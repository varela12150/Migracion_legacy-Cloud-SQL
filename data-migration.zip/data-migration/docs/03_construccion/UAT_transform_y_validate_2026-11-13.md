# UAT · sp_transform y sp_validate con datos reales (06/11 – 13/11/2026)

Ambiente: `crautos_db` de UAT, `stg_raw` cargado por AWS DMS (102 tablas; 47 en alcance). Run 1 (FULL).
Scripts y orden de ejecución: [sql/staging/90_UAT/LEEME.md](../../sql/staging/90_UAT/LEEME.md).

## sp_transform (run 1)

| Resultado | Detalle |
| --- | --- |
| 31/32 entidades SUCCESS en la primera corrida (06/11) | `blocked_contact` FAILED: 3 filas con llave de origen vacía dejaban `id` NULL (23502) |
| Fix 13/11 | Las filas con llave vacía se excluyen y se registran como `VAL_PK_MISSING`. Re-ejecución: 5.836 leídas, 5.832 cargadas, 3 registradas, SUCCESS |
| Volumen en `stg_transform` | ≈9,9 M filas en 32 entidades (las mayores: `listing_equipment` 7,2 M, `listing_image` 1,5 M, `app_user` 378 mil, `listing` 266 mil) |

## sp_validate (run 1, 13/11)

- `stg_validated` se creó con `70_sp_validate/00_stg_validated_desde_transform.sql` (el script 2d no creó tablas en UAT).
- 64 reglas cargadas (31 de relación, 17 de teléfono, 10 de correo, 6 de rango u obligatorias; 2 inactivas hasta cargar `map_catalog`). Detalle en [Reglas_validacion_CRAutos.xlsx](Reglas_validacion_CRAutos.xlsx).
- Prueba previa con `brand`: 234/234 aprobadas.
- Corrida completa: 32/32 entidades sin fallas técnicas (17 SUCCESS, 15 SUCCESS_WITH_ERRORS).

| Total | Filas |
| --- | --- |
| Revisadas | 9.927.167 |
| Aprobadas | 7.197.876 (72,5 %), de ellas 185.052 con WARNING |
| Detenidas (ERROR) | 2.729.291 (27,5 %), todas por reglas de relación (FK) |

## Hallazgos en revisión (regla por regla)

| ID | Tipo | Descripción |
| --- | --- | --- |
| H-05 | Enlace | Algunos hijos calculan el UUID del padre con una llave distinta a la del padre (ej.: `prepayment.seller_id` por código del vendedor; `seller.id` por correo). Rechazo del 100 % en prepayment, user_favorite y user_request; 98 % en user_report |
| H-06 | Enlace | Fotos y equipamiento de anuncios de traspaso se enlazan con `fn_legacy_uuid('listing', …)`, pero `listing_transfer` usa `'usedcars.archivetraspaso'` |
| H-07 | Trazabilidad | El dedup `DISTINCT ON (id)` descarta sin registro 14.170 filas de `listing` (mismo código en varias tablas del ciclo de vida) y 2.458 de `payment_log` |
| H-01 | Formato | Teléfonos con dos números en un campo: 107.357 WARNING en `listing` y 65.839 en `listing_transfer` |
| H-08 | Bitácora | `step_log.started_at = finished_at`: los SP usan `now()`; usar `clock_timestamp()` |
| H-09 | Mapeo | Columnas de origen sin mapear en `ip_allowlist`, `model` y `blocked_contact` |
