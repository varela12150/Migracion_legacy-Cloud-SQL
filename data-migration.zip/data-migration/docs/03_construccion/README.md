# Construcción

## UAT con datos reales (06/11 – 13/11/2026)

- **sp_transform:** 32/32 entidades con datos reales (fix de `blocked_contact` el 13/11).
- **sp_validate:** 64 reglas; 9,9 M filas revisadas, 72,5 % aprobadas; lo detenido está en revisión regla por regla.
- **Detalle:** [UAT_transform_y_validate_2026-11-13.md](UAT_transform_y_validate_2026-11-13.md) · reglas en [Reglas_validacion_CRAutos.xlsx](Reglas_validacion_CRAutos.xlsx) · carga DMS vs MySQL en [Comparacion_MySQL_vs_UAT_stg_raw.xlsx](Comparacion_MySQL_vs_UAT_stg_raw.xlsx)

## Prueba del sp_transform con datos dummy

- **Evidencia completa (Word):** [Evidencia_pruebas_sp_transform_dummy_2026-10-30.docx](Evidencia_pruebas_sp_transform_dummy_2026-10-30.docx)
- **Scripts usados:** [sql/staging/60_datos_dummy](../../sql/staging/60_datos_dummy/)

### Resultado: PRUEBA SUPERADA (30/10/2026, crautos_db)

| Prueba | Resultado |
| --- | --- |
| Carga dummy stg_raw | 47 tablas, 2.650 filas |
| sp_transform_all (run 1) | 32/32 entidades SUCCESS, 0 errores |
| Calidad | Emails limpios; fechas 0000/00/00 → NULL; 35 columnas UNMAPPED (esperado: map_catalog vacío) |
| Idempotencia (run 2) | 0 filas modificadas; totales iguales (listing 340, app_user 200, listing_equipment 4.532, payment 290) |
| CDC (run 3) | UPDATE de provincia 1 → solo esa fila cambia; DELETE de provincia 7 → `_is_deleted = true`; resto intacto |

### Hallazgos

| ID | Tipo | Descripción |
| --- | --- | --- |
| H-01 | Defecto | `telefono` de listing/listing_transfer trae "tel1 / tel2" y `fn_clean_phone_cr` concatena los dígitos (370 filas) |
| H-02 | Datos dummy | newcars.dealers repite el mismo teléfono en los 25 pares dphoneN (500 contactos repetidos) |
| H-03 | Pendiente | 35 columnas UNMAPPED hasta cargar map_catalog |
| H-04 | Ambiente | Extensiones instaladas por error en stg_raw; se movieron a public |

### Lecciones (DBeaver / Aurora)

- DBeaver no entiende `\ir`, `\set`, `\gset`, `\echo`. Usar los scripts de `60_datos_dummy/dbeaver/`.
- `CREATE EXTENSION` se instala en el primer esquema del `search_path`, que DBeaver fija al esquema activo. Ejecutar siempre con `public` como esquema activo.
- Sin Auto-Commit, un error deshace todo el script y el `CALL` falla con *invalid transaction termination*.
- Para correr un SP individual, crear antes el run en `stg_control.migration_run` y cerrarlo a mano.
