-- ======================================================================
-- Script maestro – crea esquemas, tablas, funciones y procedimientos del staging (v1)
-- Ejecutar con psql desde esta carpeta:  psql -d crautos_db -f 00_ejecutar_todo.sql
-- Requisito: stg_raw ya creado (DMS o 40_stg_raw/). Si no existe, los CREATE PROCEDURE
-- igual compilan (plpgsql valida las tablas al ejecutar, no al crear).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026
-- ======================================================================

\set ON_ERROR_STOP on
\ir 00_esquemas.sql

-- stg_control (tablas + funciones comunes)
\ir 10_stg_control/01_migration_run.sql
\ir 10_stg_control/02_validation_rule.sql
\ir 10_stg_control/03_step_log.sql
\ir 10_stg_control/04_error_record.sql
\ir 10_stg_control/05_reconciliation.sql
\ir 10_stg_control/06_map_catalog.sql
\ir 10_stg_control/07_source_table_registry.sql
\ir 10_stg_control/08_watermark.sql
\ir 10_stg_control/09_funciones_comunes.sql

-- stg_transform (32 entidades)
\ir 20_stg_transform/04_catalogos/brand.sql
\ir 20_stg_transform/04_catalogos/body_style.sql
\ir 20_stg_transform/04_catalogos/province.sql
\ir 20_stg_transform/03_publicaciones/equipment.sql
\ir 20_stg_transform/05_accesorios/accessory_section.sql
\ir 20_stg_transform/04_catalogos/model.sql
\ir 20_stg_transform/01_usuarios/app_user.sql
\ir 20_stg_transform/01_usuarios/seller.sql
\ir 20_stg_transform/01_usuarios/dealer.sql
\ir 20_stg_transform/01_usuarios/dealer_contact.sql
\ir 20_stg_transform/01_usuarios/admin_user.sql
\ir 20_stg_transform/03_publicaciones/listing.sql
\ir 20_stg_transform/03_publicaciones/listing_transfer.sql
\ir 20_stg_transform/03_publicaciones/listing_image.sql
\ir 20_stg_transform/03_publicaciones/listing_equipment.sql
\ir 20_stg_transform/03_publicaciones/special_deal.sql
\ir 20_stg_transform/03_publicaciones/banner.sql
\ir 20_stg_transform/05_accesorios/accessory_listing.sql
\ir 20_stg_transform/01_usuarios/user_favorite.sql
\ir 20_stg_transform/01_usuarios/user_friend.sql
\ir 20_stg_transform/01_usuarios/user_request.sql
\ir 20_stg_transform/01_usuarios/user_suggestion.sql
\ir 20_stg_transform/01_usuarios/user_report.sql
\ir 20_stg_transform/02_seguridad/blocked_contact.sql
\ir 20_stg_transform/02_seguridad/ip_allowlist.sql
\ir 20_stg_transform/02_seguridad/system_parameter.sql
\ir 20_stg_transform/06_pagos/payment.sql
\ir 20_stg_transform/06_pagos/payment_log.sql
\ir 20_stg_transform/06_pagos/prepayment.sql
\ir 20_stg_transform/06_pagos/coupon.sql
\ir 20_stg_transform/06_pagos/auto_renewal.sql
\ir 20_stg_transform/06_pagos/einvoice_document.sql

-- stg_validated (32 entidades)
\ir 30_stg_validated/04_catalogos/brand.sql
\ir 30_stg_validated/04_catalogos/body_style.sql
\ir 30_stg_validated/04_catalogos/province.sql
\ir 30_stg_validated/03_publicaciones/equipment.sql
\ir 30_stg_validated/05_accesorios/accessory_section.sql
\ir 30_stg_validated/04_catalogos/model.sql
\ir 30_stg_validated/01_usuarios/app_user.sql
\ir 30_stg_validated/01_usuarios/seller.sql
\ir 30_stg_validated/01_usuarios/dealer.sql
\ir 30_stg_validated/01_usuarios/dealer_contact.sql
\ir 30_stg_validated/01_usuarios/admin_user.sql
\ir 30_stg_validated/03_publicaciones/listing.sql
\ir 30_stg_validated/03_publicaciones/listing_transfer.sql
\ir 30_stg_validated/03_publicaciones/listing_image.sql
\ir 30_stg_validated/03_publicaciones/listing_equipment.sql
\ir 30_stg_validated/03_publicaciones/special_deal.sql
\ir 30_stg_validated/03_publicaciones/banner.sql
\ir 30_stg_validated/05_accesorios/accessory_listing.sql
\ir 30_stg_validated/01_usuarios/user_favorite.sql
\ir 30_stg_validated/01_usuarios/user_friend.sql
\ir 30_stg_validated/01_usuarios/user_request.sql
\ir 30_stg_validated/01_usuarios/user_suggestion.sql
\ir 30_stg_validated/01_usuarios/user_report.sql
\ir 30_stg_validated/02_seguridad/blocked_contact.sql
\ir 30_stg_validated/02_seguridad/ip_allowlist.sql
\ir 30_stg_validated/02_seguridad/system_parameter.sql
\ir 30_stg_validated/06_pagos/payment.sql
\ir 30_stg_validated/06_pagos/payment_log.sql
\ir 30_stg_validated/06_pagos/prepayment.sql
\ir 30_stg_validated/06_pagos/coupon.sql
\ir 30_stg_validated/06_pagos/auto_renewal.sql
\ir 30_stg_validated/06_pagos/einvoice_document.sql

-- sp_transform: stg_raw → stg_transform
\ir 50_sp_transform/04_catalogos/sp_transform_brand.sql
\ir 50_sp_transform/04_catalogos/sp_transform_body_style.sql
\ir 50_sp_transform/04_catalogos/sp_transform_province.sql
\ir 50_sp_transform/03_publicaciones/sp_transform_equipment.sql
\ir 50_sp_transform/05_accesorios/sp_transform_accessory_section.sql
\ir 50_sp_transform/04_catalogos/sp_transform_model.sql
\ir 50_sp_transform/01_usuarios/sp_transform_app_user.sql
\ir 50_sp_transform/01_usuarios/sp_transform_seller.sql
\ir 50_sp_transform/01_usuarios/sp_transform_dealer.sql
\ir 50_sp_transform/01_usuarios/sp_transform_dealer_contact.sql
\ir 50_sp_transform/01_usuarios/sp_transform_admin_user.sql
\ir 50_sp_transform/03_publicaciones/sp_transform_listing.sql
\ir 50_sp_transform/03_publicaciones/sp_transform_listing_transfer.sql
\ir 50_sp_transform/03_publicaciones/sp_transform_listing_image.sql
\ir 50_sp_transform/03_publicaciones/sp_transform_listing_equipment.sql
\ir 50_sp_transform/03_publicaciones/sp_transform_special_deal.sql
\ir 50_sp_transform/03_publicaciones/sp_transform_banner.sql
\ir 50_sp_transform/05_accesorios/sp_transform_accessory_listing.sql
\ir 50_sp_transform/01_usuarios/sp_transform_user_favorite.sql
\ir 50_sp_transform/01_usuarios/sp_transform_user_friend.sql
\ir 50_sp_transform/01_usuarios/sp_transform_user_request.sql
\ir 50_sp_transform/01_usuarios/sp_transform_user_suggestion.sql
\ir 50_sp_transform/01_usuarios/sp_transform_user_report.sql
\ir 50_sp_transform/02_seguridad/sp_transform_blocked_contact.sql
\ir 50_sp_transform/02_seguridad/sp_transform_ip_allowlist.sql
\ir 50_sp_transform/02_seguridad/sp_transform_system_parameter.sql
\ir 50_sp_transform/06_pagos/sp_transform_payment.sql
\ir 50_sp_transform/06_pagos/sp_transform_payment_log.sql
\ir 50_sp_transform/06_pagos/sp_transform_prepayment.sql
\ir 50_sp_transform/06_pagos/sp_transform_coupon.sql
\ir 50_sp_transform/06_pagos/sp_transform_auto_renewal.sql
\ir 50_sp_transform/06_pagos/sp_transform_einvoice_document.sql
\ir 50_sp_transform/00_sp_transform_all.sql

-- stg_raw: lo crea AWS DMS o el DDL generado con 40_stg_raw/generar_DDL_stg_raw.sql (47 tablas v1)
