-- ======================================================================
-- 60_datos_dummy · Datos de prueba para stg_raw (v1 · 28/10/2026)
-- Llena las 47 tablas stg_raw con datos ficticios que imitan la estructura del MySQL
-- (columnas y tipos de Q01, valores de estado de Q06, relaciones de la hoja Relaciones).
-- Objetivo: probar los sp_transform mientras no hay conexión DMS ↔ MySQL.
--
-- Qué trae:
--   * Llaves consistentes: los anuncios usan codigo 100001.. (rangos distintos por tabla
--     del ciclo de vida), usuarios 500001.., vendedores V00001.., facturas 700001..
--     Así favorites, charges, prepay, coupons, models, etc. apuntan a padres que existen.
--   * Casos para probar limpieza: emails con mayúsculas y espacios, teléfonos con 506 y guiones,
--     cédulas con guiones, fechas '0000/00/00' y vacías (deben quedar NULL + WARNING),
--     códigos de estado reales de Q06 (deben salir UNMAPPED: hasta cargar map_catalog).
--   * Solo datos ficticios: ningún dato real de clientes.
--
-- Uso:  psql -d crautos_db -f 01_insert_dummy_stg_raw.sql
--       CALL stg_transform.sp_transform_all(NULL);
-- Re-ejecutable: hace TRUNCATE de stg_raw antes de insertar.
-- Autor: Andrés Varela (Ingeniería de Datos) · Generado desde Insumos/Q01.csv y Q06.csv
-- ======================================================================
\set ON_ERROR_STOP on
BEGIN;

TRUNCATE stg_raw.accesorios__archive,
         stg_raw.accesorios__charges,
         stg_raw.accesorios__coupons,
         stg_raw.accesorios__pendingpay,
         stg_raw.accesorios__sections,
         stg_raw.accesorios__sellers,
         stg_raw.micrautos__favorites,
         stg_raw.micrautos__friends,
         stg_raw.micrautos__requests,
         stg_raw.micrautos__suggestions,
         stg_raw.micrautos__userreports,
         stg_raw.micrautos__users,
         stg_raw.newcars__brands,
         stg_raw.newcars__dealers,
         stg_raw.newcars__mainbanners,
         stg_raw.newcars__models,
         stg_raw.newcars__styles,
         stg_raw.usedcars__adminusers,
         stg_raw.usedcars__archive,
         stg_raw.usedcars__archivetraspaso,
         stg_raw.usedcars__autorenewhl,
         stg_raw.usedcars__blocked,
         stg_raw.usedcars__blockedemails,
         stg_raw.usedcars__blockedips,
         stg_raw.usedcars__blockedphones,
         stg_raw.usedcars__brands,
         stg_raw.usedcars__carextras,
         stg_raw.usedcars__charges,
         stg_raw.usedcars__chargeslog,
         stg_raw.usedcars__correosfraude,
         stg_raw.usedcars__coupons,
         stg_raw.usedcars__datafile,
         stg_raw.usedcars__dealers,
         stg_raw.usedcars__expiredsellers,
         stg_raw.usedcars__ipsaccepted,
         stg_raw.usedcars__mttdtickets,
         stg_raw.usedcars__parameters,
         stg_raw.usedcars__pending,
         stg_raw.usedcars__pendingpay,
         stg_raw.usedcars__premiumbrands,
         stg_raw.usedcars__prepay,
         stg_raw.usedcars__provinces,
         stg_raw.usedcars__sellers,
         stg_raw.usedcars__specialdeals,
         stg_raw.usedcars__styles,
         stg_raw.usedcars__tdinvoices,
         stg_raw.usedcars__tdtickets;

-- accesorios.archive · 60 filas
INSERT INTO stg_raw.accesorios__archive ("codigo", "refcode", "estado", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "visits", "numpics", "nombre", "email", "tel1", "tel2", "tel3", "precio", "moneda", "refprice", "titulo", "itemdesc", "seccion", "ip", "deldate", "delby", "pwd", _dms_op, _dms_ts)
SELECT
    'A' || lpad((i + 0)::text, 6, '0'),
    'R' || i,
    (ARRAY['A','I','V'])[((i) % 3) + 1],
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    (i * 37 % 100000),
    (i % 100),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 40),
    'tienda' || (((i)-1) % 15 + 1) || '@accesorios.cr',
    left((80000000 + i * 7919 % 9999999)::text, 10),
    left((80000000 + i * 7919 % 9999999)::text, 10),
    left((80000000 + i * 7919 % 9999999)::text, 10),
    (i % 100),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    (i % 100),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 60),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    lpad((((i)-1) % 8 + 1)::text, 2, '0'),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left((i % 10)::text, 2),
    left('clave' || i, 10),
    NULL, now()
FROM generate_series(1, 60) AS g(i);

-- accesorios.charges · 40 filas
INSERT INTO stg_raw.accesorios__charges ("codigo", "adname", "source", "datein", "amount", "feature", "cname", "ctype", "clast4", "ip", "approval", _dms_op, _dms_ts)
SELECT
    'A' || lpad((((i*3)-1) % 90 + 1)::text, 6, '0'),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    round(least(999999, 1000 + (i * 7919 % 50000))::numeric, 2),
    left(((i % 3))::text, 2),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    left(((i % 3))::text, 20),
    left(lpad((i * 4241 % 10000)::text, 4, '0'), 5),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 22),
    left('X' || lpad(i::text, 6, '0'), 30),
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- accesorios.coupons · 20 filas
INSERT INTO stg_raw.accesorios__coupons ("ccoupon", "cactivedate", "cexpdate", "cdateused", "cadcode", "ctype", "creference", _dms_op, _dms_ts)
SELECT
    'ACC' || lpad(i::text, 6, '0'),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    'A' || lpad((((i*3)-1) % 90 + 1)::text, 6, '0'),
    (ARRAY['01','02'])[((i) % 2) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 200),
    NULL, now()
FROM generate_series(1, 20) AS g(i);

-- accesorios.pendingpay · 30 filas
INSERT INTO stg_raw.accesorios__pendingpay ("codigo", "refcode", "estado", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "visits", "numpics", "nombre", "email", "tel1", "tel2", "tel3", "precio", "moneda", "refprice", "titulo", "itemdesc", "seccion", "ip", "deldate", "delby", "pwd", _dms_op, _dms_ts)
SELECT
    'A' || lpad((i + 60)::text, 6, '0'),
    'R' || i,
    left(((i % 3))::text, 1),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 2),
    (i * 37 % 100000),
    (i % 100),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 40),
    'tienda' || (((i)-1) % 15 + 1) || '@accesorios.cr',
    left((80000000 + i * 7919 % 9999999)::text, 10),
    left((80000000 + i * 7919 % 9999999)::text, 10),
    left((80000000 + i * 7919 % 9999999)::text, 10),
    (i % 100),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    (i % 100),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 60),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    lpad((((i)-1) % 8 + 1)::text, 2, '0'),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left((i % 10)::text, 2),
    left('clave' || i, 10),
    NULL, now()
FROM generate_series(1, 30) AS g(i);

-- accesorios.sections · 8 filas
INSERT INTO stg_raw.accesorios__sections ("sectionid", "sectiondesc", _dms_op, _dms_ts)
SELECT
    lpad(i::text, 2, '0'),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 25),
    NULL, now()
FROM generate_series(1, 8) AS g(i);

-- accesorios.sellers · 15 filas
INSERT INTO stg_raw.accesorios__sellers ("sellername", "sellertel1", "sellertel2", "sellertel3", "selleremail", "sellerindate", "sellerexpire", "sellerlimit", "sellerstatus", "sellercode", "sellerplanamt", "sitelink", "dollaramt", "destacados", "dept", "currency", "sellerpwd", "selleraddr1", "selleraddr2", "sellerprovince", "sellercity", "accountamount", "accountlastdeposit", "accountlastcharge", "favcount", "logo", _dms_op, _dms_ts)
SELECT
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 25),
    left((i % 10)::text, 10),
    left((i % 10)::text, 10),
    left((i % 10)::text, 10),
    'tienda' || i || '@accesorios.cr',
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    (i % 100),
    left(((i % 3))::text, 2),
    'T' || lpad(i::text, 5, '0'),
    (i % 100),
    left('https://www.crautos.com/legacy/' || i, 60),
    (i % 100),
    (i % 100),
    left(((i % 3))::text, 3),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left('clave' || i, 15),
    left('Calle ' || (i % 40) || ', avenida ' || (i % 12) || ', ' || (ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 150),
    left('Calle ' || (i % 40) || ', avenida ' || (i % 12) || ', ' || (ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 150),
    left('X' || lpad(i::text, 6, '0'), 15),
    left((ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 35),
    round(least(9999999999, 1000 + (i * 7919 % 50000))::numeric, 0),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 16),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 16),
    (i * 37 % 100000),
    left('img_' || i || '.jpg', 25),
    NULL, now()
FROM generate_series(1, 15) AS g(i);

-- micrautos.favorites · 300 filas
INSERT INTO stg_raw.micrautos__favorites ("ucode", "xcode", "fcode", "fdate", "fextra", _dms_op, _dms_ts)
SELECT
    (500000 + (((i)-1) % 200 + 1))::text,
    (100000 + (((i*3)-1) % 340 + 1))::text,
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 16),
    left((i % 10)::text, 100),
    NULL, now()
FROM generate_series(1, 300) AS g(i);

-- micrautos.friends · 100 filas
INSERT INTO stg_raw.micrautos__friends ("fid", "ucode", "fcode", "fdate", "op1", "op2", "op3", _dms_op, _dms_ts)
SELECT
    left('X' || lpad(i::text, 6, '0'), 10),
    (500000 + (((i)-1) % 200 + 1))::text,
    (500000 + (((i+7)-1) % 200 + 1))::text,
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(((i % 3))::text, 5),
    left(((i % 3))::text, 5),
    left(((i % 3))::text, 5),
    NULL, now()
FROM generate_series(1, 100) AS g(i);

-- micrautos.requests · 60 filas
INSERT INTO stg_raw.micrautos__requests ("reqid", "ucode", "dcode", "reqtype", "var1", "var2", "var3", "mtext", "rdate", _dms_op, _dms_ts)
SELECT
    'Q' || lpad(i::text, 6, '0'),
    (500000 + (((i)-1) % 200 + 1))::text,
    'D' || lpad((((i*2)-1) % 20 + 1)::text, 4, '0'),
    (ARRAY['03','01'])[((i) % 2) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 20),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 20),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 20),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 250),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 16),
    NULL, now()
FROM generate_series(1, 60) AS g(i);

-- micrautos.suggestions · 40 filas
INSERT INTO stg_raw.micrautos__suggestions ("userid", "datein", "suggestion", _dms_op, _dms_ts)
SELECT
    (500000 + (((i)-1) % 200 + 1))::text,
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 20),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- micrautos.userreports · 40 filas
INSERT INTO stg_raw.micrautos__userreports ("userid", "adcode", "datein", "report", "action", "repstatus", "repcode", _dms_op, _dms_ts)
SELECT
    (500000 + (((i)-1) % 200 + 1))::text,
    (100000 + (((i*7)-1) % 340 + 1))::text,
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 20),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['1','0'])[((i) % 2) + 1],
    left(((i % 3))::text, 15),
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- micrautos.users · 200 filas
INSERT INTO stg_raw.micrautos__users ("ucode", "uname", "ulname", "uidtype", "uidnum", "uday", "umonth", "uyear", "usex", "uemail", "upwd", "udatein", "ulastlogin", "ustatus", "uaddr1", "uaddr2", "ucity", "ucountry", "upostalcode", "uphonehome", "uphonework", "uphonecel", "umenustyle", "umainmenubg", "umainbgcolor", "umodelstitle", "umodelnamebg", "ufreead", "udotd", "udestacadoscolor", "udestacadosheader", "udetailmaintitle", "udetailsubtitle", "udetailequiptitle", "udetailequip", "ulisthighlight", "usendemail", "umodelborder", "unick", "unewmenubg", "uautoform", "actreqs", "actattempts", _dms_op, _dms_ts)
SELECT
    (500000 + i)::text,
    (ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1],
    (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i+3 % 12) + 1],
    (ARRAY['01','02','03','04','00',''])[((i) % 6) + 1],
    CASE WHEN i % 4 = 0 THEN lpad((i*7)::text,1,'1') || '-' || lpad((i*313 % 10000)::text,4,'0') || '-' || lpad((i*17 % 10000)::text,4,'0') ELSE (100000000 + i * 4021)::text END,
    lpad((1 + i % 28)::text, 2, '0'),
    lpad((1 + i % 12)::text, 2, '0'),
    (1960 + i % 45)::text,
    (ARRAY['M','F'])[(i % 2) + 1],
    CASE WHEN i % 9 = 0 THEN ' Usuario' || i || '@Correo.CR ' ELSE 'usuario' || i || '@correo.cr' END,
    left('clave' || i, 15),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 16),
    (ARRAY['1','5','0','2'])[((i) % 4) + 1],
    left('Calle ' || (i % 40) || ', avenida ' || (i % 12) || ', ' || (ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 70),
    left('Calle ' || (i % 40) || ', avenida ' || (i % 12) || ', ' || (ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 70),
    left((ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 25),
    'Costa Rica',
    left(((i % 3))::text, 12),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 12),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 12),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 12),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 2),
    left((i % 10)::text, 2),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 2),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 8),
    left((i % 10)::text, 2),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 2),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 2),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 8),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 8),
    left((i % 10)::text, 8),
    left('contacto' || i || '@empresa.cr', 2),
    left((i % 10)::text, 8),
    'user' || i,
    left((i % 10)::text, 2),
    left((i % 10)::text, 1),
    (i % 100),
    (i % 100),
    NULL, now()
FROM generate_series(1, 200) AS g(i);

-- newcars.brands · 20 filas
INSERT INTO stg_raw.newcars__brands ("brandid", "brandname", "branddir", "status", "video1", "expostatus", _dms_op, _dms_ts)
SELECT
    lpad(i::text, 2, '0'),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 20),
    left('https://www.crautos.com/legacy/' || i, 50),
    left(((i % 3))::text, 2),
    left('https://www.crautos.com/legacy/' || i, 250),
    left(((i % 3))::text, 2),
    NULL, now()
FROM generate_series(1, 20) AS g(i);

-- newcars.dealers · 20 filas
INSERT INTO stg_raw.newcars__dealers ("dcode", "dname", "daddress", "dphone1", "dphoneref1", "dphone2", "dphoneref2", "dphone3", "dphoneref3", "dphone4", "dphoneref4", "dphone5", "dphoneref5", "dphone6", "dphoneref6", "dphone7", "dphoneref7", "dphone8", "dphoneref8", "dphone9", "dphoneref9", "dphone10", "dphoneref10", "dphone11", "dphoneref11", "dphone12", "dphoneref12", "dphone13", "dphoneref13", "dphone14", "dphoneref14", "dphone15", "dphoneref15", "dphone16", "dphoneref16", "dphone17", "dphoneref17", "dphone18", "dphoneref18", "dphone19", "dphoneref19", "dphone20", "dphoneref20", "dphone21", "dphoneref21", "dphone22", "dphoneref22", "dphone23", "dphoneref23", "dphone24", "dphoneref24", "dphone25", "dphoneref25", "dotherinfo", "duser", "dpwd", "email1", "email2", "email3", "dwebsite", "dusedcode", _dms_op, _dms_ts)
SELECT
    'D' || lpad(i::text, 4, '0'),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 50),
    left('Calle ' || (i % 40) || ', avenida ' || (i % 12) || ', ' || (ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 200),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 30),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((i % 10)::text, 15),
    left('clave' || i, 20),
    left('contacto' || i || '@empresa.cr', 100),
    left('contacto' || i || '@empresa.cr', 100),
    left('contacto' || i || '@empresa.cr', 100),
    left('https://www.crautos.com/legacy/' || i, 100),
    'V' || lpad((((i*2)-1) % 50 + 1)::text, 5, '0'),
    NULL, now()
FROM generate_series(1, 20) AS g(i);

-- newcars.mainbanners · 10 filas
INSERT INTO stg_raw.newcars__mainbanners ("codigo", "client", "filename", "link", "mobilelink", "target", "startdate", "enddate", _dms_op, _dms_ts)
SELECT
    'BAN' || i,
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 50),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 50),
    left('https://www.crautos.com/legacy/' || i, 100),
    left('https://www.crautos.com/legacy/' || i, 100),
    left((i % 10)::text, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    NULL, now()
FROM generate_series(1, 10) AS g(i);

-- newcars.models · 60 filas
INSERT INTO stg_raw.newcars__models ("mcode", "mdealer", "mbrand", "mbasemodel", "mstyle", "mpicscode", "myear", "mprice", "mdescrip", "motherspecs", "mmaintext", "mnumpics", "mnumvideos", "mequipment", "mmotor", "menginesize", "mpower", "mtorque", "msuspension", "msteering", "mtransmission", "mtransmission2", "mbrakes", "mtires", "mwarranty", "mfuel", "mdrive", "mfueltank", "mmaxspeed", "mvalves", "mdoors", "mvisible", "mweight", "mheight", "mwidth", "mlength", "mdiameter", "mvideo1", _dms_op, _dms_ts)
SELECT
    'M' || lpad(i::text, 5, '0'),
    'D' || lpad((((i)-1) % 20 + 1)::text, 4, '0'),
    lpad((((i)-1) % 20 + 1)::text, 2, '0'),
    left((i % 10)::text, 20),
    lpad((((i)-1) % 10 + 1)::text, 2, '0'),
    left('img_' || i || '.jpg', 30),
    (2022 + i % 4)::text,
    (15000000 + i * 250000),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (i % 100),
    (i % 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (i % 100),
    left((i % 10)::text, 30),
    left((i % 10)::text, 30),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((i % 10)::text, 1),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((i % 10)::text, 200),
    left((i % 10)::text, 200),
    left((i % 10)::text, 1),
    left((i % 10)::text, 1),
    left((i % 10)::text, 12),
    left((i % 10)::text, 12),
    (i % 100),
    (i % 100),
    left(((i % 3))::text, 1),
    left((i % 10)::text, 12),
    left((i % 10)::text, 12),
    left((i % 10)::text, 12),
    left((i % 10)::text, 12),
    left((i % 10)::text, 12),
    left('https://www.crautos.com/legacy/' || i, 100),
    NULL, now()
FROM generate_series(1, 60) AS g(i);

-- newcars.styles · 10 filas
INSERT INTO stg_raw.newcars__styles ("styleid", "stylename", _dms_op, _dms_ts)
SELECT
    lpad(i::text, 2, '0'),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 20),
    NULL, now()
FROM generate_series(1, 10) AS g(i);

-- usedcars.adminusers · 10 filas
INSERT INTO stg_raw.usedcars__adminusers ("userid", "userpwd", "userlevel", "username", "userphone", "userposition", _dms_op, _dms_ts)
SELECT
    'admin' || i,
    left('clave' || i, 15),
    left(((i % 3))::text, 2),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 60),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 15),
    left((i % 10)::text, 60),
    NULL, now()
FROM generate_series(1, 10) AS g(i);

-- usedcars.archive · 100 filas
INSERT INTO stg_raw.usedcars__archive ("codigo", "refcode", "pwd", "agencia", "marca", "modelo", "motor", "ano", "estilo", "numpas", "precio", "precio2", "dexchrate", "traspaso", "estado", "color", "telefono", "whatsapp", "email", "coment", "coment2", "aiassist", "nombre", "foto", "numpics", "combustibl", "erange", "rangetype", "kwh", "transmisio", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20", "f21", "f22", "f23", "f24", "f25", "f26", "f27", "f28", "f29", "f30", "f31", "f32", "f33", "f34", "f35", "f36", "f37", "f38", "f39", "f40", "fstatus", "status", "mileage", "mileagetype", "source", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "option6", "option7", "option8", "option9", "option10", "compareactive", "comparepending", "comparehistory", "visits", "fototn", "foto2", "foto3", "foto4", "foto5", "interior360", "videoname", "color2", "negotiable", "registered", "tag", "numdoors", "province", "favcount", "recibe", "vin", "cchash", "appby", "delby", "deldate", "blocked", "blockedreason", "blockedby", "currency", "premium", _dms_op, _dms_ts)
SELECT
    (100000 + 240 + i)::text,
    'R' || (100000 + 240 + i)::text,
    left('clave' || i, 10),
    CASE WHEN i % 3 = 0 THEN lpad((((i)-1) % 10 + 1)::text, 2, '0') ELSE '' END,
    (((i)-1) % 30 + 1),
    (ARRAY['Corolla','Hilux','RAV4','Civic','CR-V','Tucson','Sportage','Rio','Yaris','Frontier','X-Trail','Mazda 3','Ranger','Montero'])[(i % 14) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 5),
    (2008 + i % 17)::text,
    lpad((((i)-1) % 10 + 1)::text, 2, '0'),
    (i % 100),
    (3500000 + (i * 7919 % 400) * 50000)::numeric,
    0,
    round(((i * 37) % 999)::numeric, 0),
    (i % 100),
    (ARRAY['01','02','03','04','10'])[((i) % 5) + 1],
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END || ' / ' || CASE (i+1) % 5 WHEN 0 THEN '506' || (88000000 + (i+1) * 37 % 999999)::text WHEN 1 THEN (2200 + (i+1) % 700)::text || '-' || lpad(((i+1)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i+1) * 7919 % 29999999)::text END,
    left((80000000 + i * 7919 % 9999999)::text, 9),
    CASE WHEN i % 2 = 0 THEN 'vendedor' || (((i)-1) % 50 + 1) || '@autos.cr' ELSE 'usuario' || (((i)-1) % 200 + 1) || '@correo.cr' END,
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    'foto_' || (100000 + 240 + i)::text || '.jpg',
    (i % 100),
    left((i % 10)::text, 1),
    round(((i * 37) % 999)::numeric, 0),
    left(((i % 3))::text, 1),
    round(((i * 37) % 999)::numeric, 1),
    left((i % 10)::text, 1),
    CASE WHEN (i + 1) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 2) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 3) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 4) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 5) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 6) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 7) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 8) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 9) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 10) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 11) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 12) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 13) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 14) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 15) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 16) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 17) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 18) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 19) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 20) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 21) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 22) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 23) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 24) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 25) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 26) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 27) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 28) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 29) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 30) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 31) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 32) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 33) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 34) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 35) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 36) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 37) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 38) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 39) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 40) % 3 = 0 THEN 'S' ELSE '' END,
    (ARRAY['','B1','2'])[((i) % 3) + 1],
    (ARRAY['0','2','1','3'])[((i) % 4) + 1],
    (i * 3571 % 250000)::numeric,
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 20),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    'fototn_' || (100000 + 240 + i)::text || '.jpg',
    'foto2_' || (100000 + 240 + i)::text || '.jpg',
    'foto3_' || (100000 + 240 + i)::text || '.jpg',
    'foto4_' || (100000 + 240 + i)::text || '.jpg',
    'foto5_' || (100000 + 240 + i)::text || '.jpg',
    left((i % 10)::text, 1),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left('X' || lpad(i::text, 6, '0'), 10),
    left((i % 10)::text, 1),
    ((((i)-1) % 7 + 1))::text,
    (i * 37 % 100000),
    left((i % 10)::text, 2),
    'JTDBR32E' || lpad((i * 99991 % 1000000000)::text, 9, '0'),
    left('X' || lpad(i::text, 6, '0'), 50),
    left((i % 10)::text, 25),
    left((i % 10)::text, 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left((i % 10)::text, 1),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 250),
    left((i % 10)::text, 25),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left((i % 10)::text, 1),
    NULL, now()
FROM generate_series(1, 100) AS g(i);

-- usedcars.archivetraspaso · 30 filas
INSERT INTO stg_raw.usedcars__archivetraspaso ("codigo", "refcode", "pwd", "agencia", "marca", "modelo", "motor", "ano", "estilo", "numpas", "precio", "precio2", "dexchrate", "estado", "color", "telefono", "whatsapp", "email", "coment", "coment2", "aiassist", "nombre", "foto", "certificar", "combustibl", "transmisio", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20", "f21", "f22", "f23", "f24", "f25", "f26", "f27", "f28", "f29", "f30", "f31", "f32", "f33", "f34", "f35", "f36", "f37", "f38", "f39", "f40", "fstatus", "status", "mileage", "source", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "option6", "option7", "option8", "option9", "option10", "compareactive", "comparepending", "comparehistory", "visits", "fototn", "foto2", "foto3", "foto4", "foto5", "interior360", "videoname", "color2", "negotiable", "registered", "tag", "numdoors", "province", "favcount", "recibe", "vin", "cchash", "appby", "delby", "deldate", "blocked", "blockedreason", "blockedby", "currency", "premium", _dms_op, _dms_ts)
SELECT
    (100000 + (((i)-1) % 340 + 1))::text,
    'R' || (100000 + 0 + i)::text,
    left('clave' || i, 10),
    CASE WHEN i % 3 = 0 THEN lpad((((i)-1) % 10 + 1)::text, 2, '0') ELSE '' END,
    (((i)-1) % 30 + 1),
    (ARRAY['Corolla','Hilux','RAV4','Civic','CR-V','Tucson','Sportage','Rio','Yaris','Frontier','X-Trail','Mazda 3','Ranger','Montero'])[(i % 14) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 5),
    (2008 + i % 17)::text,
    lpad((((i)-1) % 10 + 1)::text, 2, '0'),
    (i % 100),
    (3500000 + (i * 7919 % 400) * 50000)::numeric,
    0,
    round(((i * 37) % 999)::numeric, 0),
    (ARRAY['01','02','03','04','10'])[((i) % 5) + 1],
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END || ' / ' || CASE (i+1) % 5 WHEN 0 THEN '506' || (88000000 + (i+1) * 37 % 999999)::text WHEN 1 THEN (2200 + (i+1) % 700)::text || '-' || lpad(((i+1)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i+1) * 7919 % 29999999)::text END,
    left((80000000 + i * 7919 % 9999999)::text, 9),
    CASE WHEN i % 2 = 0 THEN 'vendedor' || (((i)-1) % 50 + 1) || '@autos.cr' ELSE 'usuario' || (((i)-1) % 200 + 1) || '@correo.cr' END,
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    'foto_' || (100000 + 0 + i)::text || '.jpg',
    left((i % 10)::text, 15),
    left((i % 10)::text, 1),
    left((i % 10)::text, 1),
    CASE WHEN (i + 1) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 2) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 3) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 4) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 5) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 6) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 7) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 8) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 9) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 10) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 11) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 12) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 13) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 14) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 15) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 16) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 17) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 18) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 19) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 20) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 21) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 22) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 23) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 24) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 25) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 26) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 27) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 28) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 29) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 30) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 31) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 32) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 33) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 34) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 35) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 36) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 37) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 38) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 39) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 40) % 3 = 0 THEN 'S' ELSE '' END,
    (ARRAY['','B1','2'])[((i) % 3) + 1],
    (ARRAY['0','2','1','3'])[((i) % 4) + 1],
    (i * 3571 % 250000)::numeric,
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 20),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    'fototn_' || (100000 + 0 + i)::text || '.jpg',
    'foto2_' || (100000 + 0 + i)::text || '.jpg',
    'foto3_' || (100000 + 0 + i)::text || '.jpg',
    'foto4_' || (100000 + 0 + i)::text || '.jpg',
    'foto5_' || (100000 + 0 + i)::text || '.jpg',
    left((i % 10)::text, 1),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left('X' || lpad(i::text, 6, '0'), 10),
    left((i % 10)::text, 1),
    ((((i)-1) % 7 + 1))::text,
    (i * 37 % 100000),
    left((i % 10)::text, 2),
    'JTDBR32E' || lpad((i * 99991 % 1000000000)::text, 9, '0'),
    left('X' || lpad(i::text, 6, '0'), 50),
    left((i % 10)::text, 25),
    left((i % 10)::text, 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left((i % 10)::text, 1),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 250),
    left((i % 10)::text, 25),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left((i % 10)::text, 1),
    NULL, now()
FROM generate_series(1, 30) AS g(i);

-- usedcars.autorenewhl · 40 filas
INSERT INTO stg_raw.usedcars__autorenewhl ("datein", "renewdate", "adcode", "rstatus", _dms_op, _dms_ts)
SELECT
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 20),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 20),
    (100000 + (((i*7)-1) % 340 + 1))::text,
    CASE WHEN (i+5) % 47 = 0 THEN '0000/00/00' WHEN (i+5) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i+5) * 7919 % 900) * interval '1 day' + ((i+5) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END,
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- usedcars.blocked · 20 filas
INSERT INTO stg_raw.usedcars__blocked ("blockedid", "blockedname", _dms_op, _dms_ts)
SELECT
    'BLK' || i,
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 100),
    NULL, now()
FROM generate_series(1, 20) AS g(i);

-- usedcars.blockedemails · 20 filas
INSERT INTO stg_raw.usedcars__blockedemails ("blockedemail", "blockedname", _dms_op, _dms_ts)
SELECT
    left('fraude' || i || '@spam.com', 60),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    NULL, now()
FROM generate_series(1, 20) AS g(i);

-- usedcars.blockedips · 20 filas
INSERT INTO stg_raw.usedcars__blockedips ("ip", "reason", _dms_op, _dms_ts)
SELECT
    '190.' || (i % 250) || '.' || (i * 7 % 250) || '.' || (i * 13 % 250),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 100),
    NULL, now()
FROM generate_series(1, 20) AS g(i);

-- usedcars.blockedphones · 20 filas
INSERT INTO stg_raw.usedcars__blockedphones ("blockedphone", "blockedname", _dms_op, _dms_ts)
SELECT
    left((80000000 + i * 7919 % 9999999)::text, 9),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    NULL, now()
FROM generate_series(1, 20) AS g(i);

-- usedcars.brands · 30 filas
INSERT INTO stg_raw.usedcars__brands ("brandid", "brandname", _dms_op, _dms_ts)
SELECT
    i,
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 20),
    NULL, now()
FROM generate_series(1, 30) AS g(i);

-- usedcars.carextras · 40 filas
INSERT INTO stg_raw.usedcars__carextras ("idextra", "description", _dms_op, _dms_ts)
SELECT
    i,
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 45),
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- usedcars.charges · 250 filas
INSERT INTO stg_raw.usedcars__charges ("codigo", "adname", "source", "datein", "amount", "feature", "cname", "ctype", "clast4", "ip", "approval", "tdresponse", "tdname", "tdemail", "tdidtype", "tdidnum", "tdclave", "tdmsg", "tdstatus", "tdinvoicenum", "json", _dms_op, _dms_ts)
SELECT
    (100000 + (((i*3)-1) % 340 + 1))::text,
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 22),
    round(least(999999, 1000 + (i * 7919 % 50000))::numeric, 2),
    left(((i % 3))::text, 2),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    left(((i % 3))::text, 20),
    left(lpad((i * 4241 % 10000)::text, 4, '0'), 5),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 22),
    left('X' || lpad(i::text, 6, '0'), 30),
    '{"estado":"aceptado","consecutivo":' || i || '}',
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 90),
    left('contacto' || i || '@empresa.cr', 150),
    (ARRAY['01','02','03'])[((i) % 3) + 1],
    left('X' || lpad(i::text, 6, '0'), 20),
    '506' || to_char(date '2024-01-01' + (i) % 600, 'DDMMYY') || '003101123456' || lpad(((700000 + (((i)-1) % 250 + 1)))::text, 20, '0') || '1' || lpad((i)::text, 8, '0'),
    left((i % 10)::text, 150),
    (ARRAY['ACEP','RECH','PROC'])[((i) % 3) + 1],
    ((700000 + (((i)-1) % 250 + 1)))::text,
    '{"estado":"aceptado","consecutivo":' || i || '}',
    NULL, now()
FROM generate_series(1, 250) AS g(i);

-- usedcars.chargeslog · 150 filas
INSERT INTO stg_raw.usedcars__chargeslog ("codigo", "adname", "datein", "amount", "fullorder", "ip", "response", "avsresponse", "cvvresponse", "responsetime", _dms_op, _dms_ts)
SELECT
    (100000 + (((i*3)-1) % 340 + 1))::text,
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 22),
    round(least(999999, 1000 + (i * 7919 % 50000))::numeric, 2),
    left((i % 10)::text, 40),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 22),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 30),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 30),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 30),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 30),
    NULL, now()
FROM generate_series(1, 150) AS g(i);

-- usedcars.correosfraude · 15 filas
INSERT INTO stg_raw.usedcars__correosfraude ("codigo", "emailaddr", _dms_op, _dms_ts)
SELECT
    'CF' || i,
    left('fraude' || i || '@spam.com', 200),
    NULL, now()
FROM generate_series(1, 15) AS g(i);

-- usedcars.coupons · 40 filas
INSERT INTO stg_raw.usedcars__coupons ("ccoupon", "cactivedate", "cexpdate", "cdateused", "cadcode", "ctype", "creference", _dms_op, _dms_ts)
SELECT
    'USE' || lpad(i::text, 6, '0'),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    (100000 + (((i*7)-1) % 340 + 1))::text,
    (ARRAY['01'])[((i) % 1) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 200),
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- usedcars.datafile · 100 filas
INSERT INTO stg_raw.usedcars__datafile ("codigo", "refcode", "pwd", "agencia", "marca", "modelo", "motor", "ano", "estilo", "numpas", "precio", "precio2", "dexchrate", "traspaso", "estado", "color", "telefono", "whatsapp", "email", "coment", "coment2", "aiassist", "nombre", "foto", "numpics", "combustibl", "erange", "rangetype", "kwh", "transmisio", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20", "f21", "f22", "f23", "f24", "f25", "f26", "f27", "f28", "f29", "f30", "f31", "f32", "f33", "f34", "f35", "f36", "f37", "f38", "f39", "f40", "fstatus", "status", "mileage", "mileagetype", "source", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "option6", "option7", "option8", "option9", "option10", "compareactive", "comparepending", "comparehistory", "visits", "fototn", "foto2", "foto3", "foto4", "foto5", "interior360", "videoname", "color2", "negotiable", "registered", "tag", "numdoors", "province", "favcount", "recibe", "vin", "cchash", "appby", "delby", "deldate", "blocked", "blockedreason", "blockedby", "currency", "premium", _dms_op, _dms_ts)
SELECT
    (100000 + 0 + i)::text,
    'R' || (100000 + 0 + i)::text,
    left('clave' || i, 10),
    CASE WHEN i % 3 = 0 THEN lpad((((i)-1) % 10 + 1)::text, 2, '0') ELSE '' END,
    (((i)-1) % 30 + 1),
    (ARRAY['Corolla','Hilux','RAV4','Civic','CR-V','Tucson','Sportage','Rio','Yaris','Frontier','X-Trail','Mazda 3','Ranger','Montero'])[(i % 14) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 5),
    (2008 + i % 17)::text,
    lpad((((i)-1) % 10 + 1)::text, 2, '0'),
    (i % 100),
    (3500000 + (i * 7919 % 400) * 50000)::numeric,
    0,
    round(((i * 37) % 999)::numeric, 0),
    (i % 100),
    (ARRAY['01','02','03','04','10'])[((i) % 5) + 1],
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END || ' / ' || CASE (i+1) % 5 WHEN 0 THEN '506' || (88000000 + (i+1) * 37 % 999999)::text WHEN 1 THEN (2200 + (i+1) % 700)::text || '-' || lpad(((i+1)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i+1) * 7919 % 29999999)::text END,
    left((80000000 + i * 7919 % 9999999)::text, 9),
    CASE WHEN i % 2 = 0 THEN 'vendedor' || (((i)-1) % 50 + 1) || '@autos.cr' ELSE 'usuario' || (((i)-1) % 200 + 1) || '@correo.cr' END,
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    'foto_' || (100000 + 0 + i)::text || '.jpg',
    (i % 100),
    left((i % 10)::text, 1),
    round(((i * 37) % 999)::numeric, 0),
    left(((i % 3))::text, 1),
    round(((i * 37) % 999)::numeric, 1),
    left((i % 10)::text, 1),
    CASE WHEN (i + 1) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 2) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 3) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 4) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 5) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 6) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 7) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 8) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 9) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 10) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 11) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 12) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 13) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 14) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 15) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 16) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 17) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 18) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 19) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 20) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 21) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 22) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 23) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 24) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 25) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 26) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 27) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 28) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 29) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 30) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 31) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 32) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 33) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 34) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 35) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 36) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 37) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 38) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 39) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 40) % 3 = 0 THEN 'S' ELSE '' END,
    (ARRAY['','B1','2'])[((i) % 3) + 1],
    (ARRAY['0','2','1','3'])[((i) % 4) + 1],
    (i * 3571 % 250000)::numeric,
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    'fototn_' || (100000 + 0 + i)::text || '.jpg',
    'foto2_' || (100000 + 0 + i)::text || '.jpg',
    'foto3_' || (100000 + 0 + i)::text || '.jpg',
    'foto4_' || (100000 + 0 + i)::text || '.jpg',
    'foto5_' || (100000 + 0 + i)::text || '.jpg',
    left((i % 10)::text, 1),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left('X' || lpad(i::text, 6, '0'), 10),
    left((i % 10)::text, 1),
    ((((i)-1) % 7 + 1))::text,
    (i * 37 % 100000),
    left((i % 10)::text, 2),
    'JTDBR32E' || lpad((i * 99991 % 1000000000)::text, 9, '0'),
    left('X' || lpad(i::text, 6, '0'), 50),
    left((i % 10)::text, 25),
    left((i % 10)::text, 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left((i % 10)::text, 1),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 250),
    left((i % 10)::text, 25),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left((i % 10)::text, 1),
    NULL, now()
FROM generate_series(1, 100) AS g(i);

-- usedcars.dealers · 10 filas
INSERT INTO stg_raw.usedcars__dealers ("dealercode", "dealername", "folder", "link", "demail", _dms_op, _dms_ts)
SELECT
    lpad(i::text, 2, '0'),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    left('https://www.crautos.com/legacy/' || i, 40),
    left('https://www.crautos.com/legacy/' || i, 50),
    left('contacto' || i || '@empresa.cr', 255),
    NULL, now()
FROM generate_series(1, 10) AS g(i);

-- usedcars.expiredsellers · 60 filas
INSERT INTO stg_raw.usedcars__expiredsellers ("codigo", "refcode", "pwd", "agencia", "marca", "modelo", "motor", "ano", "estilo", "numpas", "precio", "precio2", "dexchrate", "traspaso", "estado", "color", "telefono", "whatsapp", "email", "coment", "coment2", "aiassist", "nombre", "foto", "numpics", "combustibl", "erange", "rangetype", "kwh", "transmisio", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20", "f21", "f22", "f23", "f24", "f25", "f26", "f27", "f28", "f29", "f30", "f31", "f32", "f33", "f34", "f35", "f36", "f37", "f38", "f39", "f40", "fstatus", "status", "mileage", "mileagetype", "source", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "option6", "option7", "option8", "option9", "option10", "compareactive", "comparepending", "comparehistory", "visits", "fototn", "foto2", "foto3", "foto4", "foto5", "interior360", "videoname", "color2", "negotiable", "registered", "tag", "numdoors", "province", "favcount", "recibe", "vin", "cchash", "appby", "delby", "deldate", "blocked", "blockedreason", "blockedby", "currency", "premium", _dms_op, _dms_ts)
SELECT
    (100000 + 180 + i)::text,
    'R' || (100000 + 180 + i)::text,
    left('clave' || i, 10),
    CASE WHEN i % 3 = 0 THEN lpad((((i)-1) % 10 + 1)::text, 2, '0') ELSE '' END,
    (((i)-1) % 30 + 1),
    (ARRAY['Corolla','Hilux','RAV4','Civic','CR-V','Tucson','Sportage','Rio','Yaris','Frontier','X-Trail','Mazda 3','Ranger','Montero'])[(i % 14) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 5),
    (2008 + i % 17)::text,
    lpad((((i)-1) % 10 + 1)::text, 2, '0'),
    (i % 100),
    (3500000 + (i * 7919 % 400) * 50000)::numeric,
    0,
    round(((i * 37) % 999)::numeric, 0),
    (i % 100),
    (ARRAY['01','02','03','04','10'])[((i) % 5) + 1],
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END || ' / ' || CASE (i+1) % 5 WHEN 0 THEN '506' || (88000000 + (i+1) * 37 % 999999)::text WHEN 1 THEN (2200 + (i+1) % 700)::text || '-' || lpad(((i+1)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i+1) * 7919 % 29999999)::text END,
    left((80000000 + i * 7919 % 9999999)::text, 9),
    CASE WHEN i % 2 = 0 THEN 'vendedor' || (((i)-1) % 50 + 1) || '@autos.cr' ELSE 'usuario' || (((i)-1) % 200 + 1) || '@correo.cr' END,
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    'foto_' || (100000 + 180 + i)::text || '.jpg',
    (i % 100),
    left((i % 10)::text, 1),
    round(((i * 37) % 999)::numeric, 0),
    left(((i % 3))::text, 1),
    round(((i * 37) % 999)::numeric, 1),
    left((i % 10)::text, 1),
    CASE WHEN (i + 1) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 2) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 3) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 4) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 5) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 6) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 7) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 8) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 9) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 10) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 11) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 12) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 13) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 14) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 15) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 16) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 17) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 18) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 19) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 20) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 21) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 22) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 23) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 24) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 25) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 26) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 27) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 28) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 29) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 30) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 31) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 32) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 33) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 34) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 35) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 36) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 37) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 38) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 39) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 40) % 3 = 0 THEN 'S' ELSE '' END,
    (ARRAY['','B1','2'])[((i) % 3) + 1],
    (ARRAY['0','2','1','3'])[((i) % 4) + 1],
    (i * 3571 % 250000)::numeric,
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    'fototn_' || (100000 + 180 + i)::text || '.jpg',
    'foto2_' || (100000 + 180 + i)::text || '.jpg',
    'foto3_' || (100000 + 180 + i)::text || '.jpg',
    'foto4_' || (100000 + 180 + i)::text || '.jpg',
    'foto5_' || (100000 + 180 + i)::text || '.jpg',
    left((i % 10)::text, 1),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left('X' || lpad(i::text, 6, '0'), 10),
    left((i % 10)::text, 1),
    ((((i)-1) % 7 + 1))::text,
    (i * 37 % 100000),
    left((i % 10)::text, 2),
    'JTDBR32E' || lpad((i * 99991 % 1000000000)::text, 9, '0'),
    left('X' || lpad(i::text, 6, '0'), 50),
    left((i % 10)::text, 25),
    left((i % 10)::text, 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left((i % 10)::text, 1),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 250),
    left((i % 10)::text, 25),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left((i % 10)::text, 1),
    NULL, now()
FROM generate_series(1, 60) AS g(i);

-- usedcars.ipsaccepted · 10 filas
INSERT INTO stg_raw.usedcars__ipsaccepted ("aip", "alocation", "actry", _dms_op, _dms_ts)
SELECT
    '190.' || (i % 250) || '.' || (i * 7 % 250) || '.' || (i * 13 % 250),
    left((ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 70),
    left('X' || lpad(i::text, 6, '0'), 3),
    NULL, now()
FROM generate_series(1, 10) AS g(i);

-- usedcars.mttdtickets · 50 filas
INSERT INTO stg_raw.usedcars__mttdtickets ("invoicenum", "tdclave", _dms_op, _dms_ts)
SELECT
    700000 + 200 + i,
    '506' || to_char(date '2024-01-01' + (i+200) % 600, 'DDMMYY') || '003101123456' || lpad(((700000 + (((i+200)-1) % 250 + 1)))::text, 20, '0') || '1' || lpad((i+200)::text, 8, '0'),
    NULL, now()
FROM generate_series(1, 50) AS g(i);

-- usedcars.parameters · 15 filas
INSERT INTO stg_raw.usedcars__parameters ("parname", "parvalue1", "parvalue2", _dms_op, _dms_ts)
SELECT
    'PARAM_' || i,
    left((i % 10)::text, 150),
    round(least(99999999, 1000 + (i * 7919 % 50000))::numeric, 2),
    NULL, now()
FROM generate_series(1, 15) AS g(i);

-- usedcars.pending · 40 filas
INSERT INTO stg_raw.usedcars__pending ("codigo", "refcode", "pwd", "agencia", "marca", "modelo", "motor", "ano", "estilo", "numpas", "precio", "precio2", "dexchrate", "traspaso", "estado", "color", "telefono", "whatsapp", "email", "coment", "coment2", "aiassist", "nombre", "foto", "numpics", "combustibl", "erange", "rangetype", "kwh", "transmisio", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20", "f21", "f22", "f23", "f24", "f25", "f26", "f27", "f28", "f29", "f30", "f31", "f32", "f33", "f34", "f35", "f36", "f37", "f38", "f39", "f40", "fstatus", "status", "mileage", "mileagetype", "source", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "option6", "option7", "option8", "option9", "option10", "compareactive", "comparepending", "comparehistory", "visits", "fototn", "foto2", "foto3", "foto4", "foto5", "interior360", "videoname", "color2", "negotiable", "registered", "tag", "numdoors", "province", "favcount", "recibe", "vin", "cchash", "appby", "delby", "deldate", "blocked", "blockedreason", "blockedby", "currency", "premium", _dms_op, _dms_ts)
SELECT
    (100000 + 100 + i)::text,
    'R' || (100000 + 100 + i)::text,
    left('clave' || i, 10),
    CASE WHEN i % 3 = 0 THEN lpad((((i)-1) % 10 + 1)::text, 2, '0') ELSE '' END,
    (((i)-1) % 30 + 1),
    (ARRAY['Corolla','Hilux','RAV4','Civic','CR-V','Tucson','Sportage','Rio','Yaris','Frontier','X-Trail','Mazda 3','Ranger','Montero'])[(i % 14) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 5),
    (2008 + i % 17)::text,
    lpad((((i)-1) % 10 + 1)::text, 2, '0'),
    (i % 100),
    (3500000 + (i * 7919 % 400) * 50000)::numeric,
    0,
    round(((i * 37) % 999)::numeric, 0),
    (i % 100),
    (ARRAY['01','02','03','04','10'])[((i) % 5) + 1],
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END || ' / ' || CASE (i+1) % 5 WHEN 0 THEN '506' || (88000000 + (i+1) * 37 % 999999)::text WHEN 1 THEN (2200 + (i+1) % 700)::text || '-' || lpad(((i+1)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i+1) * 7919 % 29999999)::text END,
    left((80000000 + i * 7919 % 9999999)::text, 9),
    CASE WHEN i % 2 = 0 THEN 'vendedor' || (((i)-1) % 50 + 1) || '@autos.cr' ELSE 'usuario' || (((i)-1) % 200 + 1) || '@correo.cr' END,
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    'foto_' || (100000 + 100 + i)::text || '.jpg',
    (i % 100),
    left((i % 10)::text, 1),
    round(((i * 37) % 999)::numeric, 0),
    left(((i % 3))::text, 1),
    round(((i * 37) % 999)::numeric, 1),
    left((i % 10)::text, 1),
    CASE WHEN (i + 1) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 2) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 3) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 4) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 5) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 6) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 7) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 8) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 9) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 10) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 11) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 12) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 13) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 14) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 15) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 16) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 17) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 18) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 19) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 20) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 21) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 22) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 23) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 24) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 25) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 26) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 27) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 28) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 29) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 30) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 31) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 32) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 33) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 34) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 35) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 36) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 37) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 38) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 39) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 40) % 3 = 0 THEN 'S' ELSE '' END,
    (ARRAY['','B1','2'])[((i) % 3) + 1],
    (ARRAY['0','2','1'])[((i) % 3) + 1],
    (i * 3571 % 250000)::numeric,
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    'fototn_' || (100000 + 100 + i)::text || '.jpg',
    'foto2_' || (100000 + 100 + i)::text || '.jpg',
    'foto3_' || (100000 + 100 + i)::text || '.jpg',
    'foto4_' || (100000 + 100 + i)::text || '.jpg',
    'foto5_' || (100000 + 100 + i)::text || '.jpg',
    left((i % 10)::text, 1),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left('X' || lpad(i::text, 6, '0'), 10),
    left((i % 10)::text, 1),
    ((((i)-1) % 7 + 1))::text,
    (i * 37 % 100000),
    left((i % 10)::text, 2),
    'JTDBR32E' || lpad((i * 99991 % 1000000000)::text, 9, '0'),
    left('X' || lpad(i::text, 6, '0'), 50),
    left((i % 10)::text, 25),
    left((i % 10)::text, 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left((i % 10)::text, 1),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 250),
    left((i % 10)::text, 25),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left((i % 10)::text, 1),
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- usedcars.pendingpay · 40 filas
INSERT INTO stg_raw.usedcars__pendingpay ("codigo", "refcode", "pwd", "agencia", "marca", "modelo", "motor", "ano", "estilo", "numpas", "precio", "precio2", "dexchrate", "traspaso", "estado", "color", "telefono", "whatsapp", "email", "coment", "coment2", "aiassist", "nombre", "foto", "numpics", "combustibl", "erange", "rangetype", "kwh", "transmisio", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12", "f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20", "f21", "f22", "f23", "f24", "f25", "f26", "f27", "f28", "f29", "f30", "f31", "f32", "f33", "f34", "f35", "f36", "f37", "f38", "f39", "f40", "fstatus", "status", "mileage", "mileagetype", "source", "datein", "expdate", "option1", "option2", "option3", "option4", "option5", "option6", "option7", "option8", "option9", "option10", "compareactive", "comparepending", "comparehistory", "visits", "fototn", "foto2", "foto3", "foto4", "foto5", "interior360", "videoname", "color2", "negotiable", "registered", "tag", "numdoors", "province", "favcount", "recibe", "vin", "cchash", "appby", "delby", "deldate", "blocked", "blockedreason", "blockedby", "currency", "premium", _dms_op, _dms_ts)
SELECT
    (100000 + 140 + i)::text,
    'R' || (100000 + 140 + i)::text,
    left('clave' || i, 10),
    CASE WHEN i % 3 = 0 THEN lpad((((i)-1) % 10 + 1)::text, 2, '0') ELSE '' END,
    (((i)-1) % 30 + 1),
    (ARRAY['Corolla','Hilux','RAV4','Civic','CR-V','Tucson','Sportage','Rio','Yaris','Frontier','X-Trail','Mazda 3','Ranger','Montero'])[(i % 14) + 1],
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 5),
    (2008 + i % 17)::text,
    lpad((((i)-1) % 10 + 1)::text, 2, '0'),
    (i % 100),
    (3500000 + (i * 7919 % 400) * 50000)::numeric,
    0,
    round(((i * 37) % 999)::numeric, 0),
    (i % 100),
    (ARRAY['01','02','03','04','10'])[((i) % 5) + 1],
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END || ' / ' || CASE (i+1) % 5 WHEN 0 THEN '506' || (88000000 + (i+1) * 37 % 999999)::text WHEN 1 THEN (2200 + (i+1) % 700)::text || '-' || lpad(((i+1)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i+1) * 7919 % 29999999)::text END,
    left((80000000 + i * 7919 % 9999999)::text, 9),
    CASE WHEN i % 2 = 0 THEN 'vendedor' || (((i)-1) % 50 + 1) || '@autos.cr' ELSE 'usuario' || (((i)-1) % 200 + 1) || '@correo.cr' END,
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 100),
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    (ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1],
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    'foto_' || (100000 + 140 + i)::text || '.jpg',
    (i % 100),
    left((i % 10)::text, 1),
    round(((i * 37) % 999)::numeric, 0),
    left(((i % 3))::text, 1),
    round(((i * 37) % 999)::numeric, 1),
    left((i % 10)::text, 1),
    CASE WHEN (i + 1) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 2) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 3) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 4) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 5) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 6) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 7) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 8) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 9) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 10) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 11) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 12) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 13) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 14) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 15) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 16) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 17) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 18) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 19) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 20) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 21) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 22) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 23) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 24) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 25) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 26) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 27) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 28) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 29) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 30) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 31) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 32) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 33) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 34) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 35) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 36) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 37) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 38) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 39) % 3 = 0 THEN 'S' ELSE '' END,
    CASE WHEN (i + 40) % 3 = 0 THEN 'S' ELSE '' END,
    (ARRAY['','B1','2'])[((i) % 3) + 1],
    (ARRAY['0','2','1','3'])[((i) % 4) + 1],
    (i * 3571 % 250000)::numeric,
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 2),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 12),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    left(((i % 3))::text, 1),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 99)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    round(((i * 37) % 999)::numeric, 0),
    'fototn_' || (100000 + 140 + i)::text || '.jpg',
    'foto2_' || (100000 + 140 + i)::text || '.jpg',
    'foto3_' || (100000 + 140 + i)::text || '.jpg',
    'foto4_' || (100000 + 140 + i)::text || '.jpg',
    'foto5_' || (100000 + 140 + i)::text || '.jpg',
    left((i % 10)::text, 1),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 200),
    left((ARRAY['Blanco','Negro','Gris','Plata','Rojo','Azul','Vino','Café'])[(i % 8) + 1], 15),
    left((i % 10)::text, 2),
    left((i % 10)::text, 2),
    left('X' || lpad(i::text, 6, '0'), 10),
    left((i % 10)::text, 1),
    ((((i)-1) % 7 + 1))::text,
    (i * 37 % 100000),
    left((i % 10)::text, 2),
    'JTDBR32E' || lpad((i * 99991 % 1000000000)::text, 9, '0'),
    left('X' || lpad(i::text, 6, '0'), 50),
    left((i % 10)::text, 25),
    left((i % 10)::text, 25),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 18),
    left((i % 10)::text, 1),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 250),
    left((i % 10)::text, 25),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left((i % 10)::text, 1),
    NULL, now()
FROM generate_series(1, 40) AS g(i);

-- usedcars.premiumbrands · 10 filas
INSERT INTO stg_raw.usedcars__premiumbrands ("premiumid", "minyear", "minprice", _dms_op, _dms_ts)
SELECT
    i,
    left((i % 10)::text, 4),
    round(least(9999999, 1000 + (i * 7919 % 50000))::numeric, 0),
    NULL, now()
FROM generate_series(1, 10) AS g(i);

-- usedcars.prepay · 200 filas
INSERT INTO stg_raw.usedcars__prepay ("ppuser", "ppseller", "ppttype", "ppdate", "ppamount", "ppdetail", "ppcomment", "ppprevbal", "ppnewbal", "ppip", _dms_op, _dms_ts)
SELECT
    'vendedor' || (((i*3)-1) % 50 + 1) || '@autos.cr',
    'V' || lpad((((i*3)-1) % 50 + 1)::text, 5, '0'),
    (ARRAY['002','001','501','010'])[((i) % 4) + 1],
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI:SS') END, 20),
    (5000 + i * 7919 % 95000),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 200),
    left((ARRAY['Vehículo en excelente estado, único dueño.','Recibo carro de menor valor.','Marchamo al día, RTV recién pasada.','Precio negociable, financiamiento disponible.','Mantenimiento de agencia, llantas nuevas.'])[(i % 5) + 1], 200),
    (i * 1237 % 200000),
    (i * 1237 % 200000) + (5000 + i * 7919 % 95000),
    left('201.' || (i % 250) || '.' || (i * 3 % 250) || '.' || (i * 11 % 250), 20),
    NULL, now()
FROM generate_series(1, 200) AS g(i);

-- usedcars.provinces · 7 filas
INSERT INTO stg_raw.usedcars__provinces ("provinceid", "provincename", _dms_op, _dms_ts)
SELECT
    i::text,
    (ARRAY['San José','Alajuela','Cartago','Heredia','Guanacaste','Puntarenas','Limón'])[(i-1 % 7) + 1],
    NULL, now()
FROM generate_series(1, 7) AS g(i);

-- usedcars.sellers · 50 filas
INSERT INTO stg_raw.usedcars__sellers ("sellername", "sellerphone", "selleremail", "sellerindate", "sellerexpire", "sellerlimit", "sellerstatus", "sellercode", "sellerplanamt", "sitelink", "dollaramt", "destacados", "dept", "currency", "sellerpwd", "sellerpwd2", "selleraddr1", "selleraddr2", "sellerprovince", "sellercity", "financeflag", "accountamount", "accountlastdeposit", "accountlastcharge", "favcount", "bannerstart", "bannerend", "premium", "video", "sellerwhatsapp", "rep", "contactname", "contactphone", "contactemail", _dms_op, _dms_ts)
SELECT
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 30),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 55),
    'vendedor' || (((i)-1) % 50 + 1) || '@autos.cr',
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    (i % 100),
    (ARRAY['1','0'])[((i) % 2) + 1],
    'V' || lpad((((i)-1) % 50 + 1)::text, 5, '0'),
    (i % 100),
    left('https://www.crautos.com/legacy/' || i, 60),
    (i % 100),
    (i % 100),
    left(((i % 3))::text, 3),
    left((ARRAY['C','D'])[(i % 2) + 1], 1),
    left('clave' || i, 15),
    left('clave' || i, 15),
    left('Calle ' || (i % 40) || ', avenida ' || (i % 12) || ', ' || (ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 150),
    left('Calle ' || (i % 40) || ', avenida ' || (i % 12) || ', ' || (ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 150),
    (ARRAY['San José','Alajuela','Cartago','Heredia','Guanacaste','Puntarenas','Limón'])[(i % 7) + 1],
    left((ARRAY['San José','Heredia','Alajuela','Cartago','Liberia','Puntarenas','Limón','Escazú','Santa Ana','Curridabat'])[(i % 10) + 1], 35),
    left(((i % 3))::text, 5),
    round(least(9999999999, 1000 + (i * 7919 % 50000))::numeric, 0),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 16),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD HH24:MI') END, 16),
    (i * 37 % 100000),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    left((i % 10)::text, 1),
    'https://www.crautos.com/legacy/' || i,
    left((80000000 + i * 7919 % 9999999)::text, 9),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 15),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 45),
    left(CASE (i) % 5 WHEN 0 THEN '506' || (88000000 + (i) * 37 % 999999)::text WHEN 1 THEN (2200 + (i) % 700)::text || '-' || lpad(((i)*13 % 10000)::text, 4, '0') ELSE (60000000 + (i) * 7919 % 29999999)::text END, 20),
    left('contacto' || i || '@empresa.cr', 50),
    NULL, now()
FROM generate_series(1, 50) AS g(i);

-- usedcars.specialdeals · 30 filas
INSERT INTO stg_raw.usedcars__specialdeals ("adcode", "ddate", "dprice", _dms_op, _dms_ts)
SELECT
    (100000 + (((i*7)-1) % 340 + 1))::text,
    left(CASE WHEN (i) % 47 = 0 THEN '0000/00/00' WHEN (i) % 53 = 0 THEN '' ELSE to_char(timestamp '2023-01-01' + ((i) * 7919 % 900) * interval '1 day' + ((i) * 37 % 1440) * interval '1 minute', 'YYYY/MM/DD') END, 10),
    (3000000 + i * 100000)::numeric,
    NULL, now()
FROM generate_series(1, 30) AS g(i);

-- usedcars.styles · 10 filas
INSERT INTO stg_raw.usedcars__styles ("styleid", "stylename", _dms_op, _dms_ts)
SELECT
    lpad(i::text, 2, '0'),
    left((ARRAY['María','José','Ana','Luis','Carlos','Sofía','Andrés','Valeria','Diego','Daniela','Jorge','Fabiola','Esteban','Mónica','Óscar'])[(i % 15) + 1] || ' ' || (ARRAY['Rodríguez','Jiménez','Mora','Vargas','Rojas','Solís','Chaves','Araya','Quesada','Núñez','Castro','Alfaro'])[(i % 12) + 1], 20),
    NULL, now()
FROM generate_series(1, 10) AS g(i);

-- usedcars.tdinvoices · 100 filas
INSERT INTO stg_raw.usedcars__tdinvoices ("invoicenum", "tdclave", _dms_op, _dms_ts)
SELECT
    700000 + 0 + i,
    '506' || to_char(date '2024-01-01' + (i+0) % 600, 'DDMMYY') || '003101123456' || lpad(((700000 + (((i+0)-1) % 250 + 1)))::text, 20, '0') || '1' || lpad((i+0)::text, 8, '0'),
    NULL, now()
FROM generate_series(1, 100) AS g(i);

-- usedcars.tdtickets · 100 filas
INSERT INTO stg_raw.usedcars__tdtickets ("invoicenum", "tdclave", _dms_op, _dms_ts)
SELECT
    700000 + 100 + i,
    '506' || to_char(date '2024-01-01' + (i+100) % 600, 'DDMMYY') || '003101123456' || lpad(((700000 + (((i+100)-1) % 250 + 1)))::text, 20, '0') || '1' || lpad((i+100)::text, 8, '0'),
    NULL, now()
FROM generate_series(1, 100) AS g(i);

COMMIT;

-- Conteo de lo cargado por tabla
SELECT 'stg_raw.accesorios__archive' AS tabla, count(*) AS filas FROM stg_raw.accesorios__archive
UNION ALL SELECT 'stg_raw.accesorios__charges' AS tabla, count(*) AS filas FROM stg_raw.accesorios__charges
UNION ALL SELECT 'stg_raw.accesorios__coupons' AS tabla, count(*) AS filas FROM stg_raw.accesorios__coupons
UNION ALL SELECT 'stg_raw.accesorios__pendingpay' AS tabla, count(*) AS filas FROM stg_raw.accesorios__pendingpay
UNION ALL SELECT 'stg_raw.accesorios__sections' AS tabla, count(*) AS filas FROM stg_raw.accesorios__sections
UNION ALL SELECT 'stg_raw.accesorios__sellers' AS tabla, count(*) AS filas FROM stg_raw.accesorios__sellers
UNION ALL SELECT 'stg_raw.micrautos__favorites' AS tabla, count(*) AS filas FROM stg_raw.micrautos__favorites
UNION ALL SELECT 'stg_raw.micrautos__friends' AS tabla, count(*) AS filas FROM stg_raw.micrautos__friends
UNION ALL SELECT 'stg_raw.micrautos__requests' AS tabla, count(*) AS filas FROM stg_raw.micrautos__requests
UNION ALL SELECT 'stg_raw.micrautos__suggestions' AS tabla, count(*) AS filas FROM stg_raw.micrautos__suggestions
UNION ALL SELECT 'stg_raw.micrautos__userreports' AS tabla, count(*) AS filas FROM stg_raw.micrautos__userreports
UNION ALL SELECT 'stg_raw.micrautos__users' AS tabla, count(*) AS filas FROM stg_raw.micrautos__users
UNION ALL SELECT 'stg_raw.newcars__brands' AS tabla, count(*) AS filas FROM stg_raw.newcars__brands
UNION ALL SELECT 'stg_raw.newcars__dealers' AS tabla, count(*) AS filas FROM stg_raw.newcars__dealers
UNION ALL SELECT 'stg_raw.newcars__mainbanners' AS tabla, count(*) AS filas FROM stg_raw.newcars__mainbanners
UNION ALL SELECT 'stg_raw.newcars__models' AS tabla, count(*) AS filas FROM stg_raw.newcars__models
UNION ALL SELECT 'stg_raw.newcars__styles' AS tabla, count(*) AS filas FROM stg_raw.newcars__styles
UNION ALL SELECT 'stg_raw.usedcars__adminusers' AS tabla, count(*) AS filas FROM stg_raw.usedcars__adminusers
UNION ALL SELECT 'stg_raw.usedcars__archive' AS tabla, count(*) AS filas FROM stg_raw.usedcars__archive
UNION ALL SELECT 'stg_raw.usedcars__archivetraspaso' AS tabla, count(*) AS filas FROM stg_raw.usedcars__archivetraspaso
UNION ALL SELECT 'stg_raw.usedcars__autorenewhl' AS tabla, count(*) AS filas FROM stg_raw.usedcars__autorenewhl
UNION ALL SELECT 'stg_raw.usedcars__blocked' AS tabla, count(*) AS filas FROM stg_raw.usedcars__blocked
UNION ALL SELECT 'stg_raw.usedcars__blockedemails' AS tabla, count(*) AS filas FROM stg_raw.usedcars__blockedemails
UNION ALL SELECT 'stg_raw.usedcars__blockedips' AS tabla, count(*) AS filas FROM stg_raw.usedcars__blockedips
UNION ALL SELECT 'stg_raw.usedcars__blockedphones' AS tabla, count(*) AS filas FROM stg_raw.usedcars__blockedphones
UNION ALL SELECT 'stg_raw.usedcars__brands' AS tabla, count(*) AS filas FROM stg_raw.usedcars__brands
UNION ALL SELECT 'stg_raw.usedcars__carextras' AS tabla, count(*) AS filas FROM stg_raw.usedcars__carextras
UNION ALL SELECT 'stg_raw.usedcars__charges' AS tabla, count(*) AS filas FROM stg_raw.usedcars__charges
UNION ALL SELECT 'stg_raw.usedcars__chargeslog' AS tabla, count(*) AS filas FROM stg_raw.usedcars__chargeslog
UNION ALL SELECT 'stg_raw.usedcars__correosfraude' AS tabla, count(*) AS filas FROM stg_raw.usedcars__correosfraude
UNION ALL SELECT 'stg_raw.usedcars__coupons' AS tabla, count(*) AS filas FROM stg_raw.usedcars__coupons
UNION ALL SELECT 'stg_raw.usedcars__datafile' AS tabla, count(*) AS filas FROM stg_raw.usedcars__datafile
UNION ALL SELECT 'stg_raw.usedcars__dealers' AS tabla, count(*) AS filas FROM stg_raw.usedcars__dealers
UNION ALL SELECT 'stg_raw.usedcars__expiredsellers' AS tabla, count(*) AS filas FROM stg_raw.usedcars__expiredsellers
UNION ALL SELECT 'stg_raw.usedcars__ipsaccepted' AS tabla, count(*) AS filas FROM stg_raw.usedcars__ipsaccepted
UNION ALL SELECT 'stg_raw.usedcars__mttdtickets' AS tabla, count(*) AS filas FROM stg_raw.usedcars__mttdtickets
UNION ALL SELECT 'stg_raw.usedcars__parameters' AS tabla, count(*) AS filas FROM stg_raw.usedcars__parameters
UNION ALL SELECT 'stg_raw.usedcars__pending' AS tabla, count(*) AS filas FROM stg_raw.usedcars__pending
UNION ALL SELECT 'stg_raw.usedcars__pendingpay' AS tabla, count(*) AS filas FROM stg_raw.usedcars__pendingpay
UNION ALL SELECT 'stg_raw.usedcars__premiumbrands' AS tabla, count(*) AS filas FROM stg_raw.usedcars__premiumbrands
UNION ALL SELECT 'stg_raw.usedcars__prepay' AS tabla, count(*) AS filas FROM stg_raw.usedcars__prepay
UNION ALL SELECT 'stg_raw.usedcars__provinces' AS tabla, count(*) AS filas FROM stg_raw.usedcars__provinces
UNION ALL SELECT 'stg_raw.usedcars__sellers' AS tabla, count(*) AS filas FROM stg_raw.usedcars__sellers
UNION ALL SELECT 'stg_raw.usedcars__specialdeals' AS tabla, count(*) AS filas FROM stg_raw.usedcars__specialdeals
UNION ALL SELECT 'stg_raw.usedcars__styles' AS tabla, count(*) AS filas FROM stg_raw.usedcars__styles
UNION ALL SELECT 'stg_raw.usedcars__tdinvoices' AS tabla, count(*) AS filas FROM stg_raw.usedcars__tdinvoices
UNION ALL SELECT 'stg_raw.usedcars__tdtickets' AS tabla, count(*) AS filas FROM stg_raw.usedcars__tdtickets
ORDER BY 1;
