-- ======================================================================
-- 60_datos_dummy · Reporte para la reunión: datos dummy y resultado del sp_transform
-- Compatible con DBeaver (sin comandos psql). Ejecutar cada consulta con Ctrl+Enter;
-- cada una abre su propia pestaña de resultados.
-- Requiere haber corrido 01_insert_dummy_stg_raw y CALL stg_transform.sp_transform_all(NULL).
-- Autor: Andrés Varela (Ingeniería de Datos) · 30/10/2026
-- ======================================================================


-- ---------------------------------------------------------------------
-- R1 · Qué hay en stg_raw (datos dummy de entrada): filas exactas por tabla
-- ---------------------------------------------------------------------
SELECT split_part(table_name, '__', 1)  AS bd_origen,
       split_part(table_name, '__', 2)  AS tabla_origen,
       (xpath('/row/n/text()',
              query_to_xml(format('SELECT count(*) AS n FROM stg_raw.%I', table_name), false, true, '')))[1]::text::int AS filas
FROM information_schema.tables
WHERE table_schema = 'stg_raw' AND table_type = 'BASE TABLE'
ORDER BY 1, 2;


-- ---------------------------------------------------------------------
-- R2 · Historial de corridas del sp_transform
-- ---------------------------------------------------------------------
SELECT r.run_id,
       r.status,
       to_char(r.started_at, 'DD/MM/YYYY HH24:MI:SS')               AS inicio,
       round(extract(epoch FROM r.finished_at - r.started_at)::numeric, 2) AS segundos,
       count(s.*)                                                   AS entidades,
       count(*) FILTER (WHERE s.status = 'SUCCESS')                 AS ok,
       count(*) FILTER (WHERE s.status <> 'SUCCESS')                AS fallidas,
       (SELECT count(*) FROM stg_control.error_record e WHERE e.run_id = r.run_id) AS errores
FROM stg_control.migration_run r
LEFT JOIN stg_control.step_log s ON s.run_id = r.run_id
GROUP BY r.run_id
ORDER BY r.run_id;


-- ---------------------------------------------------------------------
-- R3 · De stg_raw a stg_transform: filas leídas vs. escritas por entidad (corrida 1)
-- ---------------------------------------------------------------------
SELECT entity                                   AS entidad,
       rows_in                                  AS filas_origen,
       rows_ok                                  AS filas_transform,
       CASE WHEN rows_ok > rows_in THEN 'pivot: 1 fila origen → N filas'
            WHEN rows_ok = rows_in THEN '1 a 1'
            ELSE 'revisar' END                  AS relacion,
       status                                   AS estado
FROM stg_control.step_log
WHERE run_id = 1 AND step_name = 'sp_transform'
ORDER BY step_id;


-- ---------------------------------------------------------------------
-- R4 · Ejemplo: usuarios ANTES (stg_raw) y DESPUÉS (stg_transform), lado a lado
--      Muestra limpieza de teléfono (guiones y prefijo 506), cédula, fechas,
--      UUID determinístico y códigos sin homologar (UNMAPPED).
-- ---------------------------------------------------------------------
SELECT r.ucode                         AS codigo_origen,
       t.id                            AS uuid_nuevo,
       r.uname || ' ' || r.ulname      AS nombre,
       r.uemail                        AS email_antes,
       t.email                         AS email_despues,
       r.uphonecel                     AS celular_antes,
       t.phone_mobile                  AS celular_despues,
       r.uidnum                        AS cedula_antes,
       t.id_number                     AS cedula_despues,
       r.udatein                       AS fecha_alta_antes,
       t.created_at                    AS fecha_alta_despues,
       r.ustatus                       AS estado_antes,
       t.status                        AS estado_despues
FROM stg_raw.micrautos__users r
JOIN stg_transform.app_user t ON t._source_pk = r.ucode::text
ORDER BY r.ucode
LIMIT 15;


-- ---------------------------------------------------------------------
-- R5 · Casos de limpieza en usuarios: cuántas filas corrigió cada regla
-- ---------------------------------------------------------------------
SELECT count(*)                                                                 AS usuarios,
       count(*) FILTER (WHERE r.uemail IS DISTINCT FROM t.email)                AS emails_normalizados,
       count(*) FILTER (WHERE r.uphonecel ~ '[^0-9]' OR r.uphonecel ~ '^506\d{8}$') AS celulares_limpiados,
       count(*) FILTER (WHERE r.uidnum ~ '[\s\-]')                              AS cedulas_sin_guiones,
       count(*) FILTER (WHERE nullif(trim(r.udatein), '') IS NOT NULL AND t.created_at IS NULL) AS fechas_invalidas_a_null,
       count(*) FILTER (WHERE t.status LIKE 'UNMAPPED:%')                       AS estados_por_homologar
FROM stg_raw.micrautos__users r
JOIN stg_transform.app_user t ON t._source_pk = r.ucode::text;


-- ---------------------------------------------------------------------
-- R6 · Ejemplo de pivot: un anuncio genera varias filas de fotos y equipamiento
-- ---------------------------------------------------------------------
SELECT l.legacy_id                                         AS codigo_anuncio,
       l.publication_lifecycle                             AS ciclo_vida,
       l.model_name                                        AS modelo,
       l.year                                              AS anio,
       l.price                                             AS precio,
       (SELECT count(*) FROM stg_transform.listing_image i     WHERE i.listing_id = l.id) AS fotos,
       (SELECT count(*) FROM stg_transform.listing_equipment e WHERE e.listing_id = l.id) AS equipamiento
FROM stg_transform.listing l
ORDER BY fotos DESC, equipamiento DESC
LIMIT 10;


-- ---------------------------------------------------------------------
-- R7 · Integridad: las relaciones entre tablas se resuelven con el UUID determinístico
--      (cada favorito apunta a un usuario y un anuncio que existen en stg_transform)
-- ---------------------------------------------------------------------
SELECT count(*)                                                   AS favoritos,
       count(u.id)                                                AS con_usuario_encontrado,
       count(l.id)                                                AS con_anuncio_encontrado,
       count(*) - count(u.id)                                     AS usuario_huerfano,
       count(*) - count(l.id)                                     AS anuncio_huerfano
FROM stg_transform.user_favorite f
LEFT JOIN stg_transform.app_user u ON u.id = f.user_id
LEFT JOIN stg_transform.listing  l ON l.id = f.listing_id;


-- ---------------------------------------------------------------------
-- R8 · Prueba CDC: provincias después de editar la 1 y borrar la 7 (corrida 3)
-- ---------------------------------------------------------------------
SELECT legacy_id   AS codigo,
       name        AS provincia,
       _is_deleted AS borrada,
       _run_id     AS ultima_corrida_que_la_cambio,
       to_char(_transformed_at, 'DD/MM/YYYY HH24:MI:SS') AS cambiada_el
FROM stg_transform.province
ORDER BY legacy_id::int;
