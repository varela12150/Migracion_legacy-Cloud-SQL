-- Paso 2c · stg_transform: 32 tablas (versión DBeaver). Ejecutar con Alt+X, Auto-Commit activado.

-- ===== 20_stg_transform/04_catalogos/brand.sql
-- ======================================================================
-- stg_transform.brand
-- Dominio: Catalogos · Destino final: listings_db.brand
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.brands  →  stg_raw.usedcars__brands
--   - newcars.brands  →  stg_raw.newcars__brands
--   - usedcars.premiumbrands  →  stg_raw.usedcars__premiumbrands
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.brand (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    status                       text,
    video_url                    text,
    expo_status                  text,
    brand_id                     uuid,
    premium_min_year             smallint,
    premium_min_price            numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_brand PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.brand IS 'Origen: usedcars.brands, newcars.brands, usedcars.premiumbrands. Destino: listings_db.brand';
COMMENT ON COLUMN stg_transform.brand.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.brand.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.brand.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.brand.name IS 'Homologado: initcap(trim()); unificar con newcars.brands';
COMMENT ON COLUMN stg_transform.brand.status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_transform.brand.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.brand.expo_status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_transform.brand.brand_id IS 'Por confirmar: Lookup brand por premiumid = usedcars.brands.brandid';
COMMENT ON COLUMN stg_transform.brand.premium_min_year IS 'Transformado: Copiar como regla de marca premium';
COMMENT ON COLUMN stg_transform.brand.premium_min_price IS 'Transformado: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_brand_src ON stg_transform.brand (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_brand_brand_id ON stg_transform.brand (brand_id);


-- ===== 20_stg_transform/04_catalogos/body_style.sql
-- ======================================================================
-- stg_transform.body_style
-- Dominio: Catalogos · Destino final: listings_db.body_style
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.styles  →  stg_raw.usedcars__styles
--   - newcars.styles  →  stg_raw.newcars__styles
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.body_style (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_body_style PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.body_style IS 'Origen: usedcars.styles, newcars.styles. Destino: listings_db.body_style';
COMMENT ON COLUMN stg_transform.body_style.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.body_style.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.body_style.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.body_style.name IS 'Homologado: trim(); unificar con newcars.styles';
CREATE INDEX IF NOT EXISTS ix_transform_body_style_src ON stg_transform.body_style (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/04_catalogos/province.sql
-- ======================================================================
-- stg_transform.province
-- Dominio: Catalogos · Destino final: listings_db.province
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.provinces  →  stg_raw.usedcars__provinces
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.province (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_province PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.province IS 'Origen: usedcars.provinces. Destino: listings_db.province';
COMMENT ON COLUMN stg_transform.province.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.province.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.province.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.province.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_province_src ON stg_transform.province (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/03_publicaciones/equipment.sql
-- ======================================================================
-- stg_transform.equipment
-- Dominio: Publicaciones · Destino final: listings_db.equipment
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.carextras  →  stg_raw.usedcars__carextras
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_equipment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.equipment IS 'Origen: usedcars.carextras. Destino: listings_db.equipment';
COMMENT ON COLUMN stg_transform.equipment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.equipment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.equipment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.equipment.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_equipment_src ON stg_transform.equipment (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/05_accesorios/accessory_section.sql
-- ======================================================================
-- stg_transform.accessory_section
-- Dominio: Accesorios · Destino final: listings_db.accessory_section
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.sections  →  stg_raw.accesorios__sections
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.accessory_section (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_accessory_section PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.accessory_section IS 'Origen: accesorios.sections. Destino: listings_db.accessory_section';
COMMENT ON COLUMN stg_transform.accessory_section.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.accessory_section.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.accessory_section.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.accessory_section.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_accessory_section_src ON stg_transform.accessory_section (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/04_catalogos/model.sql
-- ======================================================================
-- stg_transform.model
-- Dominio: Catalogos · Destino final: listings_db.model
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.models  →  stg_raw.newcars__models
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.model (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    brand_id                     uuid,
    base_model                   text,
    body_style_id                uuid,
    image_prefix                 text,
    year                         smallint,
    price                        numeric(14,2),
    mdescrip                     text,
    motherspecs                  text,
    mmaintext                    text,
    mnumpics                     integer,
    mnumvideos                   integer,
    mequipment                   text,
    mmotor                       text,
    menginesize                  integer,
    mpower                       text,
    mtorque                      text,
    msuspension                  text,
    msteering                    text,
    mtransmission                text,
    mtransmission2               text,
    mbrakes                      text,
    mtires                       text,
    mwarranty                    text,
    mfuel                        text,
    mdrive                       text,
    mfueltank                    text,
    mmaxspeed                    text,
    mvalves                      integer,
    mdoors                       integer,
    is_visible                   boolean,
    mweight                      text,
    mheight                      text,
    mwidth                       text,
    mlength                      text,
    mdiameter                    text,
    mvideo1                      text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_model PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.model IS 'Origen: newcars.models. Destino: listings_db.model';
COMMENT ON COLUMN stg_transform.model.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.model.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.model.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.model.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_transform.model.brand_id IS 'Derivado: Lookup UUID de brand a partir de newcars.brands.brandid';
COMMENT ON COLUMN stg_transform.model.base_model IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de newcars.styles.styleid';
COMMENT ON COLUMN stg_transform.model.image_prefix IS 'Derivado: Enlace con imágenes en S3';
COMMENT ON COLUMN stg_transform.model.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.model.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mdescrip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.motherspecs IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmaintext IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mnumpics IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mnumvideos IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mequipment IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmotor IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.menginesize IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mpower IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtorque IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.msuspension IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.msteering IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtransmission IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtransmission2 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mbrakes IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtires IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mwarranty IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mfuel IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mdrive IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mfueltank IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmaxspeed IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mvalves IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mdoors IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.is_visible IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.model.mweight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mheight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mwidth IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mlength IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mdiameter IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mvideo1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_model_src ON stg_transform.model (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_model_dealer_id ON stg_transform.model (dealer_id);
CREATE INDEX IF NOT EXISTS ix_transform_model_brand_id ON stg_transform.model (brand_id);
CREATE INDEX IF NOT EXISTS ix_transform_model_body_style_id ON stg_transform.model (body_style_id);


-- ===== 20_stg_transform/01_usuarios/app_user.sql
-- ======================================================================
-- stg_transform.app_user
-- Dominio: Usuarios · Destino final: users_db.app_user
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.users  →  stg_raw.micrautos__users
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.app_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    first_name                   text,
    last_name                    text,
    id_type                      text,
    id_number                    text,
    birth_date                   date,
    gender                       text,
    email                        text,
    created_at                   date,
    last_login_at                timestamptz,
    status                       text,
    address_line1                text,
    address_line2                text,
    city                         text,
    country                      text,
    postal_code                  text,
    phone_home                   text,
    phone_work                   text,
    phone_mobile                 text,
    free_ad_flag                 text,
    accepts_email                boolean,
    nickname                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_app_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.app_user IS 'Origen: micrautos.users. Destino: users_db.app_user';
COMMENT ON COLUMN stg_transform.app_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.app_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.app_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.app_user.first_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.last_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_transform.app_user.id_number IS 'Transformado: trim(); quitar guiones y espacios';
COMMENT ON COLUMN stg_transform.app_user.birth_date IS 'Derivado: make_date(uyear, umonth, uday); inválida → NULL + WARNING';
COMMENT ON COLUMN stg_transform.app_user.gender IS 'Homologado: Homologar con stg_control.map_catalog (GENDER)';
COMMENT ON COLUMN stg_transform.app_user.email IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_transform.app_user.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.app_user.last_login_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.app_user.status IS 'Homologado: Homologar con stg_control.map_catalog (USER_STATUS)';
COMMENT ON COLUMN stg_transform.app_user.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.country IS 'Homologado: Homologar con stg_control.map_catalog (COUNTRY)';
COMMENT ON COLUMN stg_transform.app_user.postal_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.phone_home IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.app_user.phone_work IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.app_user.phone_mobile IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.app_user.free_ad_flag IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.app_user.accepts_email IS 'Transformado: Valores sí/no → boolean';
COMMENT ON COLUMN stg_transform.app_user.nickname IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_app_user_src ON stg_transform.app_user (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/01_usuarios/seller.sql
-- ======================================================================
-- stg_transform.seller
-- Dominio: Usuarios · Destino final: users_db.seller
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.sellers  →  stg_raw.usedcars__sellers
--   - accesorios.sellers  →  stg_raw.accesorios__sellers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.seller (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    phone                        text,
    email                        text,
    start_date                   date,
    expiration_date              date,
    ad_limit                     integer,
    status                       text,
    seller_code                  text,
    plan_amount                  numeric(12,2),
    website                      text,
    plan_amount_usd              numeric(12,2),
    featured_quota               integer,
    department                   text,
    currency                     text,
    address_line1                text,
    address_line2                text,
    province_id                  text,
    city                         text,
    offers_financing             boolean,
    account_balance              numeric(12,2),
    last_deposit_at              timestamptz,
    last_charge_at               timestamptz,
    banner_start_date            date,
    banner_end_date              date,
    is_premium                   boolean,
    video_html                   text,
    whatsapp                     text,
    sales_rep                    text,
    contact_name                 text,
    contact_phone                text,
    contact_email                text,
    phone_2                      text,
    phone_3                      text,
    logo_s3_key                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_seller PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.seller IS 'Origen: usedcars.sellers, accesorios.sellers. Destino: users_db.seller';
COMMENT ON COLUMN stg_transform.seller.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.seller.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.seller.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.seller.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.email IS 'Transformado: lower(trim()); legacy_id = selleremail';
COMMENT ON COLUMN stg_transform.seller.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.expiration_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.ad_limit IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.status IS 'Homologado: Homologar con stg_control.map_catalog (SELLER_STATUS)';
COMMENT ON COLUMN stg_transform.seller.seller_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.plan_amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.plan_amount_usd IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.seller.featured_quota IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.department IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.seller.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.province_id IS 'Homologado: Homologar con stg_control.map_catalog (PROVINCE)';
COMMENT ON COLUMN stg_transform.seller.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.offers_financing IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.seller.account_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.last_deposit_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.seller.last_charge_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.seller.banner_start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.banner_end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.is_premium IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.seller.video_html IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.sales_rep IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.contact_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.seller.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.logo_s3_key IS 'Derivado: Ruta → clave en S3 (proceso de imágenes)';
CREATE INDEX IF NOT EXISTS ix_transform_seller_src ON stg_transform.seller (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/01_usuarios/dealer.sql
-- ======================================================================
-- stg_transform.dealer
-- Dominio: Usuarios · Destino final: users_db.dealer
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.dealers  →  stg_raw.usedcars__dealers
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.dealer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    website                      text,
    email                        text,
    address                      text,
    notes                        text,
    username                     text,
    email_2                      text,
    email_3                      text,
    seller_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_dealer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.dealer IS 'Origen: usedcars.dealers, newcars.dealers. Destino: users_db.dealer';
COMMENT ON COLUMN stg_transform.dealer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.dealer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.dealer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.dealer.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.address IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.username IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.email_2 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.email_3 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.seller_code IS 'Por confirmar: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_dealer_src ON stg_transform.dealer (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/01_usuarios/dealer_contact.sql
-- ======================================================================
-- stg_transform.dealer_contact
-- Dominio: Usuarios · Destino final: users_db.dealer_contact
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.dealer_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    phone                        text,
    phone_label                  text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_dealer_contact PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_transform.dealer_contact.phone IS 'dphoneN normalizado';
COMMENT ON COLUMN stg_transform.dealer_contact.phone_label IS 'dphonerefN';
COMMENT ON COLUMN stg_transform.dealer_contact.sort_order IS 'N del par dphoneN/dphonerefN';
CREATE INDEX IF NOT EXISTS ix_transform_dealer_contact_src ON stg_transform.dealer_contact (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_dealer_contact_dealer_id ON stg_transform.dealer_contact (dealer_id);


-- ===== 20_stg_transform/01_usuarios/admin_user.sql
-- ======================================================================
-- stg_transform.admin_user
-- Dominio: Usuarios · Destino final: users_db.admin_user
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.adminusers  →  stg_raw.usedcars__adminusers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.admin_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    username                     text,
    role                         text,
    full_name                    text,
    phone                        text,
    position                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_admin_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.admin_user IS 'Origen: usedcars.adminusers. Destino: users_db.admin_user';
COMMENT ON COLUMN stg_transform.admin_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.admin_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.admin_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.admin_user.username IS 'Transformado: trim(); legacy_id = userid';
COMMENT ON COLUMN stg_transform.admin_user.role IS 'Homologado: Homologar con stg_control.map_catalog (ADMIN_LEVEL)';
COMMENT ON COLUMN stg_transform.admin_user.full_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.admin_user.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.admin_user.position IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_admin_user_src ON stg_transform.admin_user (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/03_publicaciones/listing.sql
-- ======================================================================
-- stg_transform.listing
-- Dominio: Publicaciones · Destino final: listings_db.listing
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    publication_lifecycle        text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    transfer_cost                numeric(14,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    image_count                  smallint,
    fuel_type                    text,
    ev_range                     numeric(8,1),
    ev_range_unit                text,
    battery_kwh                  numeric(6,1),
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    mileage_unit                 text,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.listing IS 'Origen: usedcars.datafile, usedcars.archive, usedcars.expiredsellers, usedcars.pending, usedcars.pendingpay. Destino: listings_db.listing';
COMMENT ON COLUMN stg_transform.listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.listing.publication_lifecycle IS 'Derivado: Según tabla origen: datafile → ACTIVE · archive → ARCHIVED · expiredsellers → EXPIRED · pending → PENDING_APPROVAL · pendingpay → PENDING_PA';
COMMENT ON COLUMN stg_transform.listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_transform.listing.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_transform.listing.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_transform.listing.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.transfer_cost IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_transform.listing.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_transform.listing.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.image_count IS 'Derivado: Validación: debe coincidir con fotos migradas';
COMMENT ON COLUMN stg_transform.listing.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_transform.listing.ev_range IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.ev_range_unit IS 'Homologado: Homologar con stg_control.map_catalog (RANGE_UNIT)';
COMMENT ON COLUMN stg_transform.listing.battery_kwh IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_transform.listing.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_transform.listing.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.mileage_unit IS 'Homologado: Homologar con stg_control.map_catalog (MILEAGE_UNIT)';
COMMENT ON COLUMN stg_transform.listing.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_transform.listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_transform.listing.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_transform.listing.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_transform.listing.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.listing.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_transform_listing_src ON stg_transform.listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_dealer_id ON stg_transform.listing (dealer_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_brand_id ON stg_transform.listing (brand_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_body_style_id ON stg_transform.listing (body_style_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_province_id ON stg_transform.listing (province_id);


-- ===== 20_stg_transform/03_publicaciones/listing_transfer.sql
-- ======================================================================
-- stg_transform.listing_transfer
-- Dominio: Publicaciones · Destino final: listings_db.listing_transfer
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing_transfer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    certification                text,
    fuel_type                    text,
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing_transfer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.listing_transfer IS 'Origen: usedcars.archivetraspaso. Destino: listings_db.listing_transfer';
COMMENT ON COLUMN stg_transform.listing_transfer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.listing_transfer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.listing_transfer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.listing_transfer.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_transform.listing_transfer.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_transform.listing_transfer.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing_transfer.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_transform.listing_transfer.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_transform.listing_transfer.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_transform.listing_transfer.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.certification IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_transform.listing_transfer.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_transform.listing_transfer.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_transform.listing_transfer.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_transform.listing_transfer.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing_transfer.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.listing_transfer.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_transform.listing_transfer.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing_transfer.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_transform.listing_transfer.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_transform.listing_transfer.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing_transfer.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.listing_transfer.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_src ON stg_transform.listing_transfer (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_dealer_id ON stg_transform.listing_transfer (dealer_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_brand_id ON stg_transform.listing_transfer (brand_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_body_style_id ON stg_transform.listing_transfer (body_style_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_province_id ON stg_transform.listing_transfer (province_id);


-- ===== 20_stg_transform/03_publicaciones/listing_image.sql
-- ======================================================================
-- stg_transform.listing_image
-- Dominio: Publicaciones · Destino final: listings_db.listing_image
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing_image (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    s3_key                       text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing_image PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_transform.listing_image.s3_key IS 'Nombre de archivo origen → clave S3';
COMMENT ON COLUMN stg_transform.listing_image.sort_order IS 'Orden de la foto';
CREATE INDEX IF NOT EXISTS ix_transform_listing_image_src ON stg_transform.listing_image (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_image_listing_id ON stg_transform.listing_image (listing_id);


-- ===== 20_stg_transform/03_publicaciones/listing_equipment.sql
-- ======================================================================
-- stg_transform.listing_equipment
-- Dominio: Publicaciones · Destino final: listings_db.listing_equipment
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing_equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    equipment_id                 uuid,
    feature_slot                 smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing_equipment PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_transform.listing_equipment.feature_slot IS 'Posición f1..f40 en el origen';
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_src ON stg_transform.listing_equipment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_listing_id ON stg_transform.listing_equipment (listing_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_equipment_id ON stg_transform.listing_equipment (equipment_id);


-- ===== 20_stg_transform/03_publicaciones/special_deal.sql
-- ======================================================================
-- stg_transform.special_deal
-- Dominio: Publicaciones · Destino final: listings_db.special_deal
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.specialdeals  →  stg_raw.usedcars__specialdeals
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.special_deal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    deal_date                    date,
    deal_price                   numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_special_deal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.special_deal IS 'Origen: usedcars.specialdeals. Destino: listings_db.special_deal';
COMMENT ON COLUMN stg_transform.special_deal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.special_deal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.special_deal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.special_deal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.special_deal.deal_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.special_deal.deal_price IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_special_deal_src ON stg_transform.special_deal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_special_deal_listing_id ON stg_transform.special_deal (listing_id);


-- ===== 20_stg_transform/03_publicaciones/banner.sql
-- ======================================================================
-- stg_transform.banner
-- Dominio: Publicaciones · Destino final: listings_db.banner
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.mainbanners  →  stg_raw.newcars__mainbanners
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.banner (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    client_name                  text,
    image_s3_key                 text,
    link_url                     text,
    mobile_link_url              text,
    link_target                  text,
    start_date                   date,
    end_date                     date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_banner PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.banner IS 'Origen: newcars.mainbanners. Destino: listings_db.banner';
COMMENT ON COLUMN stg_transform.banner.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.banner.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.banner.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.banner.client_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.image_s3_key IS 'Derivado: Archivo → clave S3';
COMMENT ON COLUMN stg_transform.banner.link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.mobile_link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.link_target IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.banner.end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_transform_banner_src ON stg_transform.banner (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/05_accesorios/accessory_listing.sql
-- ======================================================================
-- stg_transform.accessory_listing
-- Dominio: Accesorios · Destino final: listings_db.accessory_listing
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.archive  →  stg_raw.accesorios__archive
--   - accesorios.pendingpay  →  stg_raw.accesorios__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.accessory_listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    condition_code               text,
    created_at                   timestamptz,
    expires_at                   timestamptz,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    visit_count                  integer,
    image_count                  smallint,
    contact_name                 text,
    contact_email                text,
    phone                        text,
    phone_2                      text,
    phone_3                      text,
    price                        numeric(14,2),
    currency                     text,
    reference_price              numeric(14,2),
    title                        text,
    description                  text,
    section_id                   uuid,
    deleted_at                   date,
    deleted_by                   text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_accessory_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.accessory_listing IS 'Origen: accesorios.archive, accesorios.pendingpay. Destino: listings_db.accessory_listing';
COMMENT ON COLUMN stg_transform.accessory_listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.accessory_listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.accessory_listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.accessory_listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (ACC_ESTADO)';
COMMENT ON COLUMN stg_transform.accessory_listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.accessory_listing.expires_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.accessory_listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.visit_count IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.image_count IS 'Derivado: Validación con imágenes';
COMMENT ON COLUMN stg_transform.accessory_listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.accessory_listing.contact_email IS 'Derivado: lower(trim()); resuelve seller_id (accesorios.sellers)';
COMMENT ON COLUMN stg_transform.accessory_listing.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.accessory_listing.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.accessory_listing.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.accessory_listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.accessory_listing.reference_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.title IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.accessory_listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.accessory_listing.section_id IS 'Derivado: Lookup UUID de accessory_section a partir de accesorios.sections.sectionid';
COMMENT ON COLUMN stg_transform.accessory_listing.deleted_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.accessory_listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_accessory_listing_src ON stg_transform.accessory_listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_accessory_listing_section_id ON stg_transform.accessory_listing (section_id);


-- ===== 20_stg_transform/01_usuarios/user_favorite.sql
-- ======================================================================
-- stg_transform.user_favorite
-- Dominio: Usuarios · Destino final: users_db.user_favorite
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.favorites  →  stg_raw.micrautos__favorites
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_favorite (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    favorite_type                text,
    created_at                   timestamptz,
    notes                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_favorite PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_favorite IS 'Origen: micrautos.favorites. Destino: users_db.user_favorite';
COMMENT ON COLUMN stg_transform.user_favorite.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_favorite.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_favorite.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_favorite.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_favorite.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.user_favorite.favorite_type IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.user_favorite.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_favorite.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_src ON stg_transform.user_favorite (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_user_id ON stg_transform.user_favorite (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_listing_id ON stg_transform.user_favorite (listing_id);


-- ===== 20_stg_transform/01_usuarios/user_friend.sql
-- ======================================================================
-- stg_transform.user_friend
-- Dominio: Usuarios · Destino final: users_db.user_friend
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.friends  →  stg_raw.micrautos__friends
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_friend (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    friend_user_id               uuid,
    created_at                   date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_friend PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_friend IS 'Origen: micrautos.friends. Destino: users_db.user_friend';
COMMENT ON COLUMN stg_transform.user_friend.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_friend.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_friend.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_friend.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_friend.friend_user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_friend.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_src ON stg_transform.user_friend (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_user_id ON stg_transform.user_friend (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_friend_user_id ON stg_transform.user_friend (friend_user_id);


-- ===== 20_stg_transform/01_usuarios/user_request.sql
-- ======================================================================
-- stg_transform.user_request
-- Dominio: Usuarios · Destino final: users_db.user_request
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.requests  →  stg_raw.micrautos__requests
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_request (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    dealer_id                    uuid,
    request_type                 text,
    attributes                   jsonb,
    message                      text,
    created_at                   timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_request PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_request IS 'Origen: micrautos.requests. Destino: users_db.user_request';
COMMENT ON COLUMN stg_transform.user_request.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_request.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_request.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_request.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_request.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_transform.user_request.request_type IS 'Homologado: Homologar con stg_control.map_catalog (REQUEST_TYPE)';
COMMENT ON COLUMN stg_transform.user_request.attributes IS 'Derivado: jsonb_build_object(''var1'',var1,''var2'',var2,''var3'',var3)';
COMMENT ON COLUMN stg_transform.user_request.message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_request.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
CREATE INDEX IF NOT EXISTS ix_transform_user_request_src ON stg_transform.user_request (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_request_user_id ON stg_transform.user_request (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_request_dealer_id ON stg_transform.user_request (dealer_id);


-- ===== 20_stg_transform/01_usuarios/user_suggestion.sql
-- ======================================================================
-- stg_transform.user_suggestion
-- Dominio: Usuarios · Destino final: users_db.user_suggestion
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.suggestions  →  stg_raw.micrautos__suggestions
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_suggestion (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    created_at                   timestamptz,
    suggestion_text              text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_suggestion PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_suggestion IS 'Origen: micrautos.suggestions. Destino: users_db.user_suggestion';
COMMENT ON COLUMN stg_transform.user_suggestion.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_suggestion.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_suggestion.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_suggestion.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_suggestion.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_suggestion.suggestion_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_suggestion_src ON stg_transform.user_suggestion (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_suggestion_user_id ON stg_transform.user_suggestion (user_id);


-- ===== 20_stg_transform/01_usuarios/user_report.sql
-- ======================================================================
-- stg_transform.user_report
-- Dominio: Usuarios · Destino final: users_db.user_report
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.userreports  →  stg_raw.micrautos__userreports
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_report (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    created_at                   timestamptz,
    report_text                  text,
    action_taken                 text,
    status                       text,
    report_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_report PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_report IS 'Origen: micrautos.userreports. Destino: users_db.user_report';
COMMENT ON COLUMN stg_transform.user_report.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_report.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_report.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_report.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_report.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.user_report.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_report.report_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_report.action_taken IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_report.status IS 'Homologado: Homologar con stg_control.map_catalog (REPORT_STATUS)';
COMMENT ON COLUMN stg_transform.user_report.report_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_report_src ON stg_transform.user_report (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_report_user_id ON stg_transform.user_report (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_report_listing_id ON stg_transform.user_report (listing_id);


-- ===== 20_stg_transform/02_seguridad/blocked_contact.sql
-- ======================================================================
-- stg_transform.blocked_contact
-- Dominio: Seguridad · Destino final: users_db.blocked_contact
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.blocked  →  stg_raw.usedcars__blocked
--   - usedcars.blockedemails  →  stg_raw.usedcars__blockedemails
--   - usedcars.blockedips  →  stg_raw.usedcars__blockedips
--   - usedcars.blockedphones  →  stg_raw.usedcars__blockedphones
--   - usedcars.correosfraude  →  stg_raw.usedcars__correosfraude
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.blocked_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    blockedid                    text,
    blockedname                  text,
    blockedemail                 text,
    ip                           text,
    reason                       text,
    blockedphone                 text,
    codigo                       text,
    emailaddr                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_blocked_contact PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.blocked_contact IS 'Origen: usedcars.blocked, usedcars.blockedemails, usedcars.blockedips, usedcars.blockedphones, usedcars.correosfraude. Destino: users_db.blocked_contact';
COMMENT ON COLUMN stg_transform.blocked_contact.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.blocked_contact.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.blocked_contact.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedid IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedemail IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_transform.blocked_contact.ip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.reason IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedphone IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.codigo IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.emailaddr IS 'Transformado: lower(trim())';
CREATE INDEX IF NOT EXISTS ix_transform_blocked_contact_src ON stg_transform.blocked_contact (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/02_seguridad/ip_allowlist.sql
-- ======================================================================
-- stg_transform.ip_allowlist
-- Dominio: Seguridad · Destino final: users_db.ip_allowlist
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.ipsaccepted  →  stg_raw.usedcars__ipsaccepted
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.ip_allowlist (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    aip                          text,
    alocation                    text,
    actry                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_ip_allowlist PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.ip_allowlist IS 'Origen: usedcars.ipsaccepted. Destino: users_db.ip_allowlist';
COMMENT ON COLUMN stg_transform.ip_allowlist.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.ip_allowlist.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.ip_allowlist.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.ip_allowlist.aip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.ip_allowlist.alocation IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.ip_allowlist.actry IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_ip_allowlist_src ON stg_transform.ip_allowlist (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/02_seguridad/system_parameter.sql
-- ======================================================================
-- stg_transform.system_parameter
-- Dominio: Seguridad · Destino final: users_db.system_parameter
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.parameters  →  stg_raw.usedcars__parameters
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.system_parameter (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    parname                      text,
    parvalue1                    text,
    parvalue2                    numeric(10,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_system_parameter PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.system_parameter IS 'Origen: usedcars.parameters. Destino: users_db.system_parameter';
COMMENT ON COLUMN stg_transform.system_parameter.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.system_parameter.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.system_parameter.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.system_parameter.parname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.system_parameter.parvalue1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.system_parameter.parvalue2 IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_system_parameter_src ON stg_transform.system_parameter (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/06_pagos/payment.sql
-- ======================================================================
-- stg_transform.payment
-- Dominio: Pagos · Destino final: payments_db.payment
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.charges  →  stg_raw.usedcars__charges
--   - accesorios.charges  →  stg_raw.accesorios__charges
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.payment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    channel                      text,
    paid_at                      timestamptz,
    amount                       numeric(12,2),
    service_code                 text,
    cardholder_name              text,
    card_brand                   text,
    card_last4                   char(4),
    authorization_code           text,
    gateway_response             jsonb,
    invoice_name                 text,
    invoice_email                text,
    invoice_id_type              text,
    invoice_id_number            text,
    einvoice_key                 text,
    einvoice_message             text,
    einvoice_status              text,
    invoice_number               text,
    gateway_payload              jsonb,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_payment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.payment IS 'Origen: usedcars.charges, accesorios.charges. Destino: payments_db.payment';
COMMENT ON COLUMN stg_transform.payment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.payment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.payment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.payment.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.payment.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.channel IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_SOURCE)';
COMMENT ON COLUMN stg_transform.payment.paid_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.payment.amount IS 'Directo: Copiar (nunca float)';
COMMENT ON COLUMN stg_transform.payment.service_code IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_FEATURE)';
COMMENT ON COLUMN stg_transform.payment.cardholder_name IS 'Transformado: trim()';
COMMENT ON COLUMN stg_transform.payment.card_brand IS 'Homologado: Homologar con stg_control.map_catalog (CARD_BRAND)';
COMMENT ON COLUMN stg_transform.payment.card_last4 IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment.authorization_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.gateway_response IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
COMMENT ON COLUMN stg_transform.payment.invoice_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.invoice_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.payment.invoice_id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_transform.payment.invoice_id_number IS 'Transformado: trim()';
COMMENT ON COLUMN stg_transform.payment.einvoice_key IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment.einvoice_message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.einvoice_status IS 'Homologado: Homologar con stg_control.map_catalog (EINVOICE_STATUS)';
COMMENT ON COLUMN stg_transform.payment.invoice_number IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment.gateway_payload IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
CREATE INDEX IF NOT EXISTS ix_transform_payment_src ON stg_transform.payment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_payment_listing_id ON stg_transform.payment (listing_id);


-- ===== 20_stg_transform/06_pagos/payment_log.sql
-- ======================================================================
-- stg_transform.payment_log
-- Dominio: Pagos · Destino final: payments_db.payment_log
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.chargeslog  →  stg_raw.usedcars__chargeslog
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.payment_log (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    attempted_at                 timestamptz,
    amount                       numeric(12,2),
    order_reference              text,
    gateway_response_code        text,
    avs_result                   text,
    cvv_result                   text,
    response_time                text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_payment_log PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.payment_log IS 'Origen: usedcars.chargeslog. Destino: payments_db.payment_log';
COMMENT ON COLUMN stg_transform.payment_log.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.payment_log.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.payment_log.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.payment_log.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.payment_log.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.attempted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.payment_log.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment_log.order_reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.gateway_response_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.avs_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.cvv_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.response_time IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_payment_log_src ON stg_transform.payment_log (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_payment_log_listing_id ON stg_transform.payment_log (listing_id);


-- ===== 20_stg_transform/06_pagos/prepayment.sql
-- ======================================================================
-- stg_transform.prepayment
-- Dominio: Pagos · Destino final: payments_db.prepayment
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.prepay  →  stg_raw.usedcars__prepay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.prepayment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    performed_by                 text,
    seller_id                    uuid,
    movement_type                text,
    movement_at                  timestamptz,
    amount                       numeric(12,2),
    detail                       text,
    comment                      text,
    previous_balance             numeric(12,2),
    new_balance                  numeric(12,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_prepayment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.prepayment IS 'Origen: usedcars.prepay. Destino: payments_db.prepayment';
COMMENT ON COLUMN stg_transform.prepayment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.prepayment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.prepayment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.prepayment.performed_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.prepayment.seller_id IS 'Derivado: Lookup UUID de seller a partir de sellers.sellercode';
COMMENT ON COLUMN stg_transform.prepayment.movement_type IS 'Homologado: Homologar con stg_control.map_catalog (PREPAY_TYPE)';
COMMENT ON COLUMN stg_transform.prepayment.movement_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.prepayment.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.prepayment.detail IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.prepayment.comment IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.prepayment.previous_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.prepayment.new_balance IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_prepayment_src ON stg_transform.prepayment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_prepayment_seller_id ON stg_transform.prepayment (seller_id);


-- ===== 20_stg_transform/06_pagos/coupon.sql
-- ======================================================================
-- stg_transform.coupon
-- Dominio: Pagos · Destino final: payments_db.coupon
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.coupons  →  stg_raw.usedcars__coupons
--   - accesorios.coupons  →  stg_raw.accesorios__coupons
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.coupon (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    code                         text,
    valid_from                   date,
    valid_to                     date,
    used_at                      date,
    listing_id                   uuid,
    coupon_type                  text,
    reference                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_coupon PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.coupon IS 'Origen: usedcars.coupons, accesorios.coupons. Destino: payments_db.coupon';
COMMENT ON COLUMN stg_transform.coupon.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.coupon.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.coupon.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.coupon.code IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_transform.coupon.valid_from IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.valid_to IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.used_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.coupon.coupon_type IS 'Homologado: Homologar con stg_control.map_catalog (COUPON_TYPE)';
COMMENT ON COLUMN stg_transform.coupon.reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_coupon_src ON stg_transform.coupon (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_coupon_listing_id ON stg_transform.coupon (listing_id);


-- ===== 20_stg_transform/06_pagos/auto_renewal.sql
-- ======================================================================
-- stg_transform.auto_renewal
-- Dominio: Pagos · Destino final: payments_db.auto_renewal
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.autorenewhl  →  stg_raw.usedcars__autorenewhl
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.auto_renewal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    created_at                   timestamptz,
    renew_at                     timestamptz,
    listing_id                   uuid,
    last_run_at                  timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_auto_renewal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.auto_renewal IS 'Origen: usedcars.autorenewhl. Destino: payments_db.auto_renewal';
COMMENT ON COLUMN stg_transform.auto_renewal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.auto_renewal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.auto_renewal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.auto_renewal.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.auto_renewal.renew_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.auto_renewal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.auto_renewal.last_run_at IS 'Transformado: Contiene fechas (''AAAA/MM/DD HH:MI''), no estados → convertir a fecha';
CREATE INDEX IF NOT EXISTS ix_transform_auto_renewal_src ON stg_transform.auto_renewal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_auto_renewal_listing_id ON stg_transform.auto_renewal (listing_id);


-- ===== 20_stg_transform/06_pagos/einvoice_document.sql
-- ======================================================================
-- stg_transform.einvoice_document
-- Dominio: Pagos · Destino final: payments_db.einvoice_document
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.tdtickets  →  stg_raw.usedcars__tdtickets
--   - usedcars.mttdtickets  →  stg_raw.usedcars__mttdtickets
--   - usedcars.tdinvoices  →  stg_raw.usedcars__tdinvoices
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.einvoice_document (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    document_number              text,
    einvoice_key                 text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_einvoice_document PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.einvoice_document IS 'Origen: usedcars.tdtickets, usedcars.mttdtickets, usedcars.tdinvoices. Destino: payments_db.einvoice_document';
COMMENT ON COLUMN stg_transform.einvoice_document.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.einvoice_document.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.einvoice_document.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.einvoice_document.document_number IS 'Transformado: Copiar; document_type = ''TICKET''';
COMMENT ON COLUMN stg_transform.einvoice_document.einvoice_key IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_einvoice_document_src ON stg_transform.einvoice_document (_source_db, _source_table, _source_pk);

