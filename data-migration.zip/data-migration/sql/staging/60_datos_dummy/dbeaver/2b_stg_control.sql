-- Paso 2b · stg_control: 8 tablas + funciones comunes (versión DBeaver). Ejecutar con Alt+X, Auto-Commit activado.

-- ===== 10_stg_control/01_migration_run.sql
-- ======================================================================
-- stg_control.migration_run
-- Grano: 1 fila por ejecución del pipeline
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.migration_run (
    run_id               bigserial NOT NULL,
    run_type             text NOT NULL,                       -- FULL / CDC / TEST / REPROCESS
    status               text NOT NULL,                       -- RUNNING / SUCCESS / FAILED
    parent_run_id        bigint,                              -- run original cuando es reproceso
    started_at           timestamptz DEFAULT now(),
    finished_at          timestamptz,
    triggered_by         text,                                -- step_functions / manual
    sfn_execution_arn    text,                                -- trazabilidad con Step Functions
    CONSTRAINT pk_migration_run PRIMARY KEY (run_id),
    CONSTRAINT fk_migration_run_parent_run_id FOREIGN KEY (parent_run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.migration_run IS '1 fila por ejecución del pipeline';
COMMENT ON COLUMN stg_control.migration_run.run_type IS 'FULL / CDC / TEST / REPROCESS';
COMMENT ON COLUMN stg_control.migration_run.status IS 'RUNNING / SUCCESS / FAILED';
COMMENT ON COLUMN stg_control.migration_run.parent_run_id IS 'run original cuando es reproceso';
COMMENT ON COLUMN stg_control.migration_run.triggered_by IS 'step_functions / manual';
COMMENT ON COLUMN stg_control.migration_run.sfn_execution_arn IS 'trazabilidad con Step Functions';
CREATE INDEX IF NOT EXISTS ix_migration_run_parent_run_id ON stg_control.migration_run (parent_run_id);


-- ===== 10_stg_control/02_validation_rule.sql
-- ======================================================================
-- stg_control.validation_rule
-- Grano: 1 fila por regla de validación
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.validation_rule (
    rule_code            text NOT NULL,                       -- p. ej. VAL_FK_USER, VAL_EMAIL_FMT
    entity               text,
    description          text,
    severity             text NOT NULL,                       -- ERROR / WARNING
    is_active            boolean NOT NULL DEFAULT true,
    CONSTRAINT pk_validation_rule PRIMARY KEY (rule_code)
);

COMMENT ON TABLE stg_control.validation_rule IS '1 fila por regla de validación';
COMMENT ON COLUMN stg_control.validation_rule.rule_code IS 'p. ej. VAL_FK_USER, VAL_EMAIL_FMT';
COMMENT ON COLUMN stg_control.validation_rule.severity IS 'ERROR / WARNING';


-- ===== 10_stg_control/03_step_log.sql
-- ======================================================================
-- stg_control.step_log
-- Grano: 1 fila por paso y entidad dentro de una ejecución
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.step_log (
    step_id              bigserial NOT NULL,
    run_id               bigint NOT NULL,
    step_name            text NOT NULL,                       -- sp_transform / sp_validate / sp_publish / sp_reconcile
    entity               text,                                -- app_user, listing, payment…
    rows_in              bigint,
    rows_ok              bigint,
    rows_error           bigint,
    rows_warning         bigint,
    started_at           timestamptz DEFAULT now(),
    finished_at          timestamptz,
    status               text NOT NULL,
    message              text,
    CONSTRAINT pk_step_log PRIMARY KEY (step_id),
    CONSTRAINT fk_step_log_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.step_log IS '1 fila por paso y entidad dentro de una ejecución';
COMMENT ON COLUMN stg_control.step_log.step_name IS 'sp_transform / sp_validate / sp_publish / sp_reconcile';
COMMENT ON COLUMN stg_control.step_log.entity IS 'app_user, listing, payment…';
CREATE INDEX IF NOT EXISTS ix_step_log_run_id ON stg_control.step_log (run_id);


-- ===== 10_stg_control/04_error_record.sql
-- ======================================================================
-- stg_control.error_record
-- Grano: 1 fila por registro rechazado o con advertencia
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.error_record (
    error_id             bigserial NOT NULL,
    run_id               bigint,
    step_name            text,
    entity               text,
    source_db            text,
    source_table         text,
    source_pk            text,
    rule_code            text,
    severity             text,                                -- ERROR = no publica · WARNING = publica
    detail               text,
    payload              jsonb,                               -- registro completo para análisis
    is_resolved          boolean NOT NULL DEFAULT false,      -- para reprocesos
    created_at           timestamptz DEFAULT now(),
    CONSTRAINT pk_error_record PRIMARY KEY (error_id),
    CONSTRAINT fk_error_record_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id),
    CONSTRAINT fk_error_record_rule_code FOREIGN KEY (rule_code) REFERENCES stg_control.validation_rule (rule_code)
);

COMMENT ON TABLE stg_control.error_record IS '1 fila por registro rechazado o con advertencia';
COMMENT ON COLUMN stg_control.error_record.severity IS 'ERROR = no publica · WARNING = publica';
COMMENT ON COLUMN stg_control.error_record.payload IS 'registro completo para análisis';
COMMENT ON COLUMN stg_control.error_record.is_resolved IS 'para reprocesos';
CREATE INDEX IF NOT EXISTS ix_error_record_run_id ON stg_control.error_record (run_id);
CREATE INDEX IF NOT EXISTS ix_error_record_rule_code ON stg_control.error_record (rule_code);
CREATE INDEX IF NOT EXISTS ix_error_record_entity ON stg_control.error_record (entity, severity);


-- ===== 10_stg_control/05_reconciliation.sql
-- ======================================================================
-- stg_control.reconciliation
-- Grano: 1 fila por entidad y ejecución
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.reconciliation (
    recon_id             bigserial NOT NULL,
    run_id               bigint NOT NULL,
    entity               text,
    source_count         bigint,
    target_count         bigint,
    error_count          bigint,
    excluded_count       bigint,
    source_checksum      text,
    target_checksum      text,
    is_match             boolean,
    checked_at           timestamptz DEFAULT now(),
    CONSTRAINT pk_reconciliation PRIMARY KEY (recon_id),
    CONSTRAINT fk_reconciliation_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.reconciliation IS '1 fila por entidad y ejecución';
CREATE INDEX IF NOT EXISTS ix_reconciliation_run_id ON stg_control.reconciliation (run_id);


-- ===== 10_stg_control/06_map_catalog.sql
-- ======================================================================
-- stg_control.map_catalog
-- Grano: 1 fila por valor origen a homologar
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.map_catalog (
    catalog_type         text NOT NULL,                       -- BRAND / STYLE / PROVINCE / LISTING_STATUS / PAYMENT_STATUS…
    source_db            text NOT NULL,
    source_value         text NOT NULL,
    target_id            uuid,                                -- id en la entidad de catálogo destino
    target_code          text,
    target_label         text,
    approved_by          text,                                -- negocio
    CONSTRAINT pk_map_catalog PRIMARY KEY (catalog_type, source_db, source_value)
);

COMMENT ON TABLE stg_control.map_catalog IS '1 fila por valor origen a homologar';
COMMENT ON COLUMN stg_control.map_catalog.catalog_type IS 'BRAND / STYLE / PROVINCE / LISTING_STATUS / PAYMENT_STATUS…';
COMMENT ON COLUMN stg_control.map_catalog.target_id IS 'id en la entidad de catálogo destino';
COMMENT ON COLUMN stg_control.map_catalog.approved_by IS 'negocio';


-- ===== 10_stg_control/07_source_table_registry.sql
-- ======================================================================
-- stg_control.source_table_registry
-- Grano: 1 fila por objeto del origen (soporta CA-02)
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.source_table_registry (
    source_db            text NOT NULL,
    source_table         text NOT NULL,
    scope_status         text NOT NULL,                       -- MAPEADA / PENDIENTE DE MAPEO / FUERA DE ALCANCE
    stg_raw_table        text,
    target_entity        text,
    load_type            text,                                -- FULL / FULL+CDC / N/A
    reason               text,
    approved_by          text,                                -- Arquitectura
    approved_at          date,
    CONSTRAINT pk_source_table_registry PRIMARY KEY (source_db, source_table)
);

COMMENT ON TABLE stg_control.source_table_registry IS '1 fila por objeto del origen (soporta CA-02)';
COMMENT ON COLUMN stg_control.source_table_registry.scope_status IS 'MAPEADA / PENDIENTE DE MAPEO / FUERA DE ALCANCE';
COMMENT ON COLUMN stg_control.source_table_registry.load_type IS 'FULL / FULL+CDC / N/A';
COMMENT ON COLUMN stg_control.source_table_registry.approved_by IS 'Arquitectura';


-- ===== 10_stg_control/08_watermark.sql
-- ======================================================================
-- stg_control.watermark
-- Grano: 1 fila por tabla origen con CDC
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.watermark (
    source_db            text NOT NULL,
    source_table         text NOT NULL,
    last_processed_at    timestamptz,                         -- último cambio CDC procesado
    last_run_id          bigint,
    CONSTRAINT pk_watermark PRIMARY KEY (source_db, source_table),
    CONSTRAINT fk_watermark_last_run_id FOREIGN KEY (last_run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.watermark IS '1 fila por tabla origen con CDC';
COMMENT ON COLUMN stg_control.watermark.last_processed_at IS 'último cambio CDC procesado';
CREATE INDEX IF NOT EXISTS ix_watermark_last_run_id ON stg_control.watermark (last_run_id);


-- ===== 10_stg_control/09_funciones_comunes.sql
-- ======================================================================
-- stg_control · Funciones comunes de transformación y bitácora
-- Las usan todos los sp_transform_<entidad>. Ejecutar después de las tablas de control.
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026
-- ======================================================================

-- ---------- Parámetros de la migración ----------
CREATE TABLE IF NOT EXISTS stg_control.migration_parameter (
    param_name   text PRIMARY KEY,
    param_value  text NOT NULL,
    description  text
);
COMMENT ON TABLE stg_control.migration_parameter IS 'Parámetros globales: namespace UUID, zona horaria, formatos de fecha';

INSERT INTO stg_control.migration_parameter (param_name, param_value, description) VALUES
  ('UUID_NAMESPACE', '6f1c2a5e-3b7d-5c41-9e2a-1d4b8c7a0f35', 'Namespace fijo de uuid_generate_v5. NO cambiar después de la primera carga'),
  ('SOURCE_TIMEZONE', 'America/Costa_Rica', 'Zona horaria de las fechas en texto del MySQL'),
  ('DATE_FORMATS', 'YYYY/MM/DD HH24:MI:SS|YYYY/MM/DD HH24:MI|YYYY/MM/DD|YYYY-MM-DD HH24:MI:SS|YYYY-MM-DD|DD/MM/YYYY', 'Formatos probados en orden (confirmar con muestras reales)')
ON CONFLICT (param_name) DO NOTHING;

CREATE OR REPLACE FUNCTION stg_control.fn_param(p_name text)
RETURNS text LANGUAGE sql STABLE AS
$$ SELECT param_value FROM stg_control.migration_parameter WHERE param_name = p_name $$;

-- ---------- Identificadores ----------
-- UUID v5 determinístico: misma llave de origen → mismo UUID en cada corrida (idempotencia y FK sin lookups).
-- Convención de p_scope: 'bd.tabla' del origen, o 'listing' para el ciclo de vida del anuncio (codigo).
CREATE OR REPLACE FUNCTION stg_control.fn_legacy_uuid(p_scope text, p_key text)
RETURNS uuid LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN nullif(trim(p_key), '') IS NULL THEN NULL
               ELSE uuid_generate_v5('6f1c2a5e-3b7d-5c41-9e2a-1d4b8c7a0f35'::uuid, p_scope || ':' || trim(p_key)) END $$;
COMMENT ON FUNCTION stg_control.fn_legacy_uuid(text, text) IS 'UUID v5 de scope:llave. El namespace debe coincidir con UUID_NAMESPACE';

-- ---------- Limpieza de texto ----------
CREATE OR REPLACE FUNCTION stg_control.fn_clean_text(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT nullif(btrim(regexp_replace(p, '[\s ]+', ' ', 'g')), '') $$;
-- latin1 → UTF-8 lo resuelve DMS (target UTF-8). Si llegan caracteres dobles (Ã©) aplicar convert_from(convert_to(p,'LATIN1'),'UTF8').

CREATE OR REPLACE FUNCTION stg_control.fn_clean_email(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT lower(stg_control.fn_clean_text(p)) $$;

CREATE OR REPLACE FUNCTION stg_control.fn_clean_phone_cr(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN d ~ '^506\d{8}$' THEN substr(d, 4) ELSE nullif(d, '') END
   FROM (SELECT regexp_replace(coalesce(p, ''), '\D', '', 'g') AS d) x $$;
-- La validación de 8 dígitos va en sp_validate (WARNING), aquí solo se normaliza.

CREATE OR REPLACE FUNCTION stg_control.fn_clean_id_number(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT nullif(regexp_replace(coalesce(p, ''), '[\s\-]', '', 'g'), '') $$;

-- ---------- Conversión de tipos (texto → tipo; inválido → NULL) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_to_int(p text)
RETURNS bigint LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN btrim(p) ~ '^-?\d{1,18}$' THEN btrim(p)::bigint END $$;

CREATE OR REPLACE FUNCTION stg_control.fn_to_numeric(p text)
RETURNS numeric LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN replace(btrim(p), ',', '') ~ '^-?\d+(\.\d+)?$' THEN replace(btrim(p), ',', '')::numeric END $$;

CREATE OR REPLACE FUNCTION stg_control.fn_to_bool(p text)
RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE lower(btrim(coalesce(p, '')))
            WHEN '1' THEN true WHEN 's' THEN true WHEN 'si' THEN true WHEN 'sí' THEN true WHEN 'y' THEN true WHEN 'yes' THEN true WHEN 'true' THEN true
            WHEN '0' THEN false WHEN 'n' THEN false WHEN 'no' THEN false WHEN 'false' THEN false
            ELSE NULL END $$;
-- TODO: confirmar con Q06 los valores reales de cada columna booleana.

CREATE OR REPLACE FUNCTION stg_control.fn_to_timestamptz(p text)
RETURNS timestamptz LANGUAGE plpgsql STABLE PARALLEL SAFE AS
$$
DECLARE
    v   text := btrim(p);
    f   text;
    ts  timestamp;
BEGIN
    IF v IS NULL OR v = '' OR v ~ '^0{4}[-/]0{2}' THEN RETURN NULL; END IF;
    FOREACH f IN ARRAY string_to_array(stg_control.fn_param('DATE_FORMATS'), '|') LOOP
        BEGIN
            ts := to_timestamp(v, f)::timestamp;
            IF ts BETWEEN '1990-01-01' AND now() + interval '20 years' THEN
                RETURN ts AT TIME ZONE stg_control.fn_param('SOURCE_TIMEZONE');
            END IF;
        EXCEPTION WHEN others THEN NULL;
        END;
    END LOOP;
    RETURN NULL;   -- sp_validate registra WARNING cuando origen no vacío y destino NULL
END;
$$;

CREATE OR REPLACE FUNCTION stg_control.fn_to_date(p text)
RETURNS date LANGUAGE sql STABLE PARALLEL SAFE AS
$$ SELECT (stg_control.fn_to_timestamptz(p) AT TIME ZONE stg_control.fn_param('SOURCE_TIMEZONE'))::date $$;

CREATE OR REPLACE FUNCTION stg_control.fn_make_date(p_year text, p_month text, p_day text)
RETURNS date LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE AS
$$
BEGIN
    RETURN make_date(btrim(p_year)::int, btrim(p_month)::int, btrim(p_day)::int);
EXCEPTION WHEN others THEN
    RETURN NULL;
END;
$$;

-- ---------- Homologación (stg_control.map_catalog) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_map_code(p_catalog text, p_source_db text, p_value text)
RETURNS text LANGUAGE sql STABLE PARALLEL SAFE AS
$$ SELECT coalesce(
          (SELECT target_code FROM stg_control.map_catalog
            WHERE catalog_type = p_catalog AND source_db IN (p_source_db, '*') AND source_value = coalesce(btrim(p_value), '')
            ORDER BY (source_db = p_source_db) DESC LIMIT 1),
          CASE WHEN nullif(btrim(p_value), '') IS NOT NULL THEN 'UNMAPPED:' || btrim(p_value) END) $$;
-- 'UNMAPPED:<valor>' se detecta en sp_validate (regla VAL_CATALOG_UNMAPPED). No se pierde el valor original.

CREATE OR REPLACE FUNCTION stg_control.fn_map_id(p_catalog text, p_source_db text, p_value text)
RETURNS uuid LANGUAGE sql STABLE PARALLEL SAFE AS
$$ SELECT target_id FROM stg_control.map_catalog
    WHERE catalog_type = p_catalog AND source_db IN (p_source_db, '*') AND source_value = coalesce(btrim(p_value), '')
    ORDER BY (source_db = p_source_db) DESC LIMIT 1 $$;

-- ---------- Específicas de publicaciones (pendientes de Q07 / proceso de imágenes) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_equipment_present(p text)
RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT coalesce(btrim(p), '') NOT IN ('', '0', 'N', 'n') $$;
-- TODO Q07: reemplazar por la lógica real de usedcars.CheckEquipment / CheckEquipment64 / CheckEquipment128.

CREATE OR REPLACE FUNCTION stg_control.fn_image_s3_key(p_file text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN nullif(btrim(p_file), '') IS NOT NULL
               THEN 'listings/legacy/' || regexp_replace(btrim(p_file), '^.*[\\/]', '') END $$;
-- TODO: confirmar convención de llaves S3 con el equipo del proceso de imágenes.

-- ---------- Bitácora (step_log / error_record) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_step_start(p_run_id bigint, p_step text, p_entity text)
RETURNS bigint LANGUAGE sql AS
$$ INSERT INTO stg_control.step_log (run_id, step_name, entity, status)
   VALUES (p_run_id, p_step, p_entity, 'RUNNING') RETURNING step_id $$;

CREATE OR REPLACE FUNCTION stg_control.fn_step_end(p_step_id bigint, p_in bigint, p_ok bigint,
                                                    p_error bigint, p_warning bigint, p_status text, p_message text)
RETURNS void LANGUAGE sql AS
$$ UPDATE stg_control.step_log
      SET rows_in = p_in, rows_ok = p_ok, rows_error = p_error, rows_warning = p_warning,
          status = p_status, message = p_message, finished_at = now()
    WHERE step_id = p_step_id $$;

CREATE OR REPLACE FUNCTION stg_control.fn_log_error(p_run_id bigint, p_step text, p_entity text,
        p_source_db text, p_source_table text, p_source_pk text, p_rule text, p_severity text,
        p_detail text, p_payload jsonb)
RETURNS void LANGUAGE sql AS
$$ INSERT INTO stg_control.error_record (run_id, step_name, entity, source_db, source_table, source_pk,
                                         rule_code, severity, detail, payload)
   VALUES (p_run_id, p_step, p_entity, p_source_db, p_source_table, p_source_pk,
           p_rule, p_severity, p_detail, p_payload) $$;

-- Reglas técnicas mínimas que usa sp_transform (error_record.rule_code tiene FK a validation_rule)
INSERT INTO stg_control.validation_rule (rule_code, entity, description, severity) VALUES
  ('SP_FAILED', NULL, 'Falla técnica de un procedimiento (ver detail)', 'ERROR'),
  ('VAL_CATALOG_UNMAPPED', NULL, 'Valor de origen sin homologar en map_catalog', 'WARNING'),
  ('VAL_DATE_INVALID', NULL, 'Fecha de origen no vacía que no se pudo convertir', 'WARNING'),
  ('VAL_FK_MISSING', NULL, 'La llave referenciada no existe en la entidad padre', 'ERROR'),
  ('VAL_LISTING_DUP_LIFECYCLE', 'listing', 'Un mismo codigo existe en más de una tabla del ciclo de vida', 'WARNING')
ON CONFLICT (rule_code) DO NOTHING;

