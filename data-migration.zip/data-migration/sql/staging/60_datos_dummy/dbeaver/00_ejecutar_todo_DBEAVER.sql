-- Versión DBeaver de 00_ejecutar_todo.sql (todos los \ir concatenados). Ejecutar con Alt+X, Auto-Commit activado.

-- ===== 00_esquemas.sql
-- ======================================================================
-- Extensiones y esquemas de staging
-- Requiere permisos CREATE en crautos_db.
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";  -- uuid_generate_v5 (UUID determinístico)
CREATE EXTENSION IF NOT EXISTS pgcrypto;     -- digest / gen_random_uuid

CREATE SCHEMA IF NOT EXISTS stg_raw;        -- espejo 1:1 del origen (lo llena AWS DMS)
CREATE SCHEMA IF NOT EXISTS stg_transform;  -- datos limpios, tipados y homologados
CREATE SCHEMA IF NOT EXISTS stg_validated;  -- solo filas que pasaron sp_validate
CREATE SCHEMA IF NOT EXISTS stg_control;    -- control operativo, errores y reconciliación



-- ===== 10_stg_control/01_migration_run.sql
-- ======================================================================
-- stg_control.migration_run
-- Grano: 1 fila por ejecución del pipeline
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.migration_run (
    run_id               bigserial NOT NULL,
    run_type             text NOT NULL,                       -- FULL / CDC / TEST / REPROCESS
    status               text NOT NULL,                       -- RUNNING / SUCCESS / FAILED
    parent_run_id        bigint,                              -- run original cuando es reproceso
    started_at           timestamptz DEFAULT now(),
    finished_at          timestamptz,
    triggered_by         text,                                -- step_functions / manual
    sfn_execution_arn    text,                                -- trazabilidad con Step Functions
    CONSTRAINT pk_migration_run PRIMARY KEY (run_id),
    CONSTRAINT fk_migration_run_parent_run_id FOREIGN KEY (parent_run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.migration_run IS '1 fila por ejecución del pipeline';
COMMENT ON COLUMN stg_control.migration_run.run_type IS 'FULL / CDC / TEST / REPROCESS';
COMMENT ON COLUMN stg_control.migration_run.status IS 'RUNNING / SUCCESS / FAILED';
COMMENT ON COLUMN stg_control.migration_run.parent_run_id IS 'run original cuando es reproceso';
COMMENT ON COLUMN stg_control.migration_run.triggered_by IS 'step_functions / manual';
COMMENT ON COLUMN stg_control.migration_run.sfn_execution_arn IS 'trazabilidad con Step Functions';
CREATE INDEX IF NOT EXISTS ix_migration_run_parent_run_id ON stg_control.migration_run (parent_run_id);


-- ===== 10_stg_control/02_validation_rule.sql
-- ======================================================================
-- stg_control.validation_rule
-- Grano: 1 fila por regla de validación
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.validation_rule (
    rule_code            text NOT NULL,                       -- p. ej. VAL_FK_USER, VAL_EMAIL_FMT
    entity               text,
    description          text,
    severity             text NOT NULL,                       -- ERROR / WARNING
    is_active            boolean NOT NULL DEFAULT true,
    CONSTRAINT pk_validation_rule PRIMARY KEY (rule_code)
);

COMMENT ON TABLE stg_control.validation_rule IS '1 fila por regla de validación';
COMMENT ON COLUMN stg_control.validation_rule.rule_code IS 'p. ej. VAL_FK_USER, VAL_EMAIL_FMT';
COMMENT ON COLUMN stg_control.validation_rule.severity IS 'ERROR / WARNING';


-- ===== 10_stg_control/03_step_log.sql
-- ======================================================================
-- stg_control.step_log
-- Grano: 1 fila por paso y entidad dentro de una ejecución
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.step_log (
    step_id              bigserial NOT NULL,
    run_id               bigint NOT NULL,
    step_name            text NOT NULL,                       -- sp_transform / sp_validate / sp_publish / sp_reconcile
    entity               text,                                -- app_user, listing, payment…
    rows_in              bigint,
    rows_ok              bigint,
    rows_error           bigint,
    rows_warning         bigint,
    started_at           timestamptz DEFAULT now(),
    finished_at          timestamptz,
    status               text NOT NULL,
    message              text,
    CONSTRAINT pk_step_log PRIMARY KEY (step_id),
    CONSTRAINT fk_step_log_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.step_log IS '1 fila por paso y entidad dentro de una ejecución';
COMMENT ON COLUMN stg_control.step_log.step_name IS 'sp_transform / sp_validate / sp_publish / sp_reconcile';
COMMENT ON COLUMN stg_control.step_log.entity IS 'app_user, listing, payment…';
CREATE INDEX IF NOT EXISTS ix_step_log_run_id ON stg_control.step_log (run_id);


-- ===== 10_stg_control/04_error_record.sql
-- ======================================================================
-- stg_control.error_record
-- Grano: 1 fila por registro rechazado o con advertencia
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.error_record (
    error_id             bigserial NOT NULL,
    run_id               bigint,
    step_name            text,
    entity               text,
    source_db            text,
    source_table         text,
    source_pk            text,
    rule_code            text,
    severity             text,                                -- ERROR = no publica · WARNING = publica
    detail               text,
    payload              jsonb,                               -- registro completo para análisis
    is_resolved          boolean NOT NULL DEFAULT false,      -- para reprocesos
    created_at           timestamptz DEFAULT now(),
    CONSTRAINT pk_error_record PRIMARY KEY (error_id),
    CONSTRAINT fk_error_record_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id),
    CONSTRAINT fk_error_record_rule_code FOREIGN KEY (rule_code) REFERENCES stg_control.validation_rule (rule_code)
);

COMMENT ON TABLE stg_control.error_record IS '1 fila por registro rechazado o con advertencia';
COMMENT ON COLUMN stg_control.error_record.severity IS 'ERROR = no publica · WARNING = publica';
COMMENT ON COLUMN stg_control.error_record.payload IS 'registro completo para análisis';
COMMENT ON COLUMN stg_control.error_record.is_resolved IS 'para reprocesos';
CREATE INDEX IF NOT EXISTS ix_error_record_run_id ON stg_control.error_record (run_id);
CREATE INDEX IF NOT EXISTS ix_error_record_rule_code ON stg_control.error_record (rule_code);
CREATE INDEX IF NOT EXISTS ix_error_record_entity ON stg_control.error_record (entity, severity);


-- ===== 10_stg_control/05_reconciliation.sql
-- ======================================================================
-- stg_control.reconciliation
-- Grano: 1 fila por entidad y ejecución
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.reconciliation (
    recon_id             bigserial NOT NULL,
    run_id               bigint NOT NULL,
    entity               text,
    source_count         bigint,
    target_count         bigint,
    error_count          bigint,
    excluded_count       bigint,
    source_checksum      text,
    target_checksum      text,
    is_match             boolean,
    checked_at           timestamptz DEFAULT now(),
    CONSTRAINT pk_reconciliation PRIMARY KEY (recon_id),
    CONSTRAINT fk_reconciliation_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.reconciliation IS '1 fila por entidad y ejecución';
CREATE INDEX IF NOT EXISTS ix_reconciliation_run_id ON stg_control.reconciliation (run_id);


-- ===== 10_stg_control/06_map_catalog.sql
-- ======================================================================
-- stg_control.map_catalog
-- Grano: 1 fila por valor origen a homologar
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.map_catalog (
    catalog_type         text NOT NULL,                       -- BRAND / STYLE / PROVINCE / LISTING_STATUS / PAYMENT_STATUS…
    source_db            text NOT NULL,
    source_value         text NOT NULL,
    target_id            uuid,                                -- id en la entidad de catálogo destino
    target_code          text,
    target_label         text,
    approved_by          text,                                -- negocio
    CONSTRAINT pk_map_catalog PRIMARY KEY (catalog_type, source_db, source_value)
);

COMMENT ON TABLE stg_control.map_catalog IS '1 fila por valor origen a homologar';
COMMENT ON COLUMN stg_control.map_catalog.catalog_type IS 'BRAND / STYLE / PROVINCE / LISTING_STATUS / PAYMENT_STATUS…';
COMMENT ON COLUMN stg_control.map_catalog.target_id IS 'id en la entidad de catálogo destino';
COMMENT ON COLUMN stg_control.map_catalog.approved_by IS 'negocio';


-- ===== 10_stg_control/07_source_table_registry.sql
-- ======================================================================
-- stg_control.source_table_registry
-- Grano: 1 fila por objeto del origen (soporta CA-02)
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.source_table_registry (
    source_db            text NOT NULL,
    source_table         text NOT NULL,
    scope_status         text NOT NULL,                       -- MAPEADA / PENDIENTE DE MAPEO / FUERA DE ALCANCE
    stg_raw_table        text,
    target_entity        text,
    load_type            text,                                -- FULL / FULL+CDC / N/A
    reason               text,
    approved_by          text,                                -- Arquitectura
    approved_at          date,
    CONSTRAINT pk_source_table_registry PRIMARY KEY (source_db, source_table)
);

COMMENT ON TABLE stg_control.source_table_registry IS '1 fila por objeto del origen (soporta CA-02)';
COMMENT ON COLUMN stg_control.source_table_registry.scope_status IS 'MAPEADA / PENDIENTE DE MAPEO / FUERA DE ALCANCE';
COMMENT ON COLUMN stg_control.source_table_registry.load_type IS 'FULL / FULL+CDC / N/A';
COMMENT ON COLUMN stg_control.source_table_registry.approved_by IS 'Arquitectura';


-- ===== 10_stg_control/08_watermark.sql
-- ======================================================================
-- stg_control.watermark
-- Grano: 1 fila por tabla origen con CDC
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.watermark (
    source_db            text NOT NULL,
    source_table         text NOT NULL,
    last_processed_at    timestamptz,                         -- último cambio CDC procesado
    last_run_id          bigint,
    CONSTRAINT pk_watermark PRIMARY KEY (source_db, source_table),
    CONSTRAINT fk_watermark_last_run_id FOREIGN KEY (last_run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.watermark IS '1 fila por tabla origen con CDC';
COMMENT ON COLUMN stg_control.watermark.last_processed_at IS 'último cambio CDC procesado';
CREATE INDEX IF NOT EXISTS ix_watermark_last_run_id ON stg_control.watermark (last_run_id);


-- ===== 10_stg_control/09_funciones_comunes.sql
-- ======================================================================
-- stg_control · Funciones comunes de transformación y bitácora
-- Las usan todos los sp_transform_<entidad>. Ejecutar después de las tablas de control.
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026
-- ======================================================================

-- ---------- Parámetros de la migración ----------
CREATE TABLE IF NOT EXISTS stg_control.migration_parameter (
    param_name   text PRIMARY KEY,
    param_value  text NOT NULL,
    description  text
);
COMMENT ON TABLE stg_control.migration_parameter IS 'Parámetros globales: namespace UUID, zona horaria, formatos de fecha';

INSERT INTO stg_control.migration_parameter (param_name, param_value, description) VALUES
  ('UUID_NAMESPACE', '6f1c2a5e-3b7d-5c41-9e2a-1d4b8c7a0f35', 'Namespace fijo de uuid_generate_v5. NO cambiar después de la primera carga'),
  ('SOURCE_TIMEZONE', 'America/Costa_Rica', 'Zona horaria de las fechas en texto del MySQL'),
  ('DATE_FORMATS', 'YYYY/MM/DD HH24:MI:SS|YYYY/MM/DD HH24:MI|YYYY/MM/DD|YYYY-MM-DD HH24:MI:SS|YYYY-MM-DD|DD/MM/YYYY', 'Formatos probados en orden (confirmar con muestras reales)')
ON CONFLICT (param_name) DO NOTHING;

CREATE OR REPLACE FUNCTION stg_control.fn_param(p_name text)
RETURNS text LANGUAGE sql STABLE AS
$$ SELECT param_value FROM stg_control.migration_parameter WHERE param_name = p_name $$;

-- ---------- Identificadores ----------
-- UUID v5 determinístico: misma llave de origen → mismo UUID en cada corrida (idempotencia y FK sin lookups).
-- Convención de p_scope: 'bd.tabla' del origen, o 'listing' para el ciclo de vida del anuncio (codigo).
CREATE OR REPLACE FUNCTION stg_control.fn_legacy_uuid(p_scope text, p_key text)
RETURNS uuid LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN nullif(trim(p_key), '') IS NULL THEN NULL
               ELSE uuid_generate_v5('6f1c2a5e-3b7d-5c41-9e2a-1d4b8c7a0f35'::uuid, p_scope || ':' || trim(p_key)) END $$;
COMMENT ON FUNCTION stg_control.fn_legacy_uuid(text, text) IS 'UUID v5 de scope:llave. El namespace debe coincidir con UUID_NAMESPACE';

-- ---------- Limpieza de texto ----------
CREATE OR REPLACE FUNCTION stg_control.fn_clean_text(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT nullif(btrim(regexp_replace(p, '[\s ]+', ' ', 'g')), '') $$;
-- latin1 → UTF-8 lo resuelve DMS (target UTF-8). Si llegan caracteres dobles (Ã©) aplicar convert_from(convert_to(p,'LATIN1'),'UTF8').

CREATE OR REPLACE FUNCTION stg_control.fn_clean_email(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT lower(stg_control.fn_clean_text(p)) $$;

CREATE OR REPLACE FUNCTION stg_control.fn_clean_phone_cr(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN d ~ '^506\d{8}$' THEN substr(d, 4) ELSE nullif(d, '') END
   FROM (SELECT regexp_replace(coalesce(p, ''), '\D', '', 'g') AS d) x $$;
-- La validación de 8 dígitos va en sp_validate (WARNING), aquí solo se normaliza.

CREATE OR REPLACE FUNCTION stg_control.fn_clean_id_number(p text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT nullif(regexp_replace(coalesce(p, ''), '[\s\-]', '', 'g'), '') $$;

-- ---------- Conversión de tipos (texto → tipo; inválido → NULL) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_to_int(p text)
RETURNS bigint LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN btrim(p) ~ '^-?\d{1,18}$' THEN btrim(p)::bigint END $$;

CREATE OR REPLACE FUNCTION stg_control.fn_to_numeric(p text)
RETURNS numeric LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN replace(btrim(p), ',', '') ~ '^-?\d+(\.\d+)?$' THEN replace(btrim(p), ',', '')::numeric END $$;

CREATE OR REPLACE FUNCTION stg_control.fn_to_bool(p text)
RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE lower(btrim(coalesce(p, '')))
            WHEN '1' THEN true WHEN 's' THEN true WHEN 'si' THEN true WHEN 'sí' THEN true WHEN 'y' THEN true WHEN 'yes' THEN true WHEN 'true' THEN true
            WHEN '0' THEN false WHEN 'n' THEN false WHEN 'no' THEN false WHEN 'false' THEN false
            ELSE NULL END $$;
-- TODO: confirmar con Q06 los valores reales de cada columna booleana.

CREATE OR REPLACE FUNCTION stg_control.fn_to_timestamptz(p text)
RETURNS timestamptz LANGUAGE plpgsql STABLE PARALLEL SAFE AS
$$
DECLARE
    v   text := btrim(p);
    f   text;
    ts  timestamp;
BEGIN
    IF v IS NULL OR v = '' OR v ~ '^0{4}[-/]0{2}' THEN RETURN NULL; END IF;
    FOREACH f IN ARRAY string_to_array(stg_control.fn_param('DATE_FORMATS'), '|') LOOP
        BEGIN
            ts := to_timestamp(v, f)::timestamp;
            IF ts BETWEEN '1990-01-01' AND now() + interval '20 years' THEN
                RETURN ts AT TIME ZONE stg_control.fn_param('SOURCE_TIMEZONE');
            END IF;
        EXCEPTION WHEN others THEN NULL;
        END;
    END LOOP;
    RETURN NULL;   -- sp_validate registra WARNING cuando origen no vacío y destino NULL
END;
$$;

CREATE OR REPLACE FUNCTION stg_control.fn_to_date(p text)
RETURNS date LANGUAGE sql STABLE PARALLEL SAFE AS
$$ SELECT (stg_control.fn_to_timestamptz(p) AT TIME ZONE stg_control.fn_param('SOURCE_TIMEZONE'))::date $$;

CREATE OR REPLACE FUNCTION stg_control.fn_make_date(p_year text, p_month text, p_day text)
RETURNS date LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE AS
$$
BEGIN
    RETURN make_date(btrim(p_year)::int, btrim(p_month)::int, btrim(p_day)::int);
EXCEPTION WHEN others THEN
    RETURN NULL;
END;
$$;

-- ---------- Homologación (stg_control.map_catalog) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_map_code(p_catalog text, p_source_db text, p_value text)
RETURNS text LANGUAGE sql STABLE PARALLEL SAFE AS
$$ SELECT coalesce(
          (SELECT target_code FROM stg_control.map_catalog
            WHERE catalog_type = p_catalog AND source_db IN (p_source_db, '*') AND source_value = coalesce(btrim(p_value), '')
            ORDER BY (source_db = p_source_db) DESC LIMIT 1),
          CASE WHEN nullif(btrim(p_value), '') IS NOT NULL THEN 'UNMAPPED:' || btrim(p_value) END) $$;
-- 'UNMAPPED:<valor>' se detecta en sp_validate (regla VAL_CATALOG_UNMAPPED). No se pierde el valor original.

CREATE OR REPLACE FUNCTION stg_control.fn_map_id(p_catalog text, p_source_db text, p_value text)
RETURNS uuid LANGUAGE sql STABLE PARALLEL SAFE AS
$$ SELECT target_id FROM stg_control.map_catalog
    WHERE catalog_type = p_catalog AND source_db IN (p_source_db, '*') AND source_value = coalesce(btrim(p_value), '')
    ORDER BY (source_db = p_source_db) DESC LIMIT 1 $$;

-- ---------- Específicas de publicaciones (pendientes de Q07 / proceso de imágenes) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_equipment_present(p text)
RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT coalesce(btrim(p), '') NOT IN ('', '0', 'N', 'n') $$;
-- TODO Q07: reemplazar por la lógica real de usedcars.CheckEquipment / CheckEquipment64 / CheckEquipment128.

CREATE OR REPLACE FUNCTION stg_control.fn_image_s3_key(p_file text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS
$$ SELECT CASE WHEN nullif(btrim(p_file), '') IS NOT NULL
               THEN 'listings/legacy/' || regexp_replace(btrim(p_file), '^.*[\\/]', '') END $$;
-- TODO: confirmar convención de llaves S3 con el equipo del proceso de imágenes.

-- ---------- Bitácora (step_log / error_record) ----------
CREATE OR REPLACE FUNCTION stg_control.fn_step_start(p_run_id bigint, p_step text, p_entity text)
RETURNS bigint LANGUAGE sql AS
$$ INSERT INTO stg_control.step_log (run_id, step_name, entity, status)
   VALUES (p_run_id, p_step, p_entity, 'RUNNING') RETURNING step_id $$;

CREATE OR REPLACE FUNCTION stg_control.fn_step_end(p_step_id bigint, p_in bigint, p_ok bigint,
                                                    p_error bigint, p_warning bigint, p_status text, p_message text)
RETURNS void LANGUAGE sql AS
$$ UPDATE stg_control.step_log
      SET rows_in = p_in, rows_ok = p_ok, rows_error = p_error, rows_warning = p_warning,
          status = p_status, message = p_message, finished_at = now()
    WHERE step_id = p_step_id $$;

CREATE OR REPLACE FUNCTION stg_control.fn_log_error(p_run_id bigint, p_step text, p_entity text,
        p_source_db text, p_source_table text, p_source_pk text, p_rule text, p_severity text,
        p_detail text, p_payload jsonb)
RETURNS void LANGUAGE sql AS
$$ INSERT INTO stg_control.error_record (run_id, step_name, entity, source_db, source_table, source_pk,
                                         rule_code, severity, detail, payload)
   VALUES (p_run_id, p_step, p_entity, p_source_db, p_source_table, p_source_pk,
           p_rule, p_severity, p_detail, p_payload) $$;

-- Reglas técnicas mínimas que usa sp_transform (error_record.rule_code tiene FK a validation_rule)
INSERT INTO stg_control.validation_rule (rule_code, entity, description, severity) VALUES
  ('SP_FAILED', NULL, 'Falla técnica de un procedimiento (ver detail)', 'ERROR'),
  ('VAL_CATALOG_UNMAPPED', NULL, 'Valor de origen sin homologar en map_catalog', 'WARNING'),
  ('VAL_DATE_INVALID', NULL, 'Fecha de origen no vacía que no se pudo convertir', 'WARNING'),
  ('VAL_FK_MISSING', NULL, 'La llave referenciada no existe en la entidad padre', 'ERROR'),
  ('VAL_LISTING_DUP_LIFECYCLE', 'listing', 'Un mismo codigo existe en más de una tabla del ciclo de vida', 'WARNING')
ON CONFLICT (rule_code) DO NOTHING;


-- ===== 20_stg_transform/04_catalogos/brand.sql
-- ======================================================================
-- stg_transform.brand
-- Dominio: Catalogos · Destino final: listings_db.brand
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.brands  →  stg_raw.usedcars__brands
--   - newcars.brands  →  stg_raw.newcars__brands
--   - usedcars.premiumbrands  →  stg_raw.usedcars__premiumbrands
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.brand (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    status                       text,
    video_url                    text,
    expo_status                  text,
    brand_id                     uuid,
    premium_min_year             smallint,
    premium_min_price            numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_brand PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.brand IS 'Origen: usedcars.brands, newcars.brands, usedcars.premiumbrands. Destino: listings_db.brand';
COMMENT ON COLUMN stg_transform.brand.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.brand.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.brand.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.brand.name IS 'Homologado: initcap(trim()); unificar con newcars.brands';
COMMENT ON COLUMN stg_transform.brand.status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_transform.brand.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.brand.expo_status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_transform.brand.brand_id IS 'Por confirmar: Lookup brand por premiumid = usedcars.brands.brandid';
COMMENT ON COLUMN stg_transform.brand.premium_min_year IS 'Transformado: Copiar como regla de marca premium';
COMMENT ON COLUMN stg_transform.brand.premium_min_price IS 'Transformado: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_brand_src ON stg_transform.brand (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_brand_brand_id ON stg_transform.brand (brand_id);


-- ===== 20_stg_transform/04_catalogos/body_style.sql
-- ======================================================================
-- stg_transform.body_style
-- Dominio: Catalogos · Destino final: listings_db.body_style
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.styles  →  stg_raw.usedcars__styles
--   - newcars.styles  →  stg_raw.newcars__styles
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.body_style (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_body_style PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.body_style IS 'Origen: usedcars.styles, newcars.styles. Destino: listings_db.body_style';
COMMENT ON COLUMN stg_transform.body_style.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.body_style.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.body_style.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.body_style.name IS 'Homologado: trim(); unificar con newcars.styles';
CREATE INDEX IF NOT EXISTS ix_transform_body_style_src ON stg_transform.body_style (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/04_catalogos/province.sql
-- ======================================================================
-- stg_transform.province
-- Dominio: Catalogos · Destino final: listings_db.province
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.provinces  →  stg_raw.usedcars__provinces
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.province (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_province PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.province IS 'Origen: usedcars.provinces. Destino: listings_db.province';
COMMENT ON COLUMN stg_transform.province.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.province.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.province.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.province.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_province_src ON stg_transform.province (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/03_publicaciones/equipment.sql
-- ======================================================================
-- stg_transform.equipment
-- Dominio: Publicaciones · Destino final: listings_db.equipment
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.carextras  →  stg_raw.usedcars__carextras
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_equipment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.equipment IS 'Origen: usedcars.carextras. Destino: listings_db.equipment';
COMMENT ON COLUMN stg_transform.equipment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.equipment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.equipment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.equipment.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_equipment_src ON stg_transform.equipment (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/05_accesorios/accessory_section.sql
-- ======================================================================
-- stg_transform.accessory_section
-- Dominio: Accesorios · Destino final: listings_db.accessory_section
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.sections  →  stg_raw.accesorios__sections
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.accessory_section (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_accessory_section PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.accessory_section IS 'Origen: accesorios.sections. Destino: listings_db.accessory_section';
COMMENT ON COLUMN stg_transform.accessory_section.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.accessory_section.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.accessory_section.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.accessory_section.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_accessory_section_src ON stg_transform.accessory_section (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/04_catalogos/model.sql
-- ======================================================================
-- stg_transform.model
-- Dominio: Catalogos · Destino final: listings_db.model
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.models  →  stg_raw.newcars__models
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.model (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    brand_id                     uuid,
    base_model                   text,
    body_style_id                uuid,
    image_prefix                 text,
    year                         smallint,
    price                        numeric(14,2),
    mdescrip                     text,
    motherspecs                  text,
    mmaintext                    text,
    mnumpics                     integer,
    mnumvideos                   integer,
    mequipment                   text,
    mmotor                       text,
    menginesize                  integer,
    mpower                       text,
    mtorque                      text,
    msuspension                  text,
    msteering                    text,
    mtransmission                text,
    mtransmission2               text,
    mbrakes                      text,
    mtires                       text,
    mwarranty                    text,
    mfuel                        text,
    mdrive                       text,
    mfueltank                    text,
    mmaxspeed                    text,
    mvalves                      integer,
    mdoors                       integer,
    is_visible                   boolean,
    mweight                      text,
    mheight                      text,
    mwidth                       text,
    mlength                      text,
    mdiameter                    text,
    mvideo1                      text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_model PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.model IS 'Origen: newcars.models. Destino: listings_db.model';
COMMENT ON COLUMN stg_transform.model.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.model.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.model.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.model.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_transform.model.brand_id IS 'Derivado: Lookup UUID de brand a partir de newcars.brands.brandid';
COMMENT ON COLUMN stg_transform.model.base_model IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de newcars.styles.styleid';
COMMENT ON COLUMN stg_transform.model.image_prefix IS 'Derivado: Enlace con imágenes en S3';
COMMENT ON COLUMN stg_transform.model.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.model.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mdescrip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.motherspecs IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmaintext IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mnumpics IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mnumvideos IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mequipment IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmotor IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.menginesize IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mpower IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtorque IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.msuspension IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.msteering IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtransmission IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtransmission2 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mbrakes IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtires IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mwarranty IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mfuel IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mdrive IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mfueltank IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmaxspeed IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mvalves IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mdoors IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.is_visible IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.model.mweight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mheight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mwidth IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mlength IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mdiameter IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mvideo1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_model_src ON stg_transform.model (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_model_dealer_id ON stg_transform.model (dealer_id);
CREATE INDEX IF NOT EXISTS ix_transform_model_brand_id ON stg_transform.model (brand_id);
CREATE INDEX IF NOT EXISTS ix_transform_model_body_style_id ON stg_transform.model (body_style_id);


-- ===== 20_stg_transform/01_usuarios/app_user.sql
-- ======================================================================
-- stg_transform.app_user
-- Dominio: Usuarios · Destino final: users_db.app_user
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.users  →  stg_raw.micrautos__users
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.app_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    first_name                   text,
    last_name                    text,
    id_type                      text,
    id_number                    text,
    birth_date                   date,
    gender                       text,
    email                        text,
    created_at                   date,
    last_login_at                timestamptz,
    status                       text,
    address_line1                text,
    address_line2                text,
    city                         text,
    country                      text,
    postal_code                  text,
    phone_home                   text,
    phone_work                   text,
    phone_mobile                 text,
    free_ad_flag                 text,
    accepts_email                boolean,
    nickname                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_app_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.app_user IS 'Origen: micrautos.users. Destino: users_db.app_user';
COMMENT ON COLUMN stg_transform.app_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.app_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.app_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.app_user.first_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.last_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_transform.app_user.id_number IS 'Transformado: trim(); quitar guiones y espacios';
COMMENT ON COLUMN stg_transform.app_user.birth_date IS 'Derivado: make_date(uyear, umonth, uday); inválida → NULL + WARNING';
COMMENT ON COLUMN stg_transform.app_user.gender IS 'Homologado: Homologar con stg_control.map_catalog (GENDER)';
COMMENT ON COLUMN stg_transform.app_user.email IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_transform.app_user.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.app_user.last_login_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.app_user.status IS 'Homologado: Homologar con stg_control.map_catalog (USER_STATUS)';
COMMENT ON COLUMN stg_transform.app_user.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.country IS 'Homologado: Homologar con stg_control.map_catalog (COUNTRY)';
COMMENT ON COLUMN stg_transform.app_user.postal_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.app_user.phone_home IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.app_user.phone_work IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.app_user.phone_mobile IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.app_user.free_ad_flag IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.app_user.accepts_email IS 'Transformado: Valores sí/no → boolean';
COMMENT ON COLUMN stg_transform.app_user.nickname IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_app_user_src ON stg_transform.app_user (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/01_usuarios/seller.sql
-- ======================================================================
-- stg_transform.seller
-- Dominio: Usuarios · Destino final: users_db.seller
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.sellers  →  stg_raw.usedcars__sellers
--   - accesorios.sellers  →  stg_raw.accesorios__sellers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.seller (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    phone                        text,
    email                        text,
    start_date                   date,
    expiration_date              date,
    ad_limit                     integer,
    status                       text,
    seller_code                  text,
    plan_amount                  numeric(12,2),
    website                      text,
    plan_amount_usd              numeric(12,2),
    featured_quota               integer,
    department                   text,
    currency                     text,
    address_line1                text,
    address_line2                text,
    province_id                  text,
    city                         text,
    offers_financing             boolean,
    account_balance              numeric(12,2),
    last_deposit_at              timestamptz,
    last_charge_at               timestamptz,
    banner_start_date            date,
    banner_end_date              date,
    is_premium                   boolean,
    video_html                   text,
    whatsapp                     text,
    sales_rep                    text,
    contact_name                 text,
    contact_phone                text,
    contact_email                text,
    phone_2                      text,
    phone_3                      text,
    logo_s3_key                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_seller PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.seller IS 'Origen: usedcars.sellers, accesorios.sellers. Destino: users_db.seller';
COMMENT ON COLUMN stg_transform.seller.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.seller.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.seller.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.seller.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.email IS 'Transformado: lower(trim()); legacy_id = selleremail';
COMMENT ON COLUMN stg_transform.seller.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.expiration_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.ad_limit IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.status IS 'Homologado: Homologar con stg_control.map_catalog (SELLER_STATUS)';
COMMENT ON COLUMN stg_transform.seller.seller_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.plan_amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.plan_amount_usd IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.seller.featured_quota IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.department IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.seller.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.province_id IS 'Homologado: Homologar con stg_control.map_catalog (PROVINCE)';
COMMENT ON COLUMN stg_transform.seller.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.offers_financing IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.seller.account_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.last_deposit_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.seller.last_charge_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.seller.banner_start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.banner_end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.is_premium IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.seller.video_html IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.sales_rep IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.contact_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.seller.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.logo_s3_key IS 'Derivado: Ruta → clave en S3 (proceso de imágenes)';
CREATE INDEX IF NOT EXISTS ix_transform_seller_src ON stg_transform.seller (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/01_usuarios/dealer.sql
-- ======================================================================
-- stg_transform.dealer
-- Dominio: Usuarios · Destino final: users_db.dealer
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.dealers  →  stg_raw.usedcars__dealers
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.dealer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    website                      text,
    email                        text,
    address                      text,
    notes                        text,
    username                     text,
    email_2                      text,
    email_3                      text,
    seller_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_dealer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.dealer IS 'Origen: usedcars.dealers, newcars.dealers. Destino: users_db.dealer';
COMMENT ON COLUMN stg_transform.dealer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.dealer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.dealer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.dealer.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.address IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.username IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.email_2 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.email_3 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.seller_code IS 'Por confirmar: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_dealer_src ON stg_transform.dealer (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/01_usuarios/dealer_contact.sql
-- ======================================================================
-- stg_transform.dealer_contact
-- Dominio: Usuarios · Destino final: users_db.dealer_contact
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.dealer_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    phone                        text,
    phone_label                  text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_dealer_contact PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_transform.dealer_contact.phone IS 'dphoneN normalizado';
COMMENT ON COLUMN stg_transform.dealer_contact.phone_label IS 'dphonerefN';
COMMENT ON COLUMN stg_transform.dealer_contact.sort_order IS 'N del par dphoneN/dphonerefN';
CREATE INDEX IF NOT EXISTS ix_transform_dealer_contact_src ON stg_transform.dealer_contact (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_dealer_contact_dealer_id ON stg_transform.dealer_contact (dealer_id);


-- ===== 20_stg_transform/01_usuarios/admin_user.sql
-- ======================================================================
-- stg_transform.admin_user
-- Dominio: Usuarios · Destino final: users_db.admin_user
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.adminusers  →  stg_raw.usedcars__adminusers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.admin_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    username                     text,
    role                         text,
    full_name                    text,
    phone                        text,
    position                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_admin_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.admin_user IS 'Origen: usedcars.adminusers. Destino: users_db.admin_user';
COMMENT ON COLUMN stg_transform.admin_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.admin_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.admin_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.admin_user.username IS 'Transformado: trim(); legacy_id = userid';
COMMENT ON COLUMN stg_transform.admin_user.role IS 'Homologado: Homologar con stg_control.map_catalog (ADMIN_LEVEL)';
COMMENT ON COLUMN stg_transform.admin_user.full_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.admin_user.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.admin_user.position IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_admin_user_src ON stg_transform.admin_user (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/03_publicaciones/listing.sql
-- ======================================================================
-- stg_transform.listing
-- Dominio: Publicaciones · Destino final: listings_db.listing
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    publication_lifecycle        text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    transfer_cost                numeric(14,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    image_count                  smallint,
    fuel_type                    text,
    ev_range                     numeric(8,1),
    ev_range_unit                text,
    battery_kwh                  numeric(6,1),
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    mileage_unit                 text,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.listing IS 'Origen: usedcars.datafile, usedcars.archive, usedcars.expiredsellers, usedcars.pending, usedcars.pendingpay. Destino: listings_db.listing';
COMMENT ON COLUMN stg_transform.listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.listing.publication_lifecycle IS 'Derivado: Según tabla origen: datafile → ACTIVE · archive → ARCHIVED · expiredsellers → EXPIRED · pending → PENDING_APPROVAL · pendingpay → PENDING_PA';
COMMENT ON COLUMN stg_transform.listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_transform.listing.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_transform.listing.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_transform.listing.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.transfer_cost IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_transform.listing.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_transform.listing.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.image_count IS 'Derivado: Validación: debe coincidir con fotos migradas';
COMMENT ON COLUMN stg_transform.listing.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_transform.listing.ev_range IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.ev_range_unit IS 'Homologado: Homologar con stg_control.map_catalog (RANGE_UNIT)';
COMMENT ON COLUMN stg_transform.listing.battery_kwh IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_transform.listing.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_transform.listing.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing.mileage_unit IS 'Homologado: Homologar con stg_control.map_catalog (MILEAGE_UNIT)';
COMMENT ON COLUMN stg_transform.listing.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_transform.listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_transform.listing.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_transform.listing.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_transform.listing.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.listing.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_transform_listing_src ON stg_transform.listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_dealer_id ON stg_transform.listing (dealer_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_brand_id ON stg_transform.listing (brand_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_body_style_id ON stg_transform.listing (body_style_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_province_id ON stg_transform.listing (province_id);


-- ===== 20_stg_transform/03_publicaciones/listing_transfer.sql
-- ======================================================================
-- stg_transform.listing_transfer
-- Dominio: Publicaciones · Destino final: listings_db.listing_transfer
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing_transfer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    certification                text,
    fuel_type                    text,
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing_transfer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.listing_transfer IS 'Origen: usedcars.archivetraspaso. Destino: listings_db.listing_transfer';
COMMENT ON COLUMN stg_transform.listing_transfer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.listing_transfer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.listing_transfer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.listing_transfer.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_transform.listing_transfer.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_transform.listing_transfer.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing_transfer.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_transform.listing_transfer.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_transform.listing_transfer.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_transform.listing_transfer.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.certification IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_transform.listing_transfer.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_transform.listing_transfer.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_transform.listing_transfer.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_transform.listing_transfer.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing_transfer.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.listing_transfer.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.listing_transfer.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_transform.listing_transfer.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.listing_transfer.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_transform.listing_transfer.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_transform.listing_transfer.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.listing_transfer.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.listing_transfer.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.listing_transfer.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.listing_transfer.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_src ON stg_transform.listing_transfer (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_dealer_id ON stg_transform.listing_transfer (dealer_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_brand_id ON stg_transform.listing_transfer (brand_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_body_style_id ON stg_transform.listing_transfer (body_style_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_transfer_province_id ON stg_transform.listing_transfer (province_id);


-- ===== 20_stg_transform/03_publicaciones/listing_image.sql
-- ======================================================================
-- stg_transform.listing_image
-- Dominio: Publicaciones · Destino final: listings_db.listing_image
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing_image (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    s3_key                       text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing_image PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_transform.listing_image.s3_key IS 'Nombre de archivo origen → clave S3';
COMMENT ON COLUMN stg_transform.listing_image.sort_order IS 'Orden de la foto';
CREATE INDEX IF NOT EXISTS ix_transform_listing_image_src ON stg_transform.listing_image (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_image_listing_id ON stg_transform.listing_image (listing_id);


-- ===== 20_stg_transform/03_publicaciones/listing_equipment.sql
-- ======================================================================
-- stg_transform.listing_equipment
-- Dominio: Publicaciones · Destino final: listings_db.listing_equipment
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing_equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    equipment_id                 uuid,
    feature_slot                 smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing_equipment PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_transform.listing_equipment.feature_slot IS 'Posición f1..f40 en el origen';
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_src ON stg_transform.listing_equipment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_listing_id ON stg_transform.listing_equipment (listing_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_equipment_id ON stg_transform.listing_equipment (equipment_id);


-- ===== 20_stg_transform/03_publicaciones/special_deal.sql
-- ======================================================================
-- stg_transform.special_deal
-- Dominio: Publicaciones · Destino final: listings_db.special_deal
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.specialdeals  →  stg_raw.usedcars__specialdeals
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.special_deal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    deal_date                    date,
    deal_price                   numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_special_deal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.special_deal IS 'Origen: usedcars.specialdeals. Destino: listings_db.special_deal';
COMMENT ON COLUMN stg_transform.special_deal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.special_deal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.special_deal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.special_deal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.special_deal.deal_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.special_deal.deal_price IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_special_deal_src ON stg_transform.special_deal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_special_deal_listing_id ON stg_transform.special_deal (listing_id);


-- ===== 20_stg_transform/03_publicaciones/banner.sql
-- ======================================================================
-- stg_transform.banner
-- Dominio: Publicaciones · Destino final: listings_db.banner
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.mainbanners  →  stg_raw.newcars__mainbanners
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.banner (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    client_name                  text,
    image_s3_key                 text,
    link_url                     text,
    mobile_link_url              text,
    link_target                  text,
    start_date                   date,
    end_date                     date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_banner PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.banner IS 'Origen: newcars.mainbanners. Destino: listings_db.banner';
COMMENT ON COLUMN stg_transform.banner.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.banner.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.banner.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.banner.client_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.image_s3_key IS 'Derivado: Archivo → clave S3';
COMMENT ON COLUMN stg_transform.banner.link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.mobile_link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.link_target IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.banner.end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_transform_banner_src ON stg_transform.banner (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/05_accesorios/accessory_listing.sql
-- ======================================================================
-- stg_transform.accessory_listing
-- Dominio: Accesorios · Destino final: listings_db.accessory_listing
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.archive  →  stg_raw.accesorios__archive
--   - accesorios.pendingpay  →  stg_raw.accesorios__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.accessory_listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    condition_code               text,
    created_at                   timestamptz,
    expires_at                   timestamptz,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    visit_count                  integer,
    image_count                  smallint,
    contact_name                 text,
    contact_email                text,
    phone                        text,
    phone_2                      text,
    phone_3                      text,
    price                        numeric(14,2),
    currency                     text,
    reference_price              numeric(14,2),
    title                        text,
    description                  text,
    section_id                   uuid,
    deleted_at                   date,
    deleted_by                   text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_accessory_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.accessory_listing IS 'Origen: accesorios.archive, accesorios.pendingpay. Destino: listings_db.accessory_listing';
COMMENT ON COLUMN stg_transform.accessory_listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.accessory_listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.accessory_listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.accessory_listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (ACC_ESTADO)';
COMMENT ON COLUMN stg_transform.accessory_listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.accessory_listing.expires_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.accessory_listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.visit_count IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.image_count IS 'Derivado: Validación con imágenes';
COMMENT ON COLUMN stg_transform.accessory_listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.accessory_listing.contact_email IS 'Derivado: lower(trim()); resuelve seller_id (accesorios.sellers)';
COMMENT ON COLUMN stg_transform.accessory_listing.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.accessory_listing.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.accessory_listing.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.accessory_listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.accessory_listing.reference_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.accessory_listing.title IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.accessory_listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.accessory_listing.section_id IS 'Derivado: Lookup UUID de accessory_section a partir de accesorios.sections.sectionid';
COMMENT ON COLUMN stg_transform.accessory_listing.deleted_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.accessory_listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_accessory_listing_src ON stg_transform.accessory_listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_accessory_listing_section_id ON stg_transform.accessory_listing (section_id);


-- ===== 20_stg_transform/01_usuarios/user_favorite.sql
-- ======================================================================
-- stg_transform.user_favorite
-- Dominio: Usuarios · Destino final: users_db.user_favorite
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.favorites  →  stg_raw.micrautos__favorites
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_favorite (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    favorite_type                text,
    created_at                   timestamptz,
    notes                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_favorite PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_favorite IS 'Origen: micrautos.favorites. Destino: users_db.user_favorite';
COMMENT ON COLUMN stg_transform.user_favorite.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_favorite.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_favorite.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_favorite.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_favorite.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.user_favorite.favorite_type IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.user_favorite.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_favorite.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_src ON stg_transform.user_favorite (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_user_id ON stg_transform.user_favorite (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_listing_id ON stg_transform.user_favorite (listing_id);


-- ===== 20_stg_transform/01_usuarios/user_friend.sql
-- ======================================================================
-- stg_transform.user_friend
-- Dominio: Usuarios · Destino final: users_db.user_friend
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.friends  →  stg_raw.micrautos__friends
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_friend (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    friend_user_id               uuid,
    created_at                   date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_friend PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_friend IS 'Origen: micrautos.friends. Destino: users_db.user_friend';
COMMENT ON COLUMN stg_transform.user_friend.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_friend.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_friend.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_friend.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_friend.friend_user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_friend.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_src ON stg_transform.user_friend (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_user_id ON stg_transform.user_friend (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_friend_user_id ON stg_transform.user_friend (friend_user_id);


-- ===== 20_stg_transform/01_usuarios/user_request.sql
-- ======================================================================
-- stg_transform.user_request
-- Dominio: Usuarios · Destino final: users_db.user_request
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.requests  →  stg_raw.micrautos__requests
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_request (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    dealer_id                    uuid,
    request_type                 text,
    attributes                   jsonb,
    message                      text,
    created_at                   timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_request PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_request IS 'Origen: micrautos.requests. Destino: users_db.user_request';
COMMENT ON COLUMN stg_transform.user_request.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_request.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_request.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_request.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_request.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_transform.user_request.request_type IS 'Homologado: Homologar con stg_control.map_catalog (REQUEST_TYPE)';
COMMENT ON COLUMN stg_transform.user_request.attributes IS 'Derivado: jsonb_build_object(''var1'',var1,''var2'',var2,''var3'',var3)';
COMMENT ON COLUMN stg_transform.user_request.message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_request.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
CREATE INDEX IF NOT EXISTS ix_transform_user_request_src ON stg_transform.user_request (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_request_user_id ON stg_transform.user_request (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_request_dealer_id ON stg_transform.user_request (dealer_id);


-- ===== 20_stg_transform/01_usuarios/user_suggestion.sql
-- ======================================================================
-- stg_transform.user_suggestion
-- Dominio: Usuarios · Destino final: users_db.user_suggestion
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.suggestions  →  stg_raw.micrautos__suggestions
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_suggestion (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    created_at                   timestamptz,
    suggestion_text              text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_suggestion PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_suggestion IS 'Origen: micrautos.suggestions. Destino: users_db.user_suggestion';
COMMENT ON COLUMN stg_transform.user_suggestion.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_suggestion.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_suggestion.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_suggestion.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_suggestion.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_suggestion.suggestion_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_suggestion_src ON stg_transform.user_suggestion (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_suggestion_user_id ON stg_transform.user_suggestion (user_id);


-- ===== 20_stg_transform/01_usuarios/user_report.sql
-- ======================================================================
-- stg_transform.user_report
-- Dominio: Usuarios · Destino final: users_db.user_report
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.userreports  →  stg_raw.micrautos__userreports
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_report (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    created_at                   timestamptz,
    report_text                  text,
    action_taken                 text,
    status                       text,
    report_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_report PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_report IS 'Origen: micrautos.userreports. Destino: users_db.user_report';
COMMENT ON COLUMN stg_transform.user_report.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_report.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_report.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_report.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_report.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.user_report.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_report.report_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_report.action_taken IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_report.status IS 'Homologado: Homologar con stg_control.map_catalog (REPORT_STATUS)';
COMMENT ON COLUMN stg_transform.user_report.report_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_report_src ON stg_transform.user_report (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_report_user_id ON stg_transform.user_report (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_report_listing_id ON stg_transform.user_report (listing_id);


-- ===== 20_stg_transform/02_seguridad/blocked_contact.sql
-- ======================================================================
-- stg_transform.blocked_contact
-- Dominio: Seguridad · Destino final: users_db.blocked_contact
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.blocked  →  stg_raw.usedcars__blocked
--   - usedcars.blockedemails  →  stg_raw.usedcars__blockedemails
--   - usedcars.blockedips  →  stg_raw.usedcars__blockedips
--   - usedcars.blockedphones  →  stg_raw.usedcars__blockedphones
--   - usedcars.correosfraude  →  stg_raw.usedcars__correosfraude
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.blocked_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    blockedid                    text,
    blockedname                  text,
    blockedemail                 text,
    ip                           text,
    reason                       text,
    blockedphone                 text,
    codigo                       text,
    emailaddr                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_blocked_contact PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.blocked_contact IS 'Origen: usedcars.blocked, usedcars.blockedemails, usedcars.blockedips, usedcars.blockedphones, usedcars.correosfraude. Destino: users_db.blocked_contact';
COMMENT ON COLUMN stg_transform.blocked_contact.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.blocked_contact.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.blocked_contact.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedid IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedemail IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_transform.blocked_contact.ip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.reason IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedphone IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.codigo IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.emailaddr IS 'Transformado: lower(trim())';
CREATE INDEX IF NOT EXISTS ix_transform_blocked_contact_src ON stg_transform.blocked_contact (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/02_seguridad/ip_allowlist.sql
-- ======================================================================
-- stg_transform.ip_allowlist
-- Dominio: Seguridad · Destino final: users_db.ip_allowlist
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.ipsaccepted  →  stg_raw.usedcars__ipsaccepted
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.ip_allowlist (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    aip                          text,
    alocation                    text,
    actry                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_ip_allowlist PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.ip_allowlist IS 'Origen: usedcars.ipsaccepted. Destino: users_db.ip_allowlist';
COMMENT ON COLUMN stg_transform.ip_allowlist.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.ip_allowlist.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.ip_allowlist.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.ip_allowlist.aip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.ip_allowlist.alocation IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.ip_allowlist.actry IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_ip_allowlist_src ON stg_transform.ip_allowlist (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/02_seguridad/system_parameter.sql
-- ======================================================================
-- stg_transform.system_parameter
-- Dominio: Seguridad · Destino final: users_db.system_parameter
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.parameters  →  stg_raw.usedcars__parameters
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.system_parameter (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    parname                      text,
    parvalue1                    text,
    parvalue2                    numeric(10,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_system_parameter PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.system_parameter IS 'Origen: usedcars.parameters. Destino: users_db.system_parameter';
COMMENT ON COLUMN stg_transform.system_parameter.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.system_parameter.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.system_parameter.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.system_parameter.parname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.system_parameter.parvalue1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.system_parameter.parvalue2 IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_system_parameter_src ON stg_transform.system_parameter (_source_db, _source_table, _source_pk);


-- ===== 20_stg_transform/06_pagos/payment.sql
-- ======================================================================
-- stg_transform.payment
-- Dominio: Pagos · Destino final: payments_db.payment
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.charges  →  stg_raw.usedcars__charges
--   - accesorios.charges  →  stg_raw.accesorios__charges
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.payment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    channel                      text,
    paid_at                      timestamptz,
    amount                       numeric(12,2),
    service_code                 text,
    cardholder_name              text,
    card_brand                   text,
    card_last4                   char(4),
    authorization_code           text,
    gateway_response             jsonb,
    invoice_name                 text,
    invoice_email                text,
    invoice_id_type              text,
    invoice_id_number            text,
    einvoice_key                 text,
    einvoice_message             text,
    einvoice_status              text,
    invoice_number               text,
    gateway_payload              jsonb,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_payment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.payment IS 'Origen: usedcars.charges, accesorios.charges. Destino: payments_db.payment';
COMMENT ON COLUMN stg_transform.payment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.payment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.payment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.payment.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.payment.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.channel IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_SOURCE)';
COMMENT ON COLUMN stg_transform.payment.paid_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.payment.amount IS 'Directo: Copiar (nunca float)';
COMMENT ON COLUMN stg_transform.payment.service_code IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_FEATURE)';
COMMENT ON COLUMN stg_transform.payment.cardholder_name IS 'Transformado: trim()';
COMMENT ON COLUMN stg_transform.payment.card_brand IS 'Homologado: Homologar con stg_control.map_catalog (CARD_BRAND)';
COMMENT ON COLUMN stg_transform.payment.card_last4 IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment.authorization_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.gateway_response IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
COMMENT ON COLUMN stg_transform.payment.invoice_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.invoice_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.payment.invoice_id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_transform.payment.invoice_id_number IS 'Transformado: trim()';
COMMENT ON COLUMN stg_transform.payment.einvoice_key IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment.einvoice_message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment.einvoice_status IS 'Homologado: Homologar con stg_control.map_catalog (EINVOICE_STATUS)';
COMMENT ON COLUMN stg_transform.payment.invoice_number IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment.gateway_payload IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
CREATE INDEX IF NOT EXISTS ix_transform_payment_src ON stg_transform.payment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_payment_listing_id ON stg_transform.payment (listing_id);


-- ===== 20_stg_transform/06_pagos/payment_log.sql
-- ======================================================================
-- stg_transform.payment_log
-- Dominio: Pagos · Destino final: payments_db.payment_log
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.chargeslog  →  stg_raw.usedcars__chargeslog
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.payment_log (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    attempted_at                 timestamptz,
    amount                       numeric(12,2),
    order_reference              text,
    gateway_response_code        text,
    avs_result                   text,
    cvv_result                   text,
    response_time                text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_payment_log PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.payment_log IS 'Origen: usedcars.chargeslog. Destino: payments_db.payment_log';
COMMENT ON COLUMN stg_transform.payment_log.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.payment_log.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.payment_log.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.payment_log.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.payment_log.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.attempted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.payment_log.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.payment_log.order_reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.gateway_response_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.avs_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.cvv_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.payment_log.response_time IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_payment_log_src ON stg_transform.payment_log (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_payment_log_listing_id ON stg_transform.payment_log (listing_id);


-- ===== 20_stg_transform/06_pagos/prepayment.sql
-- ======================================================================
-- stg_transform.prepayment
-- Dominio: Pagos · Destino final: payments_db.prepayment
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.prepay  →  stg_raw.usedcars__prepay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.prepayment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    performed_by                 text,
    seller_id                    uuid,
    movement_type                text,
    movement_at                  timestamptz,
    amount                       numeric(12,2),
    detail                       text,
    comment                      text,
    previous_balance             numeric(12,2),
    new_balance                  numeric(12,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_prepayment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.prepayment IS 'Origen: usedcars.prepay. Destino: payments_db.prepayment';
COMMENT ON COLUMN stg_transform.prepayment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.prepayment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.prepayment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.prepayment.performed_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.prepayment.seller_id IS 'Derivado: Lookup UUID de seller a partir de sellers.sellercode';
COMMENT ON COLUMN stg_transform.prepayment.movement_type IS 'Homologado: Homologar con stg_control.map_catalog (PREPAY_TYPE)';
COMMENT ON COLUMN stg_transform.prepayment.movement_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.prepayment.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.prepayment.detail IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.prepayment.comment IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.prepayment.previous_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.prepayment.new_balance IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_prepayment_src ON stg_transform.prepayment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_prepayment_seller_id ON stg_transform.prepayment (seller_id);


-- ===== 20_stg_transform/06_pagos/coupon.sql
-- ======================================================================
-- stg_transform.coupon
-- Dominio: Pagos · Destino final: payments_db.coupon
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.coupons  →  stg_raw.usedcars__coupons
--   - accesorios.coupons  →  stg_raw.accesorios__coupons
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.coupon (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    code                         text,
    valid_from                   date,
    valid_to                     date,
    used_at                      date,
    listing_id                   uuid,
    coupon_type                  text,
    reference                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_coupon PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.coupon IS 'Origen: usedcars.coupons, accesorios.coupons. Destino: payments_db.coupon';
COMMENT ON COLUMN stg_transform.coupon.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.coupon.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.coupon.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.coupon.code IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_transform.coupon.valid_from IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.valid_to IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.used_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.coupon.coupon_type IS 'Homologado: Homologar con stg_control.map_catalog (COUPON_TYPE)';
COMMENT ON COLUMN stg_transform.coupon.reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_coupon_src ON stg_transform.coupon (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_coupon_listing_id ON stg_transform.coupon (listing_id);


-- ===== 20_stg_transform/06_pagos/auto_renewal.sql
-- ======================================================================
-- stg_transform.auto_renewal
-- Dominio: Pagos · Destino final: payments_db.auto_renewal
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.autorenewhl  →  stg_raw.usedcars__autorenewhl
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.auto_renewal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    created_at                   timestamptz,
    renew_at                     timestamptz,
    listing_id                   uuid,
    last_run_at                  timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_auto_renewal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.auto_renewal IS 'Origen: usedcars.autorenewhl. Destino: payments_db.auto_renewal';
COMMENT ON COLUMN stg_transform.auto_renewal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.auto_renewal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.auto_renewal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.auto_renewal.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.auto_renewal.renew_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.auto_renewal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.auto_renewal.last_run_at IS 'Transformado: Contiene fechas (''AAAA/MM/DD HH:MI''), no estados → convertir a fecha';
CREATE INDEX IF NOT EXISTS ix_transform_auto_renewal_src ON stg_transform.auto_renewal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_auto_renewal_listing_id ON stg_transform.auto_renewal (listing_id);


-- ===== 20_stg_transform/06_pagos/einvoice_document.sql
-- ======================================================================
-- stg_transform.einvoice_document
-- Dominio: Pagos · Destino final: payments_db.einvoice_document
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.tdtickets  →  stg_raw.usedcars__tdtickets
--   - usedcars.mttdtickets  →  stg_raw.usedcars__mttdtickets
--   - usedcars.tdinvoices  →  stg_raw.usedcars__tdinvoices
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.einvoice_document (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    document_number              text,
    einvoice_key                 text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_einvoice_document PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.einvoice_document IS 'Origen: usedcars.tdtickets, usedcars.mttdtickets, usedcars.tdinvoices. Destino: payments_db.einvoice_document';
COMMENT ON COLUMN stg_transform.einvoice_document.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.einvoice_document.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.einvoice_document.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.einvoice_document.document_number IS 'Transformado: Copiar; document_type = ''TICKET''';
COMMENT ON COLUMN stg_transform.einvoice_document.einvoice_key IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_einvoice_document_src ON stg_transform.einvoice_document (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/04_catalogos/brand.sql
-- ======================================================================
-- stg_validated.brand
-- Dominio: Catalogos · Destino final: listings_db.brand
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.brands  →  stg_raw.usedcars__brands
--   - newcars.brands  →  stg_raw.newcars__brands
--   - usedcars.premiumbrands  →  stg_raw.usedcars__premiumbrands
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.brand (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    status                       text,
    video_url                    text,
    expo_status                  text,
    brand_id                     uuid,
    premium_min_year             smallint,
    premium_min_price            numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_brand PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.brand IS 'Origen: usedcars.brands, newcars.brands, usedcars.premiumbrands. Destino: listings_db.brand';
COMMENT ON COLUMN stg_validated.brand.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.brand.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.brand.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.brand.name IS 'Homologado: initcap(trim()); unificar con newcars.brands';
COMMENT ON COLUMN stg_validated.brand.status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_validated.brand.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.brand.expo_status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_validated.brand.brand_id IS 'Por confirmar: Lookup brand por premiumid = usedcars.brands.brandid';
COMMENT ON COLUMN stg_validated.brand.premium_min_year IS 'Transformado: Copiar como regla de marca premium';
COMMENT ON COLUMN stg_validated.brand.premium_min_price IS 'Transformado: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_brand_src ON stg_validated.brand (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_brand_brand_id ON stg_validated.brand (brand_id);


-- ===== 30_stg_validated/04_catalogos/body_style.sql
-- ======================================================================
-- stg_validated.body_style
-- Dominio: Catalogos · Destino final: listings_db.body_style
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.styles  →  stg_raw.usedcars__styles
--   - newcars.styles  →  stg_raw.newcars__styles
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.body_style (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_body_style PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.body_style IS 'Origen: usedcars.styles, newcars.styles. Destino: listings_db.body_style';
COMMENT ON COLUMN stg_validated.body_style.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.body_style.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.body_style.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.body_style.name IS 'Homologado: trim(); unificar con newcars.styles';
CREATE INDEX IF NOT EXISTS ix_validated_body_style_src ON stg_validated.body_style (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/04_catalogos/province.sql
-- ======================================================================
-- stg_validated.province
-- Dominio: Catalogos · Destino final: listings_db.province
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.provinces  →  stg_raw.usedcars__provinces
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.province (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_province PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.province IS 'Origen: usedcars.provinces. Destino: listings_db.province';
COMMENT ON COLUMN stg_validated.province.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.province.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.province.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.province.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_province_src ON stg_validated.province (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/03_publicaciones/equipment.sql
-- ======================================================================
-- stg_validated.equipment
-- Dominio: Publicaciones · Destino final: listings_db.equipment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.carextras  →  stg_raw.usedcars__carextras
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_equipment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.equipment IS 'Origen: usedcars.carextras. Destino: listings_db.equipment';
COMMENT ON COLUMN stg_validated.equipment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.equipment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.equipment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.equipment.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_equipment_src ON stg_validated.equipment (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/05_accesorios/accessory_section.sql
-- ======================================================================
-- stg_validated.accessory_section
-- Dominio: Accesorios · Destino final: listings_db.accessory_section
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.sections  →  stg_raw.accesorios__sections
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.accessory_section (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_accessory_section PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.accessory_section IS 'Origen: accesorios.sections. Destino: listings_db.accessory_section';
COMMENT ON COLUMN stg_validated.accessory_section.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.accessory_section.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.accessory_section.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.accessory_section.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_accessory_section_src ON stg_validated.accessory_section (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/04_catalogos/model.sql
-- ======================================================================
-- stg_validated.model
-- Dominio: Catalogos · Destino final: listings_db.model
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.models  →  stg_raw.newcars__models
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.model (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    brand_id                     uuid,
    base_model                   text,
    body_style_id                uuid,
    image_prefix                 text,
    year                         smallint,
    price                        numeric(14,2),
    mdescrip                     text,
    motherspecs                  text,
    mmaintext                    text,
    mnumpics                     integer,
    mnumvideos                   integer,
    mequipment                   text,
    mmotor                       text,
    menginesize                  integer,
    mpower                       text,
    mtorque                      text,
    msuspension                  text,
    msteering                    text,
    mtransmission                text,
    mtransmission2               text,
    mbrakes                      text,
    mtires                       text,
    mwarranty                    text,
    mfuel                        text,
    mdrive                       text,
    mfueltank                    text,
    mmaxspeed                    text,
    mvalves                      integer,
    mdoors                       integer,
    is_visible                   boolean,
    mweight                      text,
    mheight                      text,
    mwidth                       text,
    mlength                      text,
    mdiameter                    text,
    mvideo1                      text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_model PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.model IS 'Origen: newcars.models. Destino: listings_db.model';
COMMENT ON COLUMN stg_validated.model.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.model.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.model.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.model.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_validated.model.brand_id IS 'Derivado: Lookup UUID de brand a partir de newcars.brands.brandid';
COMMENT ON COLUMN stg_validated.model.base_model IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de newcars.styles.styleid';
COMMENT ON COLUMN stg_validated.model.image_prefix IS 'Derivado: Enlace con imágenes en S3';
COMMENT ON COLUMN stg_validated.model.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.model.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mdescrip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.motherspecs IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmaintext IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mnumpics IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mnumvideos IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mequipment IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmotor IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.menginesize IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mpower IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtorque IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.msuspension IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.msteering IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtransmission IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtransmission2 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mbrakes IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtires IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mwarranty IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mfuel IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mdrive IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mfueltank IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmaxspeed IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mvalves IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mdoors IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.is_visible IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.model.mweight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mheight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mwidth IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mlength IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mdiameter IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mvideo1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_model_src ON stg_validated.model (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_model_dealer_id ON stg_validated.model (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_model_brand_id ON stg_validated.model (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_model_body_style_id ON stg_validated.model (body_style_id);


-- ===== 30_stg_validated/01_usuarios/app_user.sql
-- ======================================================================
-- stg_validated.app_user
-- Dominio: Usuarios · Destino final: users_db.app_user
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.users  →  stg_raw.micrautos__users
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.app_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    first_name                   text,
    last_name                    text,
    id_type                      text,
    id_number                    text,
    birth_date                   date,
    gender                       text,
    email                        text,
    created_at                   date,
    last_login_at                timestamptz,
    status                       text,
    address_line1                text,
    address_line2                text,
    city                         text,
    country                      text,
    postal_code                  text,
    phone_home                   text,
    phone_work                   text,
    phone_mobile                 text,
    free_ad_flag                 text,
    accepts_email                boolean,
    nickname                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_app_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.app_user IS 'Origen: micrautos.users. Destino: users_db.app_user';
COMMENT ON COLUMN stg_validated.app_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.app_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.app_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.app_user.first_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.last_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_validated.app_user.id_number IS 'Transformado: trim(); quitar guiones y espacios';
COMMENT ON COLUMN stg_validated.app_user.birth_date IS 'Derivado: make_date(uyear, umonth, uday); inválida → NULL + WARNING';
COMMENT ON COLUMN stg_validated.app_user.gender IS 'Homologado: Homologar con stg_control.map_catalog (GENDER)';
COMMENT ON COLUMN stg_validated.app_user.email IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_validated.app_user.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.app_user.last_login_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.app_user.status IS 'Homologado: Homologar con stg_control.map_catalog (USER_STATUS)';
COMMENT ON COLUMN stg_validated.app_user.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.country IS 'Homologado: Homologar con stg_control.map_catalog (COUNTRY)';
COMMENT ON COLUMN stg_validated.app_user.postal_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.phone_home IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.phone_work IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.phone_mobile IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.free_ad_flag IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.app_user.accepts_email IS 'Transformado: Valores sí/no → boolean';
COMMENT ON COLUMN stg_validated.app_user.nickname IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_app_user_src ON stg_validated.app_user (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/01_usuarios/seller.sql
-- ======================================================================
-- stg_validated.seller
-- Dominio: Usuarios · Destino final: users_db.seller
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.sellers  →  stg_raw.usedcars__sellers
--   - accesorios.sellers  →  stg_raw.accesorios__sellers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.seller (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    phone                        text,
    email                        text,
    start_date                   date,
    expiration_date              date,
    ad_limit                     integer,
    status                       text,
    seller_code                  text,
    plan_amount                  numeric(12,2),
    website                      text,
    plan_amount_usd              numeric(12,2),
    featured_quota               integer,
    department                   text,
    currency                     text,
    address_line1                text,
    address_line2                text,
    province_id                  text,
    city                         text,
    offers_financing             boolean,
    account_balance              numeric(12,2),
    last_deposit_at              timestamptz,
    last_charge_at               timestamptz,
    banner_start_date            date,
    banner_end_date              date,
    is_premium                   boolean,
    video_html                   text,
    whatsapp                     text,
    sales_rep                    text,
    contact_name                 text,
    contact_phone                text,
    contact_email                text,
    phone_2                      text,
    phone_3                      text,
    logo_s3_key                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_seller PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.seller IS 'Origen: usedcars.sellers, accesorios.sellers. Destino: users_db.seller';
COMMENT ON COLUMN stg_validated.seller.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.seller.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.seller.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.seller.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.email IS 'Transformado: lower(trim()); legacy_id = selleremail';
COMMENT ON COLUMN stg_validated.seller.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.expiration_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.ad_limit IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.status IS 'Homologado: Homologar con stg_control.map_catalog (SELLER_STATUS)';
COMMENT ON COLUMN stg_validated.seller.seller_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.plan_amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.plan_amount_usd IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.seller.featured_quota IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.department IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.seller.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.province_id IS 'Homologado: Homologar con stg_control.map_catalog (PROVINCE)';
COMMENT ON COLUMN stg_validated.seller.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.offers_financing IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.seller.account_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.last_deposit_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.seller.last_charge_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.seller.banner_start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.banner_end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.is_premium IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.seller.video_html IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.sales_rep IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.contact_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.seller.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.logo_s3_key IS 'Derivado: Ruta → clave en S3 (proceso de imágenes)';
CREATE INDEX IF NOT EXISTS ix_validated_seller_src ON stg_validated.seller (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/01_usuarios/dealer.sql
-- ======================================================================
-- stg_validated.dealer
-- Dominio: Usuarios · Destino final: users_db.dealer
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.dealers  →  stg_raw.usedcars__dealers
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.dealer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    website                      text,
    email                        text,
    address                      text,
    notes                        text,
    username                     text,
    email_2                      text,
    email_3                      text,
    seller_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_dealer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.dealer IS 'Origen: usedcars.dealers, newcars.dealers. Destino: users_db.dealer';
COMMENT ON COLUMN stg_validated.dealer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.dealer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.dealer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.dealer.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.dealer.address IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.username IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.email_2 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.dealer.email_3 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.dealer.seller_code IS 'Por confirmar: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_dealer_src ON stg_validated.dealer (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/01_usuarios/dealer_contact.sql
-- ======================================================================
-- stg_validated.dealer_contact
-- Dominio: Usuarios · Destino final: users_db.dealer_contact
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.dealer_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    phone                        text,
    phone_label                  text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_dealer_contact PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.dealer_contact.phone IS 'dphoneN normalizado';
COMMENT ON COLUMN stg_validated.dealer_contact.phone_label IS 'dphonerefN';
COMMENT ON COLUMN stg_validated.dealer_contact.sort_order IS 'N del par dphoneN/dphonerefN';
CREATE INDEX IF NOT EXISTS ix_validated_dealer_contact_src ON stg_validated.dealer_contact (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_dealer_contact_dealer_id ON stg_validated.dealer_contact (dealer_id);


-- ===== 30_stg_validated/01_usuarios/admin_user.sql
-- ======================================================================
-- stg_validated.admin_user
-- Dominio: Usuarios · Destino final: users_db.admin_user
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.adminusers  →  stg_raw.usedcars__adminusers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.admin_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    username                     text,
    role                         text,
    full_name                    text,
    phone                        text,
    position                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_admin_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.admin_user IS 'Origen: usedcars.adminusers. Destino: users_db.admin_user';
COMMENT ON COLUMN stg_validated.admin_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.admin_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.admin_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.admin_user.username IS 'Transformado: trim(); legacy_id = userid';
COMMENT ON COLUMN stg_validated.admin_user.role IS 'Homologado: Homologar con stg_control.map_catalog (ADMIN_LEVEL)';
COMMENT ON COLUMN stg_validated.admin_user.full_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.admin_user.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.admin_user.position IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_admin_user_src ON stg_validated.admin_user (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/03_publicaciones/listing.sql
-- ======================================================================
-- stg_validated.listing
-- Dominio: Publicaciones · Destino final: listings_db.listing
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    publication_lifecycle        text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    transfer_cost                numeric(14,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    image_count                  smallint,
    fuel_type                    text,
    ev_range                     numeric(8,1),
    ev_range_unit                text,
    battery_kwh                  numeric(6,1),
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    mileage_unit                 text,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.listing IS 'Origen: usedcars.datafile, usedcars.archive, usedcars.expiredsellers, usedcars.pending, usedcars.pendingpay. Destino: listings_db.listing';
COMMENT ON COLUMN stg_validated.listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.listing.publication_lifecycle IS 'Derivado: Según tabla origen: datafile → ACTIVE · archive → ARCHIVED · expiredsellers → EXPIRED · pending → PENDING_APPROVAL · pendingpay → PENDING_PA';
COMMENT ON COLUMN stg_validated.listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_validated.listing.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_validated.listing.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_validated.listing.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.transfer_cost IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_validated.listing.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_validated.listing.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.image_count IS 'Derivado: Validación: debe coincidir con fotos migradas';
COMMENT ON COLUMN stg_validated.listing.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_validated.listing.ev_range IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.ev_range_unit IS 'Homologado: Homologar con stg_control.map_catalog (RANGE_UNIT)';
COMMENT ON COLUMN stg_validated.listing.battery_kwh IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_validated.listing.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_validated.listing.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.mileage_unit IS 'Homologado: Homologar con stg_control.map_catalog (MILEAGE_UNIT)';
COMMENT ON COLUMN stg_validated.listing.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_validated.listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_validated.listing.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_validated.listing.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_validated.listing.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.listing.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_validated_listing_src ON stg_validated.listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_dealer_id ON stg_validated.listing (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_brand_id ON stg_validated.listing (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_body_style_id ON stg_validated.listing (body_style_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_province_id ON stg_validated.listing (province_id);


-- ===== 30_stg_validated/03_publicaciones/listing_transfer.sql
-- ======================================================================
-- stg_validated.listing_transfer
-- Dominio: Publicaciones · Destino final: listings_db.listing_transfer
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing_transfer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    certification                text,
    fuel_type                    text,
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing_transfer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.listing_transfer IS 'Origen: usedcars.archivetraspaso. Destino: listings_db.listing_transfer';
COMMENT ON COLUMN stg_validated.listing_transfer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.listing_transfer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.listing_transfer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.listing_transfer.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_validated.listing_transfer.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_validated.listing_transfer.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing_transfer.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_validated.listing_transfer.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_validated.listing_transfer.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_validated.listing_transfer.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.certification IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_validated.listing_transfer.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_validated.listing_transfer.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_validated.listing_transfer.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_validated.listing_transfer.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing_transfer.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.listing_transfer.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_validated.listing_transfer.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing_transfer.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_validated.listing_transfer.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_validated.listing_transfer.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing_transfer.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.listing_transfer.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_src ON stg_validated.listing_transfer (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_dealer_id ON stg_validated.listing_transfer (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_brand_id ON stg_validated.listing_transfer (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_body_style_id ON stg_validated.listing_transfer (body_style_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_province_id ON stg_validated.listing_transfer (province_id);


-- ===== 30_stg_validated/03_publicaciones/listing_image.sql
-- ======================================================================
-- stg_validated.listing_image
-- Dominio: Publicaciones · Destino final: listings_db.listing_image
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing_image (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    s3_key                       text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing_image PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.listing_image.s3_key IS 'Nombre de archivo origen → clave S3';
COMMENT ON COLUMN stg_validated.listing_image.sort_order IS 'Orden de la foto';
CREATE INDEX IF NOT EXISTS ix_validated_listing_image_src ON stg_validated.listing_image (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_image_listing_id ON stg_validated.listing_image (listing_id);


-- ===== 30_stg_validated/03_publicaciones/listing_equipment.sql
-- ======================================================================
-- stg_validated.listing_equipment
-- Dominio: Publicaciones · Destino final: listings_db.listing_equipment
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing_equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    equipment_id                 uuid,
    feature_slot                 smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing_equipment PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.listing_equipment.feature_slot IS 'Posición f1..f40 en el origen';
CREATE INDEX IF NOT EXISTS ix_validated_listing_equipment_src ON stg_validated.listing_equipment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_equipment_listing_id ON stg_validated.listing_equipment (listing_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_equipment_equipment_id ON stg_validated.listing_equipment (equipment_id);


-- ===== 30_stg_validated/03_publicaciones/special_deal.sql
-- ======================================================================
-- stg_validated.special_deal
-- Dominio: Publicaciones · Destino final: listings_db.special_deal
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.specialdeals  →  stg_raw.usedcars__specialdeals
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.special_deal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    deal_date                    date,
    deal_price                   numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_special_deal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.special_deal IS 'Origen: usedcars.specialdeals. Destino: listings_db.special_deal';
COMMENT ON COLUMN stg_validated.special_deal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.special_deal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.special_deal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.special_deal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.special_deal.deal_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.special_deal.deal_price IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_special_deal_src ON stg_validated.special_deal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_special_deal_listing_id ON stg_validated.special_deal (listing_id);


-- ===== 30_stg_validated/03_publicaciones/banner.sql
-- ======================================================================
-- stg_validated.banner
-- Dominio: Publicaciones · Destino final: listings_db.banner
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.mainbanners  →  stg_raw.newcars__mainbanners
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.banner (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    client_name                  text,
    image_s3_key                 text,
    link_url                     text,
    mobile_link_url              text,
    link_target                  text,
    start_date                   date,
    end_date                     date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_banner PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.banner IS 'Origen: newcars.mainbanners. Destino: listings_db.banner';
COMMENT ON COLUMN stg_validated.banner.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.banner.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.banner.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.banner.client_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.image_s3_key IS 'Derivado: Archivo → clave S3';
COMMENT ON COLUMN stg_validated.banner.link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.mobile_link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.link_target IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.banner.end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_validated_banner_src ON stg_validated.banner (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/05_accesorios/accessory_listing.sql
-- ======================================================================
-- stg_validated.accessory_listing
-- Dominio: Accesorios · Destino final: listings_db.accessory_listing
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.archive  →  stg_raw.accesorios__archive
--   - accesorios.pendingpay  →  stg_raw.accesorios__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.accessory_listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    condition_code               text,
    created_at                   timestamptz,
    expires_at                   timestamptz,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    visit_count                  integer,
    image_count                  smallint,
    contact_name                 text,
    contact_email                text,
    phone                        text,
    phone_2                      text,
    phone_3                      text,
    price                        numeric(14,2),
    currency                     text,
    reference_price              numeric(14,2),
    title                        text,
    description                  text,
    section_id                   uuid,
    deleted_at                   date,
    deleted_by                   text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_accessory_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.accessory_listing IS 'Origen: accesorios.archive, accesorios.pendingpay. Destino: listings_db.accessory_listing';
COMMENT ON COLUMN stg_validated.accessory_listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.accessory_listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.accessory_listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.accessory_listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (ACC_ESTADO)';
COMMENT ON COLUMN stg_validated.accessory_listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.accessory_listing.expires_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.accessory_listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.visit_count IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.image_count IS 'Derivado: Validación con imágenes';
COMMENT ON COLUMN stg_validated.accessory_listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.contact_email IS 'Derivado: lower(trim()); resuelve seller_id (accesorios.sellers)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.accessory_listing.reference_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.title IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.section_id IS 'Derivado: Lookup UUID de accessory_section a partir de accesorios.sections.sectionid';
COMMENT ON COLUMN stg_validated.accessory_listing.deleted_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.accessory_listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_accessory_listing_src ON stg_validated.accessory_listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_accessory_listing_section_id ON stg_validated.accessory_listing (section_id);


-- ===== 30_stg_validated/01_usuarios/user_favorite.sql
-- ======================================================================
-- stg_validated.user_favorite
-- Dominio: Usuarios · Destino final: users_db.user_favorite
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.favorites  →  stg_raw.micrautos__favorites
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_favorite (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    favorite_type                text,
    created_at                   timestamptz,
    notes                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_favorite PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_favorite IS 'Origen: micrautos.favorites. Destino: users_db.user_favorite';
COMMENT ON COLUMN stg_validated.user_favorite.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_favorite.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_favorite.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_favorite.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_favorite.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.user_favorite.favorite_type IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.user_favorite.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.user_favorite.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_user_favorite_src ON stg_validated.user_favorite (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_favorite_user_id ON stg_validated.user_favorite (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_favorite_listing_id ON stg_validated.user_favorite (listing_id);


-- ===== 30_stg_validated/01_usuarios/user_friend.sql
-- ======================================================================
-- stg_validated.user_friend
-- Dominio: Usuarios · Destino final: users_db.user_friend
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.friends  →  stg_raw.micrautos__friends
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_friend (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    friend_user_id               uuid,
    created_at                   date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_friend PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_friend IS 'Origen: micrautos.friends. Destino: users_db.user_friend';
COMMENT ON COLUMN stg_validated.user_friend.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_friend.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_friend.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_friend.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_friend.friend_user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_friend.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_validated_user_friend_src ON stg_validated.user_friend (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_friend_user_id ON stg_validated.user_friend (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_friend_friend_user_id ON stg_validated.user_friend (friend_user_id);


-- ===== 30_stg_validated/01_usuarios/user_request.sql
-- ======================================================================
-- stg_validated.user_request
-- Dominio: Usuarios · Destino final: users_db.user_request
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.requests  →  stg_raw.micrautos__requests
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_request (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    dealer_id                    uuid,
    request_type                 text,
    attributes                   jsonb,
    message                      text,
    created_at                   timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_request PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_request IS 'Origen: micrautos.requests. Destino: users_db.user_request';
COMMENT ON COLUMN stg_validated.user_request.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_request.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_request.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_request.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_request.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_validated.user_request.request_type IS 'Homologado: Homologar con stg_control.map_catalog (REQUEST_TYPE)';
COMMENT ON COLUMN stg_validated.user_request.attributes IS 'Derivado: jsonb_build_object(''var1'',var1,''var2'',var2,''var3'',var3)';
COMMENT ON COLUMN stg_validated.user_request.message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.user_request.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
CREATE INDEX IF NOT EXISTS ix_validated_user_request_src ON stg_validated.user_request (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_request_user_id ON stg_validated.user_request (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_request_dealer_id ON stg_validated.user_request (dealer_id);


-- ===== 30_stg_validated/01_usuarios/user_suggestion.sql
-- ======================================================================
-- stg_validated.user_suggestion
-- Dominio: Usuarios · Destino final: users_db.user_suggestion
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.suggestions  →  stg_raw.micrautos__suggestions
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_suggestion (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    created_at                   timestamptz,
    suggestion_text              text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_suggestion PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_suggestion IS 'Origen: micrautos.suggestions. Destino: users_db.user_suggestion';
COMMENT ON COLUMN stg_validated.user_suggestion.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_suggestion.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_suggestion.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_suggestion.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_suggestion.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.user_suggestion.suggestion_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_user_suggestion_src ON stg_validated.user_suggestion (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_suggestion_user_id ON stg_validated.user_suggestion (user_id);


-- ===== 30_stg_validated/01_usuarios/user_report.sql
-- ======================================================================
-- stg_validated.user_report
-- Dominio: Usuarios · Destino final: users_db.user_report
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.userreports  →  stg_raw.micrautos__userreports
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_report (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    created_at                   timestamptz,
    report_text                  text,
    action_taken                 text,
    status                       text,
    report_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_report PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_report IS 'Origen: micrautos.userreports. Destino: users_db.user_report';
COMMENT ON COLUMN stg_validated.user_report.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_report.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_report.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_report.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_report.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.user_report.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.user_report.report_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.user_report.action_taken IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.user_report.status IS 'Homologado: Homologar con stg_control.map_catalog (REPORT_STATUS)';
COMMENT ON COLUMN stg_validated.user_report.report_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_user_report_src ON stg_validated.user_report (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_report_user_id ON stg_validated.user_report (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_report_listing_id ON stg_validated.user_report (listing_id);


-- ===== 30_stg_validated/02_seguridad/blocked_contact.sql
-- ======================================================================
-- stg_validated.blocked_contact
-- Dominio: Seguridad · Destino final: users_db.blocked_contact
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.blocked  →  stg_raw.usedcars__blocked
--   - usedcars.blockedemails  →  stg_raw.usedcars__blockedemails
--   - usedcars.blockedips  →  stg_raw.usedcars__blockedips
--   - usedcars.blockedphones  →  stg_raw.usedcars__blockedphones
--   - usedcars.correosfraude  →  stg_raw.usedcars__correosfraude
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.blocked_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    blockedid                    text,
    blockedname                  text,
    blockedemail                 text,
    ip                           text,
    reason                       text,
    blockedphone                 text,
    codigo                       text,
    emailaddr                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_blocked_contact PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.blocked_contact IS 'Origen: usedcars.blocked, usedcars.blockedemails, usedcars.blockedips, usedcars.blockedphones, usedcars.correosfraude. Destino: users_db.blocked_contact';
COMMENT ON COLUMN stg_validated.blocked_contact.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.blocked_contact.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.blocked_contact.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedid IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedemail IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_validated.blocked_contact.ip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.reason IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedphone IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.codigo IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.emailaddr IS 'Transformado: lower(trim())';
CREATE INDEX IF NOT EXISTS ix_validated_blocked_contact_src ON stg_validated.blocked_contact (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/02_seguridad/ip_allowlist.sql
-- ======================================================================
-- stg_validated.ip_allowlist
-- Dominio: Seguridad · Destino final: users_db.ip_allowlist
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.ipsaccepted  →  stg_raw.usedcars__ipsaccepted
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.ip_allowlist (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    aip                          text,
    alocation                    text,
    actry                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_ip_allowlist PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.ip_allowlist IS 'Origen: usedcars.ipsaccepted. Destino: users_db.ip_allowlist';
COMMENT ON COLUMN stg_validated.ip_allowlist.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.ip_allowlist.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.ip_allowlist.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.ip_allowlist.aip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.ip_allowlist.alocation IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.ip_allowlist.actry IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_ip_allowlist_src ON stg_validated.ip_allowlist (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/02_seguridad/system_parameter.sql
-- ======================================================================
-- stg_validated.system_parameter
-- Dominio: Seguridad · Destino final: users_db.system_parameter
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.parameters  →  stg_raw.usedcars__parameters
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.system_parameter (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    parname                      text,
    parvalue1                    text,
    parvalue2                    numeric(10,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_system_parameter PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.system_parameter IS 'Origen: usedcars.parameters. Destino: users_db.system_parameter';
COMMENT ON COLUMN stg_validated.system_parameter.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.system_parameter.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.system_parameter.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.system_parameter.parname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.system_parameter.parvalue1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.system_parameter.parvalue2 IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_system_parameter_src ON stg_validated.system_parameter (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/06_pagos/payment.sql
-- ======================================================================
-- stg_validated.payment
-- Dominio: Pagos · Destino final: payments_db.payment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.charges  →  stg_raw.usedcars__charges
--   - accesorios.charges  →  stg_raw.accesorios__charges
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.payment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    channel                      text,
    paid_at                      timestamptz,
    amount                       numeric(12,2),
    service_code                 text,
    cardholder_name              text,
    card_brand                   text,
    card_last4                   char(4),
    authorization_code           text,
    gateway_response             jsonb,
    invoice_name                 text,
    invoice_email                text,
    invoice_id_type              text,
    invoice_id_number            text,
    einvoice_key                 text,
    einvoice_message             text,
    einvoice_status              text,
    invoice_number               text,
    gateway_payload              jsonb,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_payment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.payment IS 'Origen: usedcars.charges, accesorios.charges. Destino: payments_db.payment';
COMMENT ON COLUMN stg_validated.payment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.payment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.payment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.payment.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.payment.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.channel IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_SOURCE)';
COMMENT ON COLUMN stg_validated.payment.paid_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.payment.amount IS 'Directo: Copiar (nunca float)';
COMMENT ON COLUMN stg_validated.payment.service_code IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_FEATURE)';
COMMENT ON COLUMN stg_validated.payment.cardholder_name IS 'Transformado: trim()';
COMMENT ON COLUMN stg_validated.payment.card_brand IS 'Homologado: Homologar con stg_control.map_catalog (CARD_BRAND)';
COMMENT ON COLUMN stg_validated.payment.card_last4 IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.authorization_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.gateway_response IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
COMMENT ON COLUMN stg_validated.payment.invoice_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.invoice_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.payment.invoice_id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_validated.payment.invoice_id_number IS 'Transformado: trim()';
COMMENT ON COLUMN stg_validated.payment.einvoice_key IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.einvoice_message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.einvoice_status IS 'Homologado: Homologar con stg_control.map_catalog (EINVOICE_STATUS)';
COMMENT ON COLUMN stg_validated.payment.invoice_number IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.gateway_payload IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
CREATE INDEX IF NOT EXISTS ix_validated_payment_src ON stg_validated.payment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_payment_listing_id ON stg_validated.payment (listing_id);


-- ===== 30_stg_validated/06_pagos/payment_log.sql
-- ======================================================================
-- stg_validated.payment_log
-- Dominio: Pagos · Destino final: payments_db.payment_log
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.chargeslog  →  stg_raw.usedcars__chargeslog
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.payment_log (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    attempted_at                 timestamptz,
    amount                       numeric(12,2),
    order_reference              text,
    gateway_response_code        text,
    avs_result                   text,
    cvv_result                   text,
    response_time                text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_payment_log PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.payment_log IS 'Origen: usedcars.chargeslog. Destino: payments_db.payment_log';
COMMENT ON COLUMN stg_validated.payment_log.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.payment_log.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.payment_log.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.payment_log.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.payment_log.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.attempted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.payment_log.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment_log.order_reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.gateway_response_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.avs_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.cvv_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.response_time IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_payment_log_src ON stg_validated.payment_log (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_payment_log_listing_id ON stg_validated.payment_log (listing_id);


-- ===== 30_stg_validated/06_pagos/prepayment.sql
-- ======================================================================
-- stg_validated.prepayment
-- Dominio: Pagos · Destino final: payments_db.prepayment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.prepay  →  stg_raw.usedcars__prepay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.prepayment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    performed_by                 text,
    seller_id                    uuid,
    movement_type                text,
    movement_at                  timestamptz,
    amount                       numeric(12,2),
    detail                       text,
    comment                      text,
    previous_balance             numeric(12,2),
    new_balance                  numeric(12,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_prepayment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.prepayment IS 'Origen: usedcars.prepay. Destino: payments_db.prepayment';
COMMENT ON COLUMN stg_validated.prepayment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.prepayment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.prepayment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.prepayment.performed_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.seller_id IS 'Derivado: Lookup UUID de seller a partir de sellers.sellercode';
COMMENT ON COLUMN stg_validated.prepayment.movement_type IS 'Homologado: Homologar con stg_control.map_catalog (PREPAY_TYPE)';
COMMENT ON COLUMN stg_validated.prepayment.movement_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.prepayment.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.prepayment.detail IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.comment IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.previous_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.prepayment.new_balance IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_prepayment_src ON stg_validated.prepayment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_prepayment_seller_id ON stg_validated.prepayment (seller_id);


-- ===== 30_stg_validated/06_pagos/coupon.sql
-- ======================================================================
-- stg_validated.coupon
-- Dominio: Pagos · Destino final: payments_db.coupon
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.coupons  →  stg_raw.usedcars__coupons
--   - accesorios.coupons  →  stg_raw.accesorios__coupons
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.coupon (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    code                         text,
    valid_from                   date,
    valid_to                     date,
    used_at                      date,
    listing_id                   uuid,
    coupon_type                  text,
    reference                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_coupon PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.coupon IS 'Origen: usedcars.coupons, accesorios.coupons. Destino: payments_db.coupon';
COMMENT ON COLUMN stg_validated.coupon.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.coupon.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.coupon.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.coupon.code IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_validated.coupon.valid_from IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.coupon.valid_to IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.coupon.used_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.coupon.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.coupon.coupon_type IS 'Homologado: Homologar con stg_control.map_catalog (COUPON_TYPE)';
COMMENT ON COLUMN stg_validated.coupon.reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_coupon_src ON stg_validated.coupon (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_coupon_listing_id ON stg_validated.coupon (listing_id);


-- ===== 30_stg_validated/06_pagos/auto_renewal.sql
-- ======================================================================
-- stg_validated.auto_renewal
-- Dominio: Pagos · Destino final: payments_db.auto_renewal
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.autorenewhl  →  stg_raw.usedcars__autorenewhl
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.auto_renewal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    created_at                   timestamptz,
    renew_at                     timestamptz,
    listing_id                   uuid,
    last_run_at                  timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_auto_renewal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.auto_renewal IS 'Origen: usedcars.autorenewhl. Destino: payments_db.auto_renewal';
COMMENT ON COLUMN stg_validated.auto_renewal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.auto_renewal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.auto_renewal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.auto_renewal.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.auto_renewal.renew_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.auto_renewal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.auto_renewal.last_run_at IS 'Transformado: Contiene fechas (''AAAA/MM/DD HH:MI''), no estados → convertir a fecha';
CREATE INDEX IF NOT EXISTS ix_validated_auto_renewal_src ON stg_validated.auto_renewal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_auto_renewal_listing_id ON stg_validated.auto_renewal (listing_id);


-- ===== 30_stg_validated/06_pagos/einvoice_document.sql
-- ======================================================================
-- stg_validated.einvoice_document
-- Dominio: Pagos · Destino final: payments_db.einvoice_document
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.tdtickets  →  stg_raw.usedcars__tdtickets
--   - usedcars.mttdtickets  →  stg_raw.usedcars__mttdtickets
--   - usedcars.tdinvoices  →  stg_raw.usedcars__tdinvoices
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.einvoice_document (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    document_number              text,
    einvoice_key                 text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_einvoice_document PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.einvoice_document IS 'Origen: usedcars.tdtickets, usedcars.mttdtickets, usedcars.tdinvoices. Destino: payments_db.einvoice_document';
COMMENT ON COLUMN stg_validated.einvoice_document.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.einvoice_document.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.einvoice_document.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.einvoice_document.document_number IS 'Transformado: Copiar; document_type = ''TICKET''';
COMMENT ON COLUMN stg_validated.einvoice_document.einvoice_key IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_einvoice_document_src ON stg_validated.einvoice_document (_source_db, _source_table, _source_pk);


-- ===== 50_sp_transform/04_catalogos/sp_transform_brand.sql
-- ======================================================================
-- stg_transform.sp_transform_brand
-- stg_raw → stg_transform.brand  ·  Destino final: listings_db.brand
-- Lee: stg_raw.usedcars__brands + stg_raw.newcars__brands + stg_raw.usedcars__premiumbrands
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_brand(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_brand(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'brand');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__brands)
        + (SELECT count(*) FROM stg_raw.newcars__brands)
        + (SELECT count(*) FROM stg_raw.usedcars__premiumbrands)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.brands
    SELECT
        stg_control.fn_legacy_uuid('usedcars.brands', r."brandid"::text)       AS id,
        r."brandid"::text                                                      AS legacy_id,
        'usedcars.brands'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."brandname"::text)                         AS name,
        NULL::text                                                             AS status,  -- no viene de usedcars.brands
        NULL::text                                                             AS video_url,  -- no viene de usedcars.brands
        NULL::text                                                             AS expo_status,  -- no viene de usedcars.brands
        NULL::uuid                                                             AS brand_id,  -- no viene de usedcars.brands
        NULL::smallint                                                         AS premium_min_year,  -- no viene de usedcars.brands
        NULL::numeric(14,2)                                                    AS premium_min_price,  -- no viene de usedcars.brands
        'usedcars'::text AS _source_db, 'brands'::text AS _source_table, r."brandid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__brands r
    UNION ALL
    -- ---- newcars.brands
    -- No se migran: branddir
    SELECT
        stg_control.fn_legacy_uuid('newcars.brands', r."brandid"::text)        AS id,
        r."brandid"::text                                                      AS legacy_id,
        'newcars.brands'                                                       AS legacy_source,
        stg_control.fn_clean_text(r."brandname"::text)                         AS name,
        stg_control.fn_map_code('BRAND_STATUS', 'newcars', r."status"::text)   AS status,
        stg_control.fn_clean_text(r."video1"::text)                            AS video_url,
        stg_control.fn_map_code('BRAND_STATUS', 'newcars', r."expostatus"::text) AS expo_status,
        NULL::uuid                                                             AS brand_id,  -- no viene de newcars.brands
        NULL::smallint                                                         AS premium_min_year,  -- no viene de newcars.brands
        NULL::numeric(14,2)                                                    AS premium_min_price,  -- no viene de newcars.brands
        'newcars'::text AS _source_db, 'brands'::text AS _source_table, r."brandid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.newcars__brands r
    UNION ALL
    -- ---- usedcars.premiumbrands
    SELECT
        stg_control.fn_legacy_uuid('usedcars.premiumbrands', r."premiumid"::text) AS id,
        r."premiumid"::text                                                    AS legacy_id,
        'usedcars.premiumbrands'                                               AS legacy_source,
        NULL::text                                                             AS name,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS status,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS video_url,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS expo_status,  -- no viene de usedcars.premiumbrands
        NULL::uuid                                                             AS brand_id,  -- POR CONFIRMAR · TODO: Lookup brand por premiumid = usedcars.brands.brandid
        stg_control.fn_to_int(r."minyear"::text)::smallint                     AS premium_min_year,
        r."minprice"::numeric(14,2)                                            AS premium_min_price,
        'usedcars'::text AS _source_db, 'premiumbrands'::text AS _source_table, r."premiumid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__premiumbrands r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.brand (id, legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        status = EXCLUDED.status,
        video_url = EXCLUDED.video_url,
        expo_status = EXCLUDED.expo_status,
        brand_id = EXCLUDED.brand_id,
        premium_min_year = EXCLUDED.premium_min_year,
        premium_min_price = EXCLUDED.premium_min_price,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.brand._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.brand._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'brand', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_brand(bigint) IS 'stg_raw → stg_transform.brand (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/04_catalogos/sp_transform_body_style.sql
-- ======================================================================
-- stg_transform.sp_transform_body_style
-- stg_raw → stg_transform.body_style  ·  Destino final: listings_db.body_style
-- Lee: stg_raw.usedcars__styles + stg_raw.newcars__styles
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_body_style(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_body_style(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'body_style');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__styles)
        + (SELECT count(*) FROM stg_raw.newcars__styles)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.styles
    SELECT
        stg_control.fn_legacy_uuid('usedcars.styles', r."styleid"::text)       AS id,
        r."styleid"::text                                                      AS legacy_id,
        'usedcars.styles'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."stylename"::text)                         AS name,
        'usedcars'::text AS _source_db, 'styles'::text AS _source_table, r."styleid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__styles r
    UNION ALL
    -- ---- newcars.styles
    SELECT
        stg_control.fn_legacy_uuid('newcars.styles', r."styleid"::text)        AS id,
        r."styleid"::text                                                      AS legacy_id,
        'newcars.styles'                                                       AS legacy_source,
        stg_control.fn_clean_text(r."stylename"::text)                         AS name,
        'newcars'::text AS _source_db, 'styles'::text AS _source_table, r."styleid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.newcars__styles r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.body_style (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.body_style._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.body_style._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'body_style', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_body_style(bigint) IS 'stg_raw → stg_transform.body_style (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/04_catalogos/sp_transform_province.sql
-- ======================================================================
-- stg_transform.sp_transform_province
-- stg_raw → stg_transform.province  ·  Destino final: listings_db.province
-- Lee: stg_raw.usedcars__provinces
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_province(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_province(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'province');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__provinces)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.provinces
    SELECT
        stg_control.fn_legacy_uuid('usedcars.provinces', r."provinceid"::text) AS id,
        r."provinceid"::text                                                   AS legacy_id,
        'usedcars.provinces'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."provincename"::text)                      AS name,
        'usedcars'::text AS _source_db, 'provinces'::text AS _source_table, r."provinceid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__provinces r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.province (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.province._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.province._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'province', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_province(bigint) IS 'stg_raw → stg_transform.province (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_equipment.sql
-- ======================================================================
-- stg_transform.sp_transform_equipment
-- stg_raw → stg_transform.equipment  ·  Destino final: listings_db.equipment
-- Lee: stg_raw.usedcars__carextras
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_equipment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_equipment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'equipment');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__carextras)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.carextras
    SELECT
        stg_control.fn_legacy_uuid('usedcars.carextras', r."idextra"::text)    AS id,
        r."idextra"::text                                                      AS legacy_id,
        'usedcars.carextras'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."description"::text)                       AS name,
        'usedcars'::text AS _source_db, 'carextras'::text AS _source_table, r."idextra"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__carextras r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.equipment (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.equipment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.equipment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'equipment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_equipment(bigint) IS 'stg_raw → stg_transform.equipment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/05_accesorios/sp_transform_accessory_section.sql
-- ======================================================================
-- stg_transform.sp_transform_accessory_section
-- stg_raw → stg_transform.accessory_section  ·  Destino final: listings_db.accessory_section
-- Lee: stg_raw.accesorios__sections
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_accessory_section(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_accessory_section(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'accessory_section');

    SELECT (SELECT count(*) FROM stg_raw.accesorios__sections)
      INTO v_in;

    WITH src AS (
    -- ---- accesorios.sections
    SELECT
        stg_control.fn_legacy_uuid('accesorios.sections', r."sectionid"::text) AS id,
        r."sectionid"::text                                                    AS legacy_id,
        'accesorios.sections'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."sectiondesc"::text)                       AS name,
        'accesorios'::text AS _source_db, 'sections'::text AS _source_table, r."sectionid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.accesorios__sections r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.accessory_section (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.accessory_section._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.accessory_section._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'accessory_section', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_accessory_section(bigint) IS 'stg_raw → stg_transform.accessory_section (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/04_catalogos/sp_transform_model.sql
-- ======================================================================
-- stg_transform.sp_transform_model
-- stg_raw → stg_transform.model  ·  Destino final: listings_db.model
-- Lee: stg_raw.newcars__models
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_model(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_model(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'model');

    SELECT (SELECT count(*) FROM stg_raw.newcars__models)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.models
    SELECT
        stg_control.fn_legacy_uuid('newcars.models', r."mcode"::text)          AS id,
        r."mcode"::text                                                        AS legacy_id,
        'newcars.models'                                                       AS legacy_source,
        stg_control.fn_legacy_uuid('newcars.dealers', r."mdealer"::text)       AS dealer_id,
        stg_control.fn_legacy_uuid('newcars.brands', r."mbrand"::text)         AS brand_id,
        stg_control.fn_clean_text(r."mbasemodel"::text)                        AS base_model,
        stg_control.fn_legacy_uuid('newcars.styles', r."mstyle"::text)         AS body_style_id,
        r."mpicscode"::text                                                    AS image_prefix,
        stg_control.fn_to_int(r."myear"::text)::smallint                       AS year,
        r."mprice"::numeric(14,2)                                              AS price,
        stg_control.fn_clean_text(r."mdescrip"::text)                          AS mdescrip,
        stg_control.fn_clean_text(r."motherspecs"::text)                       AS motherspecs,
        stg_control.fn_clean_text(r."mmaintext"::text)                         AS mmaintext,
        r."mnumpics"::integer                                                  AS mnumpics,
        r."mnumvideos"::integer                                                AS mnumvideos,
        stg_control.fn_clean_text(r."mequipment"::text)                        AS mequipment,
        stg_control.fn_clean_text(r."mmotor"::text)                            AS mmotor,
        r."menginesize"::integer                                               AS menginesize,
        stg_control.fn_clean_text(r."mpower"::text)                            AS mpower,
        stg_control.fn_clean_text(r."mtorque"::text)                           AS mtorque,
        stg_control.fn_clean_text(r."msuspension"::text)                       AS msuspension,
        stg_control.fn_clean_text(r."msteering"::text)                         AS msteering,
        stg_control.fn_clean_text(r."mtransmission"::text)                     AS mtransmission,
        stg_control.fn_clean_text(r."mtransmission2"::text)                    AS mtransmission2,
        stg_control.fn_clean_text(r."mbrakes"::text)                           AS mbrakes,
        stg_control.fn_clean_text(r."mtires"::text)                            AS mtires,
        stg_control.fn_clean_text(r."mwarranty"::text)                         AS mwarranty,
        stg_control.fn_clean_text(r."mfuel"::text)                             AS mfuel,
        stg_control.fn_clean_text(r."mdrive"::text)                            AS mdrive,
        stg_control.fn_clean_text(r."mfueltank"::text)                         AS mfueltank,
        stg_control.fn_clean_text(r."mmaxspeed"::text)                         AS mmaxspeed,
        r."mvalves"::integer                                                   AS mvalves,
        r."mdoors"::integer                                                    AS mdoors,
        stg_control.fn_to_bool(r."mvisible"::text)                             AS is_visible,
        stg_control.fn_clean_text(r."mweight"::text)                           AS mweight,
        stg_control.fn_clean_text(r."mheight"::text)                           AS mheight,
        stg_control.fn_clean_text(r."mwidth"::text)                            AS mwidth,
        stg_control.fn_clean_text(r."mlength"::text)                           AS mlength,
        stg_control.fn_clean_text(r."mdiameter"::text)                         AS mdiameter,
        stg_control.fn_clean_text(r."mvideo1"::text)                           AS mvideo1,
        'newcars'::text AS _source_db, 'models'::text AS _source_table, r."mcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.newcars__models r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.model (id, legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        base_model = EXCLUDED.base_model,
        body_style_id = EXCLUDED.body_style_id,
        image_prefix = EXCLUDED.image_prefix,
        year = EXCLUDED.year,
        price = EXCLUDED.price,
        mdescrip = EXCLUDED.mdescrip,
        motherspecs = EXCLUDED.motherspecs,
        mmaintext = EXCLUDED.mmaintext,
        mnumpics = EXCLUDED.mnumpics,
        mnumvideos = EXCLUDED.mnumvideos,
        mequipment = EXCLUDED.mequipment,
        mmotor = EXCLUDED.mmotor,
        menginesize = EXCLUDED.menginesize,
        mpower = EXCLUDED.mpower,
        mtorque = EXCLUDED.mtorque,
        msuspension = EXCLUDED.msuspension,
        msteering = EXCLUDED.msteering,
        mtransmission = EXCLUDED.mtransmission,
        mtransmission2 = EXCLUDED.mtransmission2,
        mbrakes = EXCLUDED.mbrakes,
        mtires = EXCLUDED.mtires,
        mwarranty = EXCLUDED.mwarranty,
        mfuel = EXCLUDED.mfuel,
        mdrive = EXCLUDED.mdrive,
        mfueltank = EXCLUDED.mfueltank,
        mmaxspeed = EXCLUDED.mmaxspeed,
        mvalves = EXCLUDED.mvalves,
        mdoors = EXCLUDED.mdoors,
        is_visible = EXCLUDED.is_visible,
        mweight = EXCLUDED.mweight,
        mheight = EXCLUDED.mheight,
        mwidth = EXCLUDED.mwidth,
        mlength = EXCLUDED.mlength,
        mdiameter = EXCLUDED.mdiameter,
        mvideo1 = EXCLUDED.mvideo1,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.model._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.model._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'model', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_model(bigint) IS 'stg_raw → stg_transform.model (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_app_user.sql
-- ======================================================================
-- stg_transform.sp_transform_app_user
-- stg_raw → stg_transform.app_user  ·  Destino final: users_db.app_user
-- Lee: stg_raw.micrautos__users
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_app_user(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_app_user(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'app_user');

    SELECT (SELECT count(*) FROM stg_raw.micrautos__users)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.users
    -- No se migran: upwd, umenustyle, umainmenubg, umainbgcolor, umodelstitle, umodelnamebg, udestacadoscolor, udestacadosheader, udetailmaintitle, udetailsubtitle, udetailequiptitle, udetailequip, ulisthighlight, umodelborder, unewmenubg, actreqs, actattempts
    SELECT
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS id,
        r."ucode"::text                                                        AS legacy_id,
        'micrautos.users'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."uname"::text)                             AS first_name,
        stg_control.fn_clean_text(r."ulname"::text)                            AS last_name,
        stg_control.fn_map_code('ID_TYPE', 'micrautos', r."uidtype"::text)     AS id_type,
        stg_control.fn_clean_id_number(r."uidnum")                             AS id_number,
        stg_control.fn_make_date(r."uyear", r."umonth", r."uday")              AS birth_date,  -- combina uday, umonth, uyear
        stg_control.fn_map_code('GENDER', 'micrautos', r."usex"::text)         AS gender,
        stg_control.fn_clean_email(r."uemail")                                 AS email,
        stg_control.fn_to_date(r."udatein")                                    AS created_at,
        stg_control.fn_to_timestamptz(r."ulastlogin")                          AS last_login_at,
        stg_control.fn_map_code('USER_STATUS', 'micrautos', r."ustatus"::text) AS status,
        stg_control.fn_clean_text(r."uaddr1"::text)                            AS address_line1,
        stg_control.fn_clean_text(r."uaddr2"::text)                            AS address_line2,
        stg_control.fn_clean_text(r."ucity"::text)                             AS city,
        stg_control.fn_map_code('COUNTRY', 'micrautos', r."ucountry"::text)    AS country,
        stg_control.fn_clean_text(r."upostalcode"::text)                       AS postal_code,
        stg_control.fn_clean_phone_cr(r."uphonehome")                          AS phone_home,
        stg_control.fn_clean_phone_cr(r."uphonework")                          AS phone_work,
        stg_control.fn_clean_phone_cr(r."uphonecel")                           AS phone_mobile,
        r."ufreead"::text                                                      AS free_ad_flag,  -- POR CONFIRMAR
        stg_control.fn_to_bool(r."usendemail"::text)                           AS accepts_email,
        stg_control.fn_clean_text(r."unick"::text)                             AS nickname,
        'micrautos'::text AS _source_db, 'users'::text AS _source_table, r."ucode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.micrautos__users r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.app_user (id, legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        first_name = EXCLUDED.first_name,
        last_name = EXCLUDED.last_name,
        id_type = EXCLUDED.id_type,
        id_number = EXCLUDED.id_number,
        birth_date = EXCLUDED.birth_date,
        gender = EXCLUDED.gender,
        email = EXCLUDED.email,
        created_at = EXCLUDED.created_at,
        last_login_at = EXCLUDED.last_login_at,
        status = EXCLUDED.status,
        address_line1 = EXCLUDED.address_line1,
        address_line2 = EXCLUDED.address_line2,
        city = EXCLUDED.city,
        country = EXCLUDED.country,
        postal_code = EXCLUDED.postal_code,
        phone_home = EXCLUDED.phone_home,
        phone_work = EXCLUDED.phone_work,
        phone_mobile = EXCLUDED.phone_mobile,
        free_ad_flag = EXCLUDED.free_ad_flag,
        accepts_email = EXCLUDED.accepts_email,
        nickname = EXCLUDED.nickname,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.app_user._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.app_user._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'app_user', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_app_user(bigint) IS 'stg_raw → stg_transform.app_user (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_seller.sql
-- ======================================================================
-- stg_transform.sp_transform_seller
-- stg_raw → stg_transform.seller  ·  Destino final: users_db.seller
-- Lee: stg_raw.usedcars__sellers + stg_raw.accesorios__sellers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_seller(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_seller(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'seller');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__sellers)
        + (SELECT count(*) FROM stg_raw.accesorios__sellers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.sellers
    -- No se migran: sellerpwd, sellerpwd2, favcount
    SELECT
        stg_control.fn_legacy_uuid('usedcars.sellers', r."selleremail"::text)  AS id,
        r."selleremail"::text                                                  AS legacy_id,
        'usedcars.sellers'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."sellername"::text)                        AS name,
        stg_control.fn_clean_phone_cr(r."sellerphone")                         AS phone,
        stg_control.fn_clean_email(r."selleremail")                            AS email,
        stg_control.fn_to_date(r."sellerindate")                               AS start_date,
        stg_control.fn_to_date(r."sellerexpire")                               AS expiration_date,
        r."sellerlimit"::integer                                               AS ad_limit,
        stg_control.fn_map_code('SELLER_STATUS', 'usedcars', r."sellerstatus"::text) AS status,
        r."sellercode"::text                                                   AS seller_code,
        r."sellerplanamt"::numeric(12,2)                                       AS plan_amount,
        stg_control.fn_clean_text(r."sitelink"::text)                          AS website,
        r."dollaramt"::numeric(12,2)                                           AS plan_amount_usd,  -- POR CONFIRMAR
        r."destacados"::integer                                                AS featured_quota,
        stg_control.fn_clean_text(r."dept"::text)                              AS department,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_clean_text(r."selleraddr1"::text)                       AS address_line1,
        stg_control.fn_clean_text(r."selleraddr2"::text)                       AS address_line2,
        stg_control.fn_map_code('PROVINCE', 'usedcars', r."sellerprovince"::text) AS province_id,
        stg_control.fn_clean_text(r."sellercity"::text)                        AS city,
        stg_control.fn_to_bool(r."financeflag"::text)                          AS offers_financing,  -- POR CONFIRMAR
        r."accountamount"::numeric(12,2)                                       AS account_balance,
        stg_control.fn_to_timestamptz(r."accountlastdeposit")                  AS last_deposit_at,
        stg_control.fn_to_timestamptz(r."accountlastcharge")                   AS last_charge_at,
        stg_control.fn_to_date(r."bannerstart")                                AS banner_start_date,
        stg_control.fn_to_date(r."bannerend")                                  AS banner_end_date,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        stg_control.fn_clean_text(r."video"::text)                             AS video_html,
        stg_control.fn_clean_phone_cr(r."sellerwhatsapp")                      AS whatsapp,
        stg_control.fn_clean_text(r."rep"::text)                               AS sales_rep,
        stg_control.fn_clean_text(r."contactname"::text)                       AS contact_name,
        stg_control.fn_clean_phone_cr(r."contactphone")                        AS contact_phone,
        stg_control.fn_clean_email(r."contactemail")                           AS contact_email,
        NULL::text                                                             AS phone_2,  -- no viene de usedcars.sellers
        NULL::text                                                             AS phone_3,  -- no viene de usedcars.sellers
        NULL::text                                                             AS logo_s3_key,  -- no viene de usedcars.sellers
        'usedcars'::text AS _source_db, 'sellers'::text AS _source_table, r."selleremail"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__sellers r
    UNION ALL
    -- ---- accesorios.sellers
    -- No se migran: sellerpwd, favcount
    SELECT
        stg_control.fn_legacy_uuid('accesorios.sellers', r."selleremail"::text) AS id,
        r."selleremail"::text                                                  AS legacy_id,
        'accesorios.sellers'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."sellername"::text)                        AS name,
        stg_control.fn_clean_phone_cr(r."sellertel1")                          AS phone,
        stg_control.fn_clean_email(r."selleremail")                            AS email,
        stg_control.fn_to_date(r."sellerindate")                               AS start_date,
        stg_control.fn_to_date(r."sellerexpire")                               AS expiration_date,
        r."sellerlimit"::integer                                               AS ad_limit,
        stg_control.fn_map_code('SELLER_STATUS', 'accesorios', r."sellerstatus"::text) AS status,
        r."sellercode"::text                                                   AS seller_code,
        r."sellerplanamt"::numeric(12,2)                                       AS plan_amount,
        stg_control.fn_clean_text(r."sitelink"::text)                          AS website,
        r."dollaramt"::numeric(12,2)                                           AS plan_amount_usd,  -- POR CONFIRMAR
        r."destacados"::integer                                                AS featured_quota,
        stg_control.fn_clean_text(r."dept"::text)                              AS department,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."currency"::text)  AS currency,
        stg_control.fn_clean_text(r."selleraddr1"::text)                       AS address_line1,
        stg_control.fn_clean_text(r."selleraddr2"::text)                       AS address_line2,
        stg_control.fn_map_code('PROVINCE', 'accesorios', r."sellerprovince"::text) AS province_id,
        stg_control.fn_clean_text(r."sellercity"::text)                        AS city,
        NULL::boolean                                                          AS offers_financing,  -- no viene de accesorios.sellers
        r."accountamount"::numeric(12,2)                                       AS account_balance,
        stg_control.fn_to_timestamptz(r."accountlastdeposit")                  AS last_deposit_at,
        stg_control.fn_to_timestamptz(r."accountlastcharge")                   AS last_charge_at,
        NULL::date                                                             AS banner_start_date,  -- no viene de accesorios.sellers
        NULL::date                                                             AS banner_end_date,  -- no viene de accesorios.sellers
        NULL::boolean                                                          AS is_premium,  -- no viene de accesorios.sellers
        NULL::text                                                             AS video_html,  -- no viene de accesorios.sellers
        NULL::text                                                             AS whatsapp,  -- no viene de accesorios.sellers
        NULL::text                                                             AS sales_rep,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_name,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_phone,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_email,  -- no viene de accesorios.sellers
        stg_control.fn_clean_phone_cr(r."sellertel2")                          AS phone_2,
        stg_control.fn_clean_phone_cr(r."sellertel3")                          AS phone_3,
        r."logo"::text                                                         AS logo_s3_key,
        'accesorios'::text AS _source_db, 'sellers'::text AS _source_table, r."selleremail"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__sellers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.seller (id, legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        start_date = EXCLUDED.start_date,
        expiration_date = EXCLUDED.expiration_date,
        ad_limit = EXCLUDED.ad_limit,
        status = EXCLUDED.status,
        seller_code = EXCLUDED.seller_code,
        plan_amount = EXCLUDED.plan_amount,
        website = EXCLUDED.website,
        plan_amount_usd = EXCLUDED.plan_amount_usd,
        featured_quota = EXCLUDED.featured_quota,
        department = EXCLUDED.department,
        currency = EXCLUDED.currency,
        address_line1 = EXCLUDED.address_line1,
        address_line2 = EXCLUDED.address_line2,
        province_id = EXCLUDED.province_id,
        city = EXCLUDED.city,
        offers_financing = EXCLUDED.offers_financing,
        account_balance = EXCLUDED.account_balance,
        last_deposit_at = EXCLUDED.last_deposit_at,
        last_charge_at = EXCLUDED.last_charge_at,
        banner_start_date = EXCLUDED.banner_start_date,
        banner_end_date = EXCLUDED.banner_end_date,
        is_premium = EXCLUDED.is_premium,
        video_html = EXCLUDED.video_html,
        whatsapp = EXCLUDED.whatsapp,
        sales_rep = EXCLUDED.sales_rep,
        contact_name = EXCLUDED.contact_name,
        contact_phone = EXCLUDED.contact_phone,
        contact_email = EXCLUDED.contact_email,
        phone_2 = EXCLUDED.phone_2,
        phone_3 = EXCLUDED.phone_3,
        logo_s3_key = EXCLUDED.logo_s3_key,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.seller._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.seller._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'seller', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_seller(bigint) IS 'stg_raw → stg_transform.seller (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_dealer.sql
-- ======================================================================
-- stg_transform.sp_transform_dealer
-- stg_raw → stg_transform.dealer  ·  Destino final: users_db.dealer
-- Lee: stg_raw.usedcars__dealers + stg_raw.newcars__dealers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_dealer(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_dealer(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'dealer');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__dealers)
        + (SELECT count(*) FROM stg_raw.newcars__dealers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.dealers  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: folder
    SELECT
        stg_control.fn_legacy_uuid('usedcars.dealers', md5(concat_ws('|', r."dealercode", r."dealername", r."folder", r."link", r."demail"))) AS id,
        r."dealercode"::text                                                   AS legacy_id,
        'usedcars.dealers'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."dealername"::text)                        AS name,
        stg_control.fn_clean_text(r."link"::text)                              AS website,
        stg_control.fn_clean_email(r."demail")                                 AS email,
        NULL::text                                                             AS address,  -- no viene de usedcars.dealers
        NULL::text                                                             AS notes,  -- no viene de usedcars.dealers
        NULL::text                                                             AS username,  -- no viene de usedcars.dealers
        NULL::text                                                             AS email_2,  -- no viene de usedcars.dealers
        NULL::text                                                             AS email_3,  -- no viene de usedcars.dealers
        NULL::text                                                             AS seller_code,  -- no viene de usedcars.dealers
        'usedcars'::text AS _source_db, 'dealers'::text AS _source_table, md5(concat_ws('|', r."dealercode", r."dealername", r."folder", r."link", r."demail")) AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__dealers r
    UNION ALL
    -- ---- newcars.dealers
    -- No se migran: dpwd
    SELECT
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)         AS id,
        r."dcode"::text                                                        AS legacy_id,
        'newcars.dealers'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."dname"::text)                             AS name,
        stg_control.fn_clean_text(r."dwebsite"::text)                          AS website,
        stg_control.fn_clean_email(r."email1")                                 AS email,
        stg_control.fn_clean_text(r."daddress"::text)                          AS address,
        stg_control.fn_clean_text(r."dotherinfo"::text)                        AS notes,
        stg_control.fn_clean_text(r."duser"::text)                             AS username,
        stg_control.fn_clean_email(r."email2")                                 AS email_2,
        stg_control.fn_clean_email(r."email3")                                 AS email_3,
        r."dusedcode"::text                                                    AS seller_code,  -- POR CONFIRMAR
        'newcars'::text AS _source_db, 'dealers'::text AS _source_table, r."dcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.newcars__dealers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.dealer (id, legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        website = EXCLUDED.website,
        email = EXCLUDED.email,
        address = EXCLUDED.address,
        notes = EXCLUDED.notes,
        username = EXCLUDED.username,
        email_2 = EXCLUDED.email_2,
        email_3 = EXCLUDED.email_3,
        seller_code = EXCLUDED.seller_code,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.dealer._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.dealer._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'dealer', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_dealer(bigint) IS 'stg_raw → stg_transform.dealer (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_dealer_contact.sql
-- ======================================================================
-- stg_transform.sp_transform_dealer_contact
-- stg_raw → stg_transform.dealer_contact  ·  Destino final: users_db.dealer_contact
-- Lee: stg_raw.newcars__dealers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_dealer_contact(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_dealer_contact(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'dealer_contact');

    SELECT (SELECT count(*) FROM stg_raw.newcars__dealers)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.dealers: pivot dphoneN / dphonerefN
    SELECT
        stg_control.fn_legacy_uuid('newcars.dealers:contact', r."dcode"::text || '|' || v.n) AS id,
        r."dcode"::text || '|' || v.n                                        AS legacy_id,
        'newcars.dealers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)                                                   AS dealer_id,
        stg_control.fn_clean_phone_cr(v.phone)                     AS phone,
        stg_control.fn_clean_text(v.label)                         AS phone_label,
        v.n::smallint                                              AS sort_order,
        'newcars'::text AS _source_db, 'dealers'::text AS _source_table, r."dcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.newcars__dealers r
    CROSS JOIN LATERAL (VALUES
            (1, r."dphone1"::text, r."dphoneref1"::text),
            (2, r."dphone2"::text, r."dphoneref2"::text),
            (3, r."dphone3"::text, r."dphoneref3"::text),
            (4, r."dphone4"::text, r."dphoneref4"::text),
            (5, r."dphone5"::text, r."dphoneref5"::text),
            (6, r."dphone6"::text, r."dphoneref6"::text),
            (7, r."dphone7"::text, r."dphoneref7"::text),
            (8, r."dphone8"::text, r."dphoneref8"::text),
            (9, r."dphone9"::text, r."dphoneref9"::text),
            (10, r."dphone10"::text, r."dphoneref10"::text),
            (11, r."dphone11"::text, r."dphoneref11"::text),
            (12, r."dphone12"::text, r."dphoneref12"::text),
            (13, r."dphone13"::text, r."dphoneref13"::text),
            (14, r."dphone14"::text, r."dphoneref14"::text),
            (15, r."dphone15"::text, r."dphoneref15"::text),
            (16, r."dphone16"::text, r."dphoneref16"::text),
            (17, r."dphone17"::text, r."dphoneref17"::text),
            (18, r."dphone18"::text, r."dphoneref18"::text),
            (19, r."dphone19"::text, r."dphoneref19"::text),
            (20, r."dphone20"::text, r."dphoneref20"::text),
            (21, r."dphone21"::text, r."dphoneref21"::text),
            (22, r."dphone22"::text, r."dphoneref22"::text),
            (23, r."dphone23"::text, r."dphoneref23"::text),
            (24, r."dphone24"::text, r."dphoneref24"::text),
            (25, r."dphone25"::text, r."dphoneref25"::text)
         ) AS v(n, phone, label)
    WHERE nullif(trim(v.phone), '') IS NOT NULL
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.dealer_contact (id, legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        dealer_id = EXCLUDED.dealer_id,
        phone = EXCLUDED.phone,
        phone_label = EXCLUDED.phone_label,
        sort_order = EXCLUDED.sort_order,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.dealer_contact._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.dealer_contact._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'dealer_contact', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_dealer_contact(bigint) IS 'stg_raw → stg_transform.dealer_contact (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_admin_user.sql
-- ======================================================================
-- stg_transform.sp_transform_admin_user
-- stg_raw → stg_transform.admin_user  ·  Destino final: users_db.admin_user
-- Lee: stg_raw.usedcars__adminusers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_admin_user(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_admin_user(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'admin_user');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__adminusers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.adminusers
    -- No se migran: userpwd
    SELECT
        stg_control.fn_legacy_uuid('usedcars.adminusers', r."userid"::text)    AS id,
        r."userid"::text                                                       AS legacy_id,
        'usedcars.adminusers'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."userid"::text)                            AS username,
        stg_control.fn_map_code('ADMIN_LEVEL', 'usedcars', r."userlevel"::text) AS role,
        stg_control.fn_clean_text(r."username"::text)                          AS full_name,
        stg_control.fn_clean_phone_cr(r."userphone")                           AS phone,
        stg_control.fn_clean_text(r."userposition"::text)                      AS position,
        'usedcars'::text AS _source_db, 'adminusers'::text AS _source_table, r."userid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__adminusers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.admin_user (id, legacy_id, legacy_source, username, role, full_name, phone, position,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, username, role, full_name, phone, position,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, username, role, full_name, phone, position)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        username = EXCLUDED.username,
        role = EXCLUDED.role,
        full_name = EXCLUDED.full_name,
        phone = EXCLUDED.phone,
        position = EXCLUDED.position,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.admin_user._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.admin_user._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'admin_user', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_admin_user(bigint) IS 'stg_raw → stg_transform.admin_user (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing.sql
-- ======================================================================
-- stg_transform.sp_transform_listing
-- stg_raw → stg_transform.listing  ·  Destino final: listings_db.listing
-- Lee: stg_raw.usedcars__datafile + stg_raw.usedcars__archive + stg_raw.usedcars__expiredsellers + stg_raw.usedcars__pending + stg_raw.usedcars__pendingpay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__datafile)
        + (SELECT count(*) FROM stg_raw.usedcars__archive)
        + (SELECT count(*) FROM stg_raw.usedcars__expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars__pending)
        + (SELECT count(*) FROM stg_raw.usedcars__pendingpay)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.datafile'                                                    AS legacy_source,
        'ACTIVE'                                                               AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__datafile r
    UNION ALL
    -- ---- usedcars.archive
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.archive'                                                     AS legacy_source,
        'ARCHIVED'                                                             AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__archive r
    UNION ALL
    -- ---- usedcars.expiredsellers
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.expiredsellers'                                              AS legacy_source,
        'EXPIRED'                                                              AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__expiredsellers r
    UNION ALL
    -- ---- usedcars.pending
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.pending'                                                     AS legacy_source,
        'PENDING_APPROVAL'                                                     AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__pending r
    UNION ALL
    -- ---- usedcars.pendingpay
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.pendingpay'                                                  AS legacy_source,
        'PENDING_PAYMENT'                                                      AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__pendingpay r
    ),
    dedup AS (
    -- Un mismo codigo puede existir en varias tablas del ciclo de vida: gana la de menor _prio
    -- (datafile > archive > expiredsellers > pending > pendingpay) y, dentro de la misma, el último cambio DMS.
    -- Los duplicados reales se reportan en sp_validate (regla VAL_LISTING_DUP_LIFECYCLE).
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing (id, legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        publication_lifecycle = EXCLUDED.publication_lifecycle,
        reference_code = EXCLUDED.reference_code,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        model_name = EXCLUDED.model_name,
        engine = EXCLUDED.engine,
        year = EXCLUDED.year,
        body_style_id = EXCLUDED.body_style_id,
        passengers = EXCLUDED.passengers,
        price = EXCLUDED.price,
        previous_price = EXCLUDED.previous_price,
        exchange_rate = EXCLUDED.exchange_rate,
        transfer_cost = EXCLUDED.transfer_cost,
        condition_code = EXCLUDED.condition_code,
        exterior_color = EXCLUDED.exterior_color,
        contact_phone = EXCLUDED.contact_phone,
        contact_whatsapp = EXCLUDED.contact_whatsapp,
        contact_email = EXCLUDED.contact_email,
        summary = EXCLUDED.summary,
        description = EXCLUDED.description,
        ai_description = EXCLUDED.ai_description,
        contact_name = EXCLUDED.contact_name,
        image_count = EXCLUDED.image_count,
        fuel_type = EXCLUDED.fuel_type,
        ev_range = EXCLUDED.ev_range,
        ev_range_unit = EXCLUDED.ev_range_unit,
        battery_kwh = EXCLUDED.battery_kwh,
        transmission = EXCLUDED.transmission,
        publication_status = EXCLUDED.publication_status,
        mileage = EXCLUDED.mileage,
        mileage_unit = EXCLUDED.mileage_unit,
        source_channel = EXCLUDED.source_channel,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        option_6 = EXCLUDED.option_6,
        option_7 = EXCLUDED.option_7,
        option_8 = EXCLUDED.option_8,
        option_9 = EXCLUDED.option_9,
        option_10 = EXCLUDED.option_10,
        visit_count = EXCLUDED.visit_count,
        has_interior_360 = EXCLUDED.has_interior_360,
        video_url = EXCLUDED.video_url,
        interior_color = EXCLUDED.interior_color,
        is_negotiable = EXCLUDED.is_negotiable,
        is_registered = EXCLUDED.is_registered,
        plate = EXCLUDED.plate,
        doors = EXCLUDED.doors,
        province_id = EXCLUDED.province_id,
        accepts_trade_in = EXCLUDED.accepts_trade_in,
        vin = EXCLUDED.vin,
        approved_by = EXCLUDED.approved_by,
        deleted_by = EXCLUDED.deleted_by,
        deleted_at = EXCLUDED.deleted_at,
        is_blocked = EXCLUDED.is_blocked,
        blocked_reason = EXCLUDED.blocked_reason,
        blocked_by = EXCLUDED.blocked_by,
        currency = EXCLUDED.currency,
        is_premium = EXCLUDED.is_premium,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing(bigint) IS 'stg_raw → stg_transform.listing (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing_transfer.sql
-- ======================================================================
-- stg_transform.sp_transform_listing_transfer
-- stg_raw → stg_transform.listing_transfer  ·  Destino final: listings_db.listing_transfer
-- Lee: stg_raw.usedcars__archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_transfer(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_transfer(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_transfer');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.archivetraspaso
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('usedcars.archivetraspaso', concat_ws('|', r."refcode", r."codigo")) AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.archivetraspaso'                                             AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_text(r."certificar"::text)                        AS certification,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__archivetraspaso r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_transfer (id, legacy_id, legacy_source, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, certification, fuel_type, transmission, publication_status, mileage, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, certification, fuel_type, transmission, publication_status, mileage, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, certification, fuel_type, transmission, publication_status, mileage, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        reference_code = EXCLUDED.reference_code,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        model_name = EXCLUDED.model_name,
        engine = EXCLUDED.engine,
        year = EXCLUDED.year,
        body_style_id = EXCLUDED.body_style_id,
        passengers = EXCLUDED.passengers,
        price = EXCLUDED.price,
        previous_price = EXCLUDED.previous_price,
        exchange_rate = EXCLUDED.exchange_rate,
        condition_code = EXCLUDED.condition_code,
        exterior_color = EXCLUDED.exterior_color,
        contact_phone = EXCLUDED.contact_phone,
        contact_whatsapp = EXCLUDED.contact_whatsapp,
        contact_email = EXCLUDED.contact_email,
        summary = EXCLUDED.summary,
        description = EXCLUDED.description,
        ai_description = EXCLUDED.ai_description,
        contact_name = EXCLUDED.contact_name,
        certification = EXCLUDED.certification,
        fuel_type = EXCLUDED.fuel_type,
        transmission = EXCLUDED.transmission,
        publication_status = EXCLUDED.publication_status,
        mileage = EXCLUDED.mileage,
        source_channel = EXCLUDED.source_channel,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        option_6 = EXCLUDED.option_6,
        option_7 = EXCLUDED.option_7,
        option_8 = EXCLUDED.option_8,
        option_9 = EXCLUDED.option_9,
        option_10 = EXCLUDED.option_10,
        visit_count = EXCLUDED.visit_count,
        has_interior_360 = EXCLUDED.has_interior_360,
        video_url = EXCLUDED.video_url,
        interior_color = EXCLUDED.interior_color,
        is_negotiable = EXCLUDED.is_negotiable,
        is_registered = EXCLUDED.is_registered,
        plate = EXCLUDED.plate,
        doors = EXCLUDED.doors,
        province_id = EXCLUDED.province_id,
        accepts_trade_in = EXCLUDED.accepts_trade_in,
        vin = EXCLUDED.vin,
        approved_by = EXCLUDED.approved_by,
        deleted_by = EXCLUDED.deleted_by,
        deleted_at = EXCLUDED.deleted_at,
        is_blocked = EXCLUDED.is_blocked,
        blocked_reason = EXCLUDED.blocked_reason,
        blocked_by = EXCLUDED.blocked_by,
        currency = EXCLUDED.currency,
        is_premium = EXCLUDED.is_premium,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_transfer._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_transfer._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_transfer', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_transfer(bigint) IS 'stg_raw → stg_transform.listing_transfer (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing_image.sql
-- ======================================================================
-- stg_transform.sp_transform_listing_image
-- stg_raw → stg_transform.listing_image  ·  Destino final: listings_db.listing_image
-- Lee: stg_raw.usedcars__datafile + stg_raw.usedcars__archive + stg_raw.usedcars__expiredsellers + stg_raw.usedcars__pending + stg_raw.usedcars__pendingpay + stg_raw.usedcars__archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_image(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_image(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_image');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__datafile)
        + (SELECT count(*) FROM stg_raw.usedcars__archive)
        + (SELECT count(*) FROM stg_raw.usedcars__expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars__pending)
        + (SELECT count(*) FROM stg_raw.usedcars__pendingpay)
        + (SELECT count(*) FROM stg_raw.usedcars__archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.datafile'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__datafile r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.archive: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archive'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__archive r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.expiredsellers: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.expiredsellers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__expiredsellers r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.pending: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pending'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__pending r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.pendingpay: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pendingpay'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__pendingpay r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.archivetraspaso: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archivetraspaso'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 6 AS _prio
    FROM stg_raw.usedcars__archivetraspaso r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_image (id, legacy_id, legacy_source, listing_id, s3_key, sort_order,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, s3_key, sort_order,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, s3_key, sort_order)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        s3_key = EXCLUDED.s3_key,
        sort_order = EXCLUDED.sort_order,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_image._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_image._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_image', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_image(bigint) IS 'stg_raw → stg_transform.listing_image (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing_equipment.sql
-- ======================================================================
-- stg_transform.sp_transform_listing_equipment
-- stg_raw → stg_transform.listing_equipment  ·  Destino final: listings_db.listing_equipment
-- Lee: stg_raw.usedcars__datafile + stg_raw.usedcars__archive + stg_raw.usedcars__expiredsellers + stg_raw.usedcars__pending + stg_raw.usedcars__pendingpay + stg_raw.usedcars__archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_equipment(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_equipment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_equipment');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__datafile)
        + (SELECT count(*) FROM stg_raw.usedcars__archive)
        + (SELECT count(*) FROM stg_raw.usedcars__expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars__pending)
        + (SELECT count(*) FROM stg_raw.usedcars__pendingpay)
        + (SELECT count(*) FROM stg_raw.usedcars__archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.datafile'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__datafile r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.archive: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archive'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__archive r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.expiredsellers: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.expiredsellers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__expiredsellers r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.pending: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pending'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__pending r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.pendingpay: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pendingpay'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__pendingpay r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.archivetraspaso: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archivetraspaso'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 6 AS _prio
    FROM stg_raw.usedcars__archivetraspaso r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_equipment (id, legacy_id, legacy_source, listing_id, equipment_id, feature_slot,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, equipment_id, feature_slot,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, equipment_id, feature_slot)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        equipment_id = EXCLUDED.equipment_id,
        feature_slot = EXCLUDED.feature_slot,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_equipment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_equipment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_equipment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_equipment(bigint) IS 'stg_raw → stg_transform.listing_equipment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_special_deal.sql
-- ======================================================================
-- stg_transform.sp_transform_special_deal
-- stg_raw → stg_transform.special_deal  ·  Destino final: listings_db.special_deal
-- Lee: stg_raw.usedcars__specialdeals
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_special_deal(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_special_deal(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'special_deal');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__specialdeals)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.specialdeals
    SELECT
        stg_control.fn_legacy_uuid('usedcars.specialdeals', concat_ws('|', r."adcode", r."ddate")) AS id,
        concat_ws('|', r."adcode", r."ddate")                                  AS legacy_id,
        'usedcars.specialdeals'                                                AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."adcode"::text)                AS listing_id,
        stg_control.fn_to_date(r."ddate")                                      AS deal_date,
        r."dprice"::numeric(14,2)                                              AS deal_price,
        'usedcars'::text AS _source_db, 'specialdeals'::text AS _source_table, concat_ws('|', r."adcode", r."ddate") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__specialdeals r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.special_deal (id, legacy_id, legacy_source, listing_id, deal_date, deal_price,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, deal_date, deal_price,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, deal_date, deal_price)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        deal_date = EXCLUDED.deal_date,
        deal_price = EXCLUDED.deal_price,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.special_deal._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.special_deal._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'special_deal', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_special_deal(bigint) IS 'stg_raw → stg_transform.special_deal (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_banner.sql
-- ======================================================================
-- stg_transform.sp_transform_banner
-- stg_raw → stg_transform.banner  ·  Destino final: listings_db.banner
-- Lee: stg_raw.newcars__mainbanners
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_banner(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_banner(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'banner');

    SELECT (SELECT count(*) FROM stg_raw.newcars__mainbanners)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.mainbanners
    SELECT
        stg_control.fn_legacy_uuid('newcars.mainbanners', r."codigo"::text)    AS id,
        r."codigo"::text                                                       AS legacy_id,
        'newcars.mainbanners'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."client"::text)                            AS client_name,
        r."filename"::text                                                     AS image_s3_key,
        stg_control.fn_clean_text(r."link"::text)                              AS link_url,
        stg_control.fn_clean_text(r."mobilelink"::text)                        AS mobile_link_url,
        stg_control.fn_clean_text(r."target"::text)                            AS link_target,
        stg_control.fn_to_date(r."startdate")                                  AS start_date,
        stg_control.fn_to_date(r."enddate")                                    AS end_date,
        'newcars'::text AS _source_db, 'mainbanners'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.newcars__mainbanners r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.banner (id, legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        client_name = EXCLUDED.client_name,
        image_s3_key = EXCLUDED.image_s3_key,
        link_url = EXCLUDED.link_url,
        mobile_link_url = EXCLUDED.mobile_link_url,
        link_target = EXCLUDED.link_target,
        start_date = EXCLUDED.start_date,
        end_date = EXCLUDED.end_date,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.banner._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.banner._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'banner', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_banner(bigint) IS 'stg_raw → stg_transform.banner (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/05_accesorios/sp_transform_accessory_listing.sql
-- ======================================================================
-- stg_transform.sp_transform_accessory_listing
-- stg_raw → stg_transform.accessory_listing  ·  Destino final: listings_db.accessory_listing
-- Lee: stg_raw.accesorios__archive + stg_raw.accesorios__pendingpay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_accessory_listing(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_accessory_listing(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'accessory_listing');

    SELECT (SELECT count(*) FROM stg_raw.accesorios__archive)
        + (SELECT count(*) FROM stg_raw.accesorios__pendingpay)
      INTO v_in;

    WITH src AS (
    -- ---- accesorios.archive
    -- No se migran: ip, pwd
    SELECT
        stg_control.fn_legacy_uuid('accesorios.archive', r."codigo"::text)     AS id,
        r."codigo"::text                                                       AS legacy_id,
        'accesorios.archive'                                                   AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        stg_control.fn_map_code('ACC_ESTADO', 'accesorios', r."estado"::text)  AS condition_code,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."expdate")                             AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_phone_cr(r."tel1")                                AS phone,
        stg_control.fn_clean_phone_cr(r."tel2")                                AS phone_2,
        stg_control.fn_clean_phone_cr(r."tel3")                                AS phone_3,
        r."precio"::numeric(14,2)                                              AS price,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."moneda"::text)    AS currency,
        r."refprice"::numeric(14,2)                                            AS reference_price,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."titulo"::text)                            AS title,
        stg_control.fn_clean_text(r."itemdesc"::text)                          AS description,
        stg_control.fn_legacy_uuid('accesorios.sections', r."seccion"::text)   AS section_id,
        stg_control.fn_to_date(r."deldate")                                    AS deleted_at,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        'accesorios'::text AS _source_db, 'archive'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.accesorios__archive r
    UNION ALL
    -- ---- accesorios.pendingpay
    -- No se migran: ip, pwd
    SELECT
        stg_control.fn_legacy_uuid('accesorios.pendingpay', r."codigo"::text)  AS id,
        r."codigo"::text                                                       AS legacy_id,
        'accesorios.pendingpay'                                                AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        stg_control.fn_map_code('ACC_ESTADO', 'accesorios', r."estado"::text)  AS condition_code,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."expdate")                             AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_phone_cr(r."tel1")                                AS phone,
        stg_control.fn_clean_phone_cr(r."tel2")                                AS phone_2,
        stg_control.fn_clean_phone_cr(r."tel3")                                AS phone_3,
        r."precio"::numeric(14,2)                                              AS price,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."moneda"::text)    AS currency,
        r."refprice"::numeric(14,2)                                            AS reference_price,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."titulo"::text)                            AS title,
        stg_control.fn_clean_text(r."itemdesc"::text)                          AS description,
        stg_control.fn_legacy_uuid('accesorios.sections', r."seccion"::text)   AS section_id,
        stg_control.fn_to_date(r."deldate")                                    AS deleted_at,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        'accesorios'::text AS _source_db, 'pendingpay'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__pendingpay r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.accessory_listing (id, legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        reference_code = EXCLUDED.reference_code,
        condition_code = EXCLUDED.condition_code,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        visit_count = EXCLUDED.visit_count,
        image_count = EXCLUDED.image_count,
        contact_name = EXCLUDED.contact_name,
        contact_email = EXCLUDED.contact_email,
        phone = EXCLUDED.phone,
        phone_2 = EXCLUDED.phone_2,
        phone_3 = EXCLUDED.phone_3,
        price = EXCLUDED.price,
        currency = EXCLUDED.currency,
        reference_price = EXCLUDED.reference_price,
        title = EXCLUDED.title,
        description = EXCLUDED.description,
        section_id = EXCLUDED.section_id,
        deleted_at = EXCLUDED.deleted_at,
        deleted_by = EXCLUDED.deleted_by,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.accessory_listing._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.accessory_listing._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'accessory_listing', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_accessory_listing(bigint) IS 'stg_raw → stg_transform.accessory_listing (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_favorite.sql
-- ======================================================================
-- stg_transform.sp_transform_user_favorite
-- stg_raw → stg_transform.user_favorite  ·  Destino final: users_db.user_favorite
-- Lee: stg_raw.micrautos__favorites
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_favorite(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_favorite(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_favorite');

    SELECT (SELECT count(*) FROM stg_raw.micrautos__favorites)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.favorites
    SELECT
        stg_control.fn_legacy_uuid('micrautos.favorites', concat_ws('|', r."ucode", r."xcode")) AS id,
        concat_ws('|', r."ucode", r."xcode")                                   AS legacy_id,
        'micrautos.favorites'                                                  AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS user_id,
        stg_control.fn_legacy_uuid('listing', r."xcode"::text)                 AS listing_id,
        r."fcode"::text                                                        AS favorite_type,  -- POR CONFIRMAR
        stg_control.fn_to_timestamptz(r."fdate")                               AS created_at,
        stg_control.fn_clean_text(r."fextra"::text)                            AS notes,
        'micrautos'::text AS _source_db, 'favorites'::text AS _source_table, concat_ws('|', r."ucode", r."xcode") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.micrautos__favorites r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_favorite (id, legacy_id, legacy_source, user_id, listing_id, favorite_type, created_at, notes,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, listing_id, favorite_type, created_at, notes,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, listing_id, favorite_type, created_at, notes)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        listing_id = EXCLUDED.listing_id,
        favorite_type = EXCLUDED.favorite_type,
        created_at = EXCLUDED.created_at,
        notes = EXCLUDED.notes,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_favorite._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_favorite._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_favorite', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_favorite(bigint) IS 'stg_raw → stg_transform.user_favorite (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_friend.sql
-- ======================================================================
-- stg_transform.sp_transform_user_friend
-- stg_raw → stg_transform.user_friend  ·  Destino final: users_db.user_friend
-- Lee: stg_raw.micrautos__friends
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_friend(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_friend(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_friend');

    SELECT (SELECT count(*) FROM stg_raw.micrautos__friends)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.friends
    SELECT
        stg_control.fn_legacy_uuid('micrautos.friends', concat_ws('|', r."ucode", r."fcode")) AS id,
        r."fid"::text                                                          AS legacy_id,
        'micrautos.friends'                                                    AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS user_id,
        stg_control.fn_legacy_uuid('micrautos.users', r."fcode"::text)         AS friend_user_id,
        stg_control.fn_to_date(r."fdate")                                      AS created_at,
        'micrautos'::text AS _source_db, 'friends'::text AS _source_table, concat_ws('|', r."ucode", r."fcode") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.micrautos__friends r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_friend (id, legacy_id, legacy_source, user_id, friend_user_id, created_at,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, friend_user_id, created_at,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, friend_user_id, created_at)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        friend_user_id = EXCLUDED.friend_user_id,
        created_at = EXCLUDED.created_at,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_friend._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_friend._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_friend', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_friend(bigint) IS 'stg_raw → stg_transform.user_friend (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_request.sql
-- ======================================================================
-- stg_transform.sp_transform_user_request
-- stg_raw → stg_transform.user_request  ·  Destino final: users_db.user_request
-- Lee: stg_raw.micrautos__requests
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_request(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_request(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_request');

    SELECT (SELECT count(*) FROM stg_raw.micrautos__requests)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.requests
    SELECT
        stg_control.fn_legacy_uuid('micrautos.requests', r."reqid"::text)      AS id,
        r."reqid"::text                                                        AS legacy_id,
        'micrautos.requests'                                                   AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS user_id,
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)         AS dealer_id,
        stg_control.fn_map_code('REQUEST_TYPE', 'micrautos', r."reqtype"::text) AS request_type,
        jsonb_build_object('var1', r."var1", 'var2', r."var2", 'var3', r."var3") AS attributes,  -- combina var1, var2, var3
        stg_control.fn_clean_text(r."mtext"::text)                             AS message,
        stg_control.fn_to_timestamptz(r."rdate")                               AS created_at,
        'micrautos'::text AS _source_db, 'requests'::text AS _source_table, r."reqid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.micrautos__requests r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_request (id, legacy_id, legacy_source, user_id, dealer_id, request_type, attributes, message, created_at,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, dealer_id, request_type, attributes, message, created_at,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, dealer_id, request_type, attributes, message, created_at)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        dealer_id = EXCLUDED.dealer_id,
        request_type = EXCLUDED.request_type,
        attributes = EXCLUDED.attributes,
        message = EXCLUDED.message,
        created_at = EXCLUDED.created_at,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_request._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_request._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_request', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_request(bigint) IS 'stg_raw → stg_transform.user_request (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_suggestion.sql
-- ======================================================================
-- stg_transform.sp_transform_user_suggestion
-- stg_raw → stg_transform.user_suggestion  ·  Destino final: users_db.user_suggestion
-- Lee: stg_raw.micrautos__suggestions
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_suggestion(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_suggestion(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_suggestion');

    SELECT (SELECT count(*) FROM stg_raw.micrautos__suggestions)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.suggestions
    SELECT
        stg_control.fn_legacy_uuid('micrautos.suggestions', concat_ws('|', r."userid", r."datein")) AS id,
        concat_ws('|', r."userid", r."datein")                                 AS legacy_id,
        'micrautos.suggestions'                                                AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."userid"::text)        AS user_id,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_clean_text(r."suggestion"::text)                        AS suggestion_text,
        'micrautos'::text AS _source_db, 'suggestions'::text AS _source_table, concat_ws('|', r."userid", r."datein") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.micrautos__suggestions r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_suggestion (id, legacy_id, legacy_source, user_id, created_at, suggestion_text,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, created_at, suggestion_text,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, created_at, suggestion_text)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        created_at = EXCLUDED.created_at,
        suggestion_text = EXCLUDED.suggestion_text,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_suggestion._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_suggestion._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_suggestion', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_suggestion(bigint) IS 'stg_raw → stg_transform.user_suggestion (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_report.sql
-- ======================================================================
-- stg_transform.sp_transform_user_report
-- stg_raw → stg_transform.user_report  ·  Destino final: users_db.user_report
-- Lee: stg_raw.micrautos__userreports
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_report(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_report(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_report');

    SELECT (SELECT count(*) FROM stg_raw.micrautos__userreports)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.userreports
    SELECT
        stg_control.fn_legacy_uuid('micrautos.userreports', concat_ws('|', r."userid", r."datein", r."adcode")) AS id,
        concat_ws('|', r."userid", r."datein", r."adcode")                     AS legacy_id,
        'micrautos.userreports'                                                AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."userid"::text)        AS user_id,
        stg_control.fn_legacy_uuid('listing', r."adcode"::text)                AS listing_id,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_clean_text(r."report"::text)                            AS report_text,
        stg_control.fn_clean_text(r."action"::text)                            AS action_taken,
        stg_control.fn_map_code('REPORT_STATUS', 'micrautos', r."repstatus"::text) AS status,
        stg_control.fn_clean_text(r."repcode"::text)                           AS report_code,
        'micrautos'::text AS _source_db, 'userreports'::text AS _source_table, concat_ws('|', r."userid", r."datein", r."adcode") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.micrautos__userreports r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_report (id, legacy_id, legacy_source, user_id, listing_id, created_at, report_text, action_taken, status, report_code,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, listing_id, created_at, report_text, action_taken, status, report_code,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, listing_id, created_at, report_text, action_taken, status, report_code)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        listing_id = EXCLUDED.listing_id,
        created_at = EXCLUDED.created_at,
        report_text = EXCLUDED.report_text,
        action_taken = EXCLUDED.action_taken,
        status = EXCLUDED.status,
        report_code = EXCLUDED.report_code,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_report._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_report._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_report', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_report(bigint) IS 'stg_raw → stg_transform.user_report (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/02_seguridad/sp_transform_blocked_contact.sql
-- ======================================================================
-- stg_transform.sp_transform_blocked_contact
-- stg_raw → stg_transform.blocked_contact  ·  Destino final: users_db.blocked_contact
-- Lee: stg_raw.usedcars__blocked + stg_raw.usedcars__blockedemails + stg_raw.usedcars__blockedips + stg_raw.usedcars__blockedphones + stg_raw.usedcars__correosfraude
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_blocked_contact(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_blocked_contact(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'blocked_contact');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__blocked)
        + (SELECT count(*) FROM stg_raw.usedcars__blockedemails)
        + (SELECT count(*) FROM stg_raw.usedcars__blockedips)
        + (SELECT count(*) FROM stg_raw.usedcars__blockedphones)
        + (SELECT count(*) FROM stg_raw.usedcars__correosfraude)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.blocked
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blocked', r."blockedid"::text)    AS id,
        r."blockedid"::text                                                    AS legacy_id,
        'usedcars.blocked'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."blockedid"::text)                         AS blockedid,
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blocked
        NULL::text                                                             AS ip,  -- no viene de usedcars.blocked
        NULL::text                                                             AS reason,  -- no viene de usedcars.blocked
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blocked
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blocked
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blocked
        'usedcars'::text AS _source_db, 'blocked'::text AS _source_table, r."blockedid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__blocked r
    UNION ALL
    -- ---- usedcars.blockedemails
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedemails', r."blockedemail"::text) AS id,
        r."blockedemail"::text                                                 AS legacy_id,
        'usedcars.blockedemails'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedemails
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        stg_control.fn_clean_email(r."blockedemail")                           AS blockedemail,
        NULL::text                                                             AS ip,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS reason,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedemails
        'usedcars'::text AS _source_db, 'blockedemails'::text AS _source_table, r."blockedemail"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__blockedemails r
    UNION ALL
    -- ---- usedcars.blockedips
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedips', r."ip"::text)        AS id,
        r."ip"::text                                                           AS legacy_id,
        'usedcars.blockedips'                                                  AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS blockedname,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blockedips
        stg_control.fn_clean_text(r."ip"::text)                                AS ip,
        stg_control.fn_clean_text(r."reason"::text)                            AS reason,
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedips
        'usedcars'::text AS _source_db, 'blockedips'::text AS _source_table, r."ip"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__blockedips r
    UNION ALL
    -- ---- usedcars.blockedphones
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedphones', r."blockedphone"::text) AS id,
        r."blockedphone"::text                                                 AS legacy_id,
        'usedcars.blockedphones'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedphones
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS ip,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS reason,  -- no viene de usedcars.blockedphones
        stg_control.fn_clean_text(r."blockedphone"::text)                      AS blockedphone,
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedphones
        'usedcars'::text AS _source_db, 'blockedphones'::text AS _source_table, r."blockedphone"::text AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__blockedphones r
    UNION ALL
    -- ---- usedcars.correosfraude
    SELECT
        stg_control.fn_legacy_uuid('usedcars.correosfraude', r."codigo"::text) AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.correosfraude'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedname,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS ip,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS reason,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.correosfraude
        stg_control.fn_clean_text(r."codigo"::text)                            AS codigo,
        stg_control.fn_clean_email(r."emailaddr")                              AS emailaddr,
        'usedcars'::text AS _source_db, 'correosfraude'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__correosfraude r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.blocked_contact (id, legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        blockedid = EXCLUDED.blockedid,
        blockedname = EXCLUDED.blockedname,
        blockedemail = EXCLUDED.blockedemail,
        ip = EXCLUDED.ip,
        reason = EXCLUDED.reason,
        blockedphone = EXCLUDED.blockedphone,
        codigo = EXCLUDED.codigo,
        emailaddr = EXCLUDED.emailaddr,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.blocked_contact._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.blocked_contact._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'blocked_contact', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_blocked_contact(bigint) IS 'stg_raw → stg_transform.blocked_contact (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/02_seguridad/sp_transform_ip_allowlist.sql
-- ======================================================================
-- stg_transform.sp_transform_ip_allowlist
-- stg_raw → stg_transform.ip_allowlist  ·  Destino final: users_db.ip_allowlist
-- Lee: stg_raw.usedcars__ipsaccepted
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_ip_allowlist(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_ip_allowlist(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'ip_allowlist');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__ipsaccepted)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.ipsaccepted
    SELECT
        stg_control.fn_legacy_uuid('usedcars.ipsaccepted', r."aip"::text)      AS id,
        r."aip"::text                                                          AS legacy_id,
        'usedcars.ipsaccepted'                                                 AS legacy_source,
        stg_control.fn_clean_text(r."aip"::text)                               AS aip,
        stg_control.fn_clean_text(r."alocation"::text)                         AS alocation,
        stg_control.fn_clean_text(r."actry"::text)                             AS actry,
        'usedcars'::text AS _source_db, 'ipsaccepted'::text AS _source_table, r."aip"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__ipsaccepted r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.ip_allowlist (id, legacy_id, legacy_source, aip, alocation, actry,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, aip, alocation, actry,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, aip, alocation, actry)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        aip = EXCLUDED.aip,
        alocation = EXCLUDED.alocation,
        actry = EXCLUDED.actry,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.ip_allowlist._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.ip_allowlist._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'ip_allowlist', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_ip_allowlist(bigint) IS 'stg_raw → stg_transform.ip_allowlist (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/02_seguridad/sp_transform_system_parameter.sql
-- ======================================================================
-- stg_transform.sp_transform_system_parameter
-- stg_raw → stg_transform.system_parameter  ·  Destino final: users_db.system_parameter
-- Lee: stg_raw.usedcars__parameters
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_system_parameter(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_system_parameter(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'system_parameter');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__parameters)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.parameters
    SELECT
        stg_control.fn_legacy_uuid('usedcars.parameters', r."parname"::text)   AS id,
        r."parname"::text                                                      AS legacy_id,
        'usedcars.parameters'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."parname"::text)                           AS parname,
        stg_control.fn_clean_text(r."parvalue1"::text)                         AS parvalue1,
        r."parvalue2"::numeric(10,2)                                           AS parvalue2,
        'usedcars'::text AS _source_db, 'parameters'::text AS _source_table, r."parname"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__parameters r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.system_parameter (id, legacy_id, legacy_source, parname, parvalue1, parvalue2,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, parname, parvalue1, parvalue2,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, parname, parvalue1, parvalue2)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        parname = EXCLUDED.parname,
        parvalue1 = EXCLUDED.parvalue1,
        parvalue2 = EXCLUDED.parvalue2,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.system_parameter._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.system_parameter._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'system_parameter', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_system_parameter(bigint) IS 'stg_raw → stg_transform.system_parameter (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_payment.sql
-- ======================================================================
-- stg_transform.sp_transform_payment
-- stg_raw → stg_transform.payment  ·  Destino final: payments_db.payment
-- Lee: stg_raw.usedcars__charges + stg_raw.accesorios__charges
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_payment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_payment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'payment');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__charges)
        + (SELECT count(*) FROM stg_raw.accesorios__charges)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.charges
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.charges', concat_ws('|', r."codigo", r."datein", r."tdinvoicenum")) AS id,
        concat_ws('|', r."codigo", r."datein", r."tdinvoicenum")               AS legacy_id,
        'usedcars.charges'                                                     AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_map_code('PAYMENT_SOURCE', 'usedcars', r."source"::text) AS channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS paid_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_map_code('PAYMENT_FEATURE', 'usedcars', r."feature"::text) AS service_code,
        stg_control.fn_clean_text(r."cname"::text)                             AS cardholder_name,
        stg_control.fn_map_code('CARD_BRAND', 'usedcars', r."ctype"::text)     AS card_brand,
        stg_control.fn_clean_text(r."clast4"::text)::char(4)                   AS card_last4,
        stg_control.fn_clean_text(r."approval"::text)                          AS authorization_code,
        to_jsonb(r."tdresponse")                                               AS gateway_response,  -- POR CONFIRMAR · TODO: evaluar jsonb vs archivo en S3
        stg_control.fn_clean_text(r."tdname"::text)                            AS invoice_name,
        stg_control.fn_clean_email(r."tdemail")                                AS invoice_email,
        stg_control.fn_map_code('ID_TYPE', 'usedcars', r."tdidtype"::text)     AS invoice_id_type,
        stg_control.fn_clean_text(r."tdidnum"::text)                           AS invoice_id_number,
        r."tdclave"::text                                                      AS einvoice_key,
        stg_control.fn_clean_text(r."tdmsg"::text)                             AS einvoice_message,
        stg_control.fn_map_code('EINVOICE_STATUS', 'usedcars', r."tdstatus"::text) AS einvoice_status,
        r."tdinvoicenum"::text                                                 AS invoice_number,
        to_jsonb(r."json")                                                     AS gateway_payload,  -- POR CONFIRMAR · TODO: evaluar jsonb vs archivo en S3
        'usedcars'::text AS _source_db, 'charges'::text AS _source_table, concat_ws('|', r."codigo", r."datein", r."tdinvoicenum") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__charges r
    UNION ALL
    -- ---- accesorios.charges  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('accesorios.charges', md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval"))) AS id,
        md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval")) AS legacy_id,
        'accesorios.charges'                                                   AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_map_code('PAYMENT_SOURCE', 'accesorios', r."source"::text) AS channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS paid_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_map_code('PAYMENT_FEATURE', 'accesorios', r."feature"::text) AS service_code,
        stg_control.fn_clean_text(r."cname"::text)                             AS cardholder_name,
        stg_control.fn_map_code('CARD_BRAND', 'accesorios', r."ctype"::text)   AS card_brand,
        stg_control.fn_clean_text(r."clast4"::text)::char(4)                   AS card_last4,
        stg_control.fn_clean_text(r."approval"::text)                          AS authorization_code,
        NULL::jsonb                                                            AS gateway_response,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_name,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_email,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_id_type,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_id_number,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_key,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_message,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_status,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_number,  -- no viene de accesorios.charges
        NULL::jsonb                                                            AS gateway_payload,  -- no viene de accesorios.charges
        'accesorios'::text AS _source_db, 'charges'::text AS _source_table, md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval")) AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__charges r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.payment (id, legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        listing_title_snapshot = EXCLUDED.listing_title_snapshot,
        channel = EXCLUDED.channel,
        paid_at = EXCLUDED.paid_at,
        amount = EXCLUDED.amount,
        service_code = EXCLUDED.service_code,
        cardholder_name = EXCLUDED.cardholder_name,
        card_brand = EXCLUDED.card_brand,
        card_last4 = EXCLUDED.card_last4,
        authorization_code = EXCLUDED.authorization_code,
        gateway_response = EXCLUDED.gateway_response,
        invoice_name = EXCLUDED.invoice_name,
        invoice_email = EXCLUDED.invoice_email,
        invoice_id_type = EXCLUDED.invoice_id_type,
        invoice_id_number = EXCLUDED.invoice_id_number,
        einvoice_key = EXCLUDED.einvoice_key,
        einvoice_message = EXCLUDED.einvoice_message,
        einvoice_status = EXCLUDED.einvoice_status,
        invoice_number = EXCLUDED.invoice_number,
        gateway_payload = EXCLUDED.gateway_payload,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.payment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.payment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'payment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_payment(bigint) IS 'stg_raw → stg_transform.payment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_payment_log.sql
-- ======================================================================
-- stg_transform.sp_transform_payment_log
-- stg_raw → stg_transform.payment_log  ·  Destino final: payments_db.payment_log
-- Lee: stg_raw.usedcars__chargeslog
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_payment_log(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_payment_log(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'payment_log');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__chargeslog)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.chargeslog  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.chargeslog', md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime"))) AS id,
        md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime")) AS legacy_id,
        'usedcars.chargeslog'                                                  AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_to_timestamptz(r."datein")                              AS attempted_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_clean_text(r."fullorder"::text)                         AS order_reference,
        stg_control.fn_clean_text(r."response"::text)                          AS gateway_response_code,
        stg_control.fn_clean_text(r."avsresponse"::text)                       AS avs_result,
        stg_control.fn_clean_text(r."cvvresponse"::text)                       AS cvv_result,
        stg_control.fn_clean_text(r."responsetime"::text)                      AS response_time,
        'usedcars'::text AS _source_db, 'chargeslog'::text AS _source_table, md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime")) AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__chargeslog r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.payment_log (id, legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        listing_title_snapshot = EXCLUDED.listing_title_snapshot,
        attempted_at = EXCLUDED.attempted_at,
        amount = EXCLUDED.amount,
        order_reference = EXCLUDED.order_reference,
        gateway_response_code = EXCLUDED.gateway_response_code,
        avs_result = EXCLUDED.avs_result,
        cvv_result = EXCLUDED.cvv_result,
        response_time = EXCLUDED.response_time,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.payment_log._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.payment_log._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'payment_log', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_payment_log(bigint) IS 'stg_raw → stg_transform.payment_log (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_prepayment.sql
-- ======================================================================
-- stg_transform.sp_transform_prepayment
-- stg_raw → stg_transform.prepayment  ·  Destino final: payments_db.prepayment
-- Lee: stg_raw.usedcars__prepay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_prepayment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_prepayment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'prepayment');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__prepay)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.prepay
    -- No se migran: ppip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.prepay', concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal")) AS id,
        concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal")                 AS legacy_id,
        'usedcars.prepay'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."ppuser"::text)                            AS performed_by,
        stg_control.fn_legacy_uuid('usedcars.sellers', r."ppseller"::text) /* TODO: confirmar que sellers.sellercode es la PK del padre */ AS seller_id,
        stg_control.fn_map_code('PREPAY_TYPE', 'usedcars', r."ppttype"::text)  AS movement_type,
        stg_control.fn_to_timestamptz(r."ppdate")                              AS movement_at,
        r."ppamount"::numeric(12,2)                                            AS amount,
        stg_control.fn_clean_text(r."ppdetail"::text)                          AS detail,
        stg_control.fn_clean_text(r."ppcomment"::text)                         AS comment,
        r."ppprevbal"::numeric(12,2)                                           AS previous_balance,
        r."ppnewbal"::numeric(12,2)                                            AS new_balance,
        'usedcars'::text AS _source_db, 'prepay'::text AS _source_table, concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__prepay r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.prepayment (id, legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        performed_by = EXCLUDED.performed_by,
        seller_id = EXCLUDED.seller_id,
        movement_type = EXCLUDED.movement_type,
        movement_at = EXCLUDED.movement_at,
        amount = EXCLUDED.amount,
        detail = EXCLUDED.detail,
        comment = EXCLUDED.comment,
        previous_balance = EXCLUDED.previous_balance,
        new_balance = EXCLUDED.new_balance,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.prepayment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.prepayment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'prepayment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_prepayment(bigint) IS 'stg_raw → stg_transform.prepayment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_coupon.sql
-- ======================================================================
-- stg_transform.sp_transform_coupon
-- stg_raw → stg_transform.coupon  ·  Destino final: payments_db.coupon
-- Lee: stg_raw.usedcars__coupons + stg_raw.accesorios__coupons
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_coupon(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_coupon(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'coupon');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__coupons)
        + (SELECT count(*) FROM stg_raw.accesorios__coupons)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.coupons
    SELECT
        stg_control.fn_legacy_uuid('usedcars.coupons', r."ccoupon"::text)      AS id,
        r."ccoupon"::text                                                      AS legacy_id,
        'usedcars.coupons'                                                     AS legacy_source,
        upper(stg_control.fn_clean_text(r."ccoupon"))                          AS code,
        stg_control.fn_to_date(r."cactivedate")                                AS valid_from,
        stg_control.fn_to_date(r."cexpdate")                                   AS valid_to,
        stg_control.fn_to_date(r."cdateused")                                  AS used_at,
        stg_control.fn_legacy_uuid('listing', r."cadcode"::text)               AS listing_id,
        stg_control.fn_map_code('COUPON_TYPE', 'usedcars', r."ctype"::text)    AS coupon_type,
        stg_control.fn_clean_text(r."creference"::text)                        AS reference,
        'usedcars'::text AS _source_db, 'coupons'::text AS _source_table, r."ccoupon"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__coupons r
    UNION ALL
    -- ---- accesorios.coupons
    SELECT
        stg_control.fn_legacy_uuid('accesorios.coupons', r."ccoupon"::text)    AS id,
        r."ccoupon"::text                                                      AS legacy_id,
        'accesorios.coupons'                                                   AS legacy_source,
        upper(stg_control.fn_clean_text(r."ccoupon"))                          AS code,
        stg_control.fn_to_date(r."cactivedate")                                AS valid_from,
        stg_control.fn_to_date(r."cexpdate")                                   AS valid_to,
        stg_control.fn_to_date(r."cdateused")                                  AS used_at,
        stg_control.fn_legacy_uuid('listing', r."cadcode"::text)               AS listing_id,
        stg_control.fn_map_code('COUPON_TYPE', 'accesorios', r."ctype"::text)  AS coupon_type,
        stg_control.fn_clean_text(r."creference"::text)                        AS reference,
        'accesorios'::text AS _source_db, 'coupons'::text AS _source_table, r."ccoupon"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__coupons r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.coupon (id, legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        code = EXCLUDED.code,
        valid_from = EXCLUDED.valid_from,
        valid_to = EXCLUDED.valid_to,
        used_at = EXCLUDED.used_at,
        listing_id = EXCLUDED.listing_id,
        coupon_type = EXCLUDED.coupon_type,
        reference = EXCLUDED.reference,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.coupon._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.coupon._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'coupon', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_coupon(bigint) IS 'stg_raw → stg_transform.coupon (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_auto_renewal.sql
-- ======================================================================
-- stg_transform.sp_transform_auto_renewal
-- stg_raw → stg_transform.auto_renewal  ·  Destino final: payments_db.auto_renewal
-- Lee: stg_raw.usedcars__autorenewhl
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_auto_renewal(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_auto_renewal(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'auto_renewal');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__autorenewhl)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.autorenewhl
    SELECT
        stg_control.fn_legacy_uuid('usedcars.autorenewhl', concat_ws('|', r."datein", r."renewdate")) AS id,
        concat_ws('|', r."datein", r."renewdate")                              AS legacy_id,
        'usedcars.autorenewhl'                                                 AS legacy_source,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."renewdate")                           AS renew_at,
        stg_control.fn_legacy_uuid('listing', r."adcode"::text)                AS listing_id,
        stg_control.fn_to_timestamptz(r."rstatus")                             AS last_run_at,
        'usedcars'::text AS _source_db, 'autorenewhl'::text AS _source_table, concat_ws('|', r."datein", r."renewdate") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__autorenewhl r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.auto_renewal (id, legacy_id, legacy_source, created_at, renew_at, listing_id, last_run_at,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, created_at, renew_at, listing_id, last_run_at,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, created_at, renew_at, listing_id, last_run_at)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        created_at = EXCLUDED.created_at,
        renew_at = EXCLUDED.renew_at,
        listing_id = EXCLUDED.listing_id,
        last_run_at = EXCLUDED.last_run_at,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.auto_renewal._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.auto_renewal._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'auto_renewal', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_auto_renewal(bigint) IS 'stg_raw → stg_transform.auto_renewal (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_einvoice_document.sql
-- ======================================================================
-- stg_transform.sp_transform_einvoice_document
-- stg_raw → stg_transform.einvoice_document  ·  Destino final: payments_db.einvoice_document
-- Lee: stg_raw.usedcars__tdtickets + stg_raw.usedcars__mttdtickets + stg_raw.usedcars__tdinvoices
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_einvoice_document(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_einvoice_document(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'einvoice_document');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__tdtickets)
        + (SELECT count(*) FROM stg_raw.usedcars__mttdtickets)
        + (SELECT count(*) FROM stg_raw.usedcars__tdinvoices)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.tdtickets
    SELECT
        stg_control.fn_legacy_uuid('usedcars.tdtickets', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.tdtickets'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'tdtickets'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__tdtickets r
    UNION ALL
    -- ---- usedcars.mttdtickets
    SELECT
        stg_control.fn_legacy_uuid('usedcars.mttdtickets', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.mttdtickets'                                                 AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'mttdtickets'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__mttdtickets r
    UNION ALL
    -- ---- usedcars.tdinvoices
    SELECT
        stg_control.fn_legacy_uuid('usedcars.tdinvoices', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.tdinvoices'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'tdinvoices'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__tdinvoices r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.einvoice_document (id, legacy_id, legacy_source, document_number, einvoice_key,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, document_number, einvoice_key,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, document_number, einvoice_key)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        document_number = EXCLUDED.document_number,
        einvoice_key = EXCLUDED.einvoice_key,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.einvoice_document._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.einvoice_document._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'einvoice_document', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_einvoice_document(bigint) IS 'stg_raw → stg_transform.einvoice_document (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/00_sp_transform_all.sql
-- ======================================================================
-- stg_transform.sp_transform_all · Orquestador stg_raw → stg_transform
-- Orden: catálogos → usuarios → publicaciones → relaciones de usuario → seguridad → pagos.
-- Como los UUID son determinísticos, el orden no es obligatorio para transformar;
-- sí lo es para sp_validate (FK contra la entidad padre ya transformada).
-- COMMIT por entidad: si una falla, queda FAILED en step_log y se sigue con la siguiente.
-- Uso (fuera de un bloque de transacción):  CALL stg_transform.sp_transform_all(NULL);
-- -- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_all(p_run_id bigint DEFAULT NULL, p_run_type text DEFAULT 'FULL')
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_run_id IS NULL THEN
        INSERT INTO stg_control.migration_run (run_type, status, triggered_by)
        VALUES (p_run_type, 'RUNNING', current_user)
        RETURNING run_id INTO p_run_id;
        COMMIT;
    END IF;

    CALL stg_transform.sp_transform_brand(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_body_style(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_province(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_equipment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_accessory_section(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_model(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_app_user(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_seller(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_dealer(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_dealer_contact(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_admin_user(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_transfer(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_image(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_equipment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_special_deal(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_banner(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_accessory_listing(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_favorite(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_friend(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_request(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_suggestion(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_report(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_blocked_contact(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_ip_allowlist(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_system_parameter(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_payment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_payment_log(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_prepayment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_coupon(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_auto_renewal(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_einvoice_document(p_run_id);  COMMIT;

    UPDATE stg_control.migration_run
       SET status = CASE WHEN EXISTS (SELECT 1 FROM stg_control.step_log
                                       WHERE run_id = p_run_id AND step_name = 'sp_transform' AND status = 'FAILED')
                         THEN 'FAILED' ELSE 'SUCCESS' END,
           finished_at = now()
     WHERE run_id = p_run_id;
    COMMIT;
    RAISE NOTICE 'sp_transform_all terminado · run_id = %', p_run_id;
END;
$$;

