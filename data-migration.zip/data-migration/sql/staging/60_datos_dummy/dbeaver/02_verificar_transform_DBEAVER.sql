-- ======================================================================
-- 60_datos_dummy · Verificación de sp_transform_all con datos dummy
-- Correr después de:  CALL stg_transform.sp_transform_all(NULL);
-- Versión DBeaver: ejecutar con Alt+X; cada consulta abre su pestaña de resultados.
-- Los NOTICE de las secciones 4, 5 y 6 salen en la pestaña "Output" (activar con Ctrl+Shift+O).
-- Revisa la última corrida (max run_id): estado, filas por entidad, errores,
-- limpieza (emails / teléfonos), valores UNMAPPED y la prueba de idempotencia.
-- Autor: Andrés Varela (Ingeniería de Datos) · 29/10/2026
-- ======================================================================

-- == 1. Estado de la corrida
SELECT run_id, run_type, status, started_at, finished_at, finished_at - started_at AS duracion
FROM stg_control.migration_run WHERE run_id = (SELECT max(run_id) FROM stg_control.migration_run);

-- == 2. Resultado por entidad (esperado: 32 filas, todas SUCCESS)
SELECT entity, status, rows_in, rows_ok, rows_error, rows_warning, left(message, 80) AS message
FROM stg_control.step_log WHERE run_id = (SELECT max(run_id) FROM stg_control.migration_run) ORDER BY step_id;

-- == 3. Errores registrados (esperado: 0)
SELECT entity, rule_code, severity, left(detail, 100) AS detail, count(*)
FROM stg_control.error_record WHERE run_id = (SELECT max(run_id) FROM stg_control.migration_run)
GROUP BY 1, 2, 3, 4 ORDER BY 5 DESC;

-- == 4. Emails que no quedaron en minúscula/sin espacios (esperado: 0 en todas)
DO $$ DECLARE r record; n bigint; BEGIN
FOR r IN SELECT table_name, column_name FROM information_schema.columns
         WHERE table_schema = 'stg_transform' AND column_name ILIKE '%email%' AND data_type = 'text' LOOP
  EXECUTE format('SELECT count(*) FROM stg_transform.%I WHERE %I <> lower(trim(%I))',
                 r.table_name, r.column_name, r.column_name) INTO n;
  IF n > 0 THEN RAISE NOTICE 'EMAIL sucio  %.% = %', r.table_name, r.column_name, n; END IF;
END LOOP; END $$;

-- == 5. Teléfonos con caracteres no numéricos o más de 8 dígitos
--    (conocido: listing.contact_phone y listing_transfer.contact_phone, origen trae "tel1 / tel2")
DO $$ DECLARE r record; n bigint; BEGIN
FOR r IN SELECT table_name, column_name FROM information_schema.columns
         WHERE table_schema = 'stg_transform' AND column_name ILIKE '%phone%'
           AND column_name NOT ILIKE '%label%' AND data_type = 'text' LOOP
  EXECUTE format('SELECT count(*) FROM stg_transform.%I WHERE %I ~ ''[^0-9]'' OR length(%I) > 8',
                 r.table_name, r.column_name, r.column_name) INTO n;
  IF n > 0 THEN RAISE NOTICE 'TEL sucio  %.% = %', r.table_name, r.column_name, n; END IF;
END LOOP; END $$;

-- == 6. Valores UNMAPPED: por columna (esperados mientras map_catalog esté vacío)
DO $$ DECLARE r record; n bigint; BEGIN
FOR r IN SELECT table_name, column_name FROM information_schema.columns
         WHERE table_schema = 'stg_transform' AND data_type = 'text' AND column_name NOT LIKE '\_%' LOOP
  EXECUTE format('SELECT count(*) FROM stg_transform.%I WHERE %I LIKE ''UNMAPPED:%%''',
                 r.table_name, r.column_name) INTO n;
  IF n > 0 THEN RAISE NOTICE 'UNMAPPED  %.% = %', r.table_name, r.column_name, n; END IF;
END LOOP; END $$;

-- == 7. Fechas: casos de borde (0000/00/00 y vacío deben dar NULL)
SELECT v AS valor_origen, stg_control.fn_to_timestamptz(v) AS resultado
FROM (VALUES ('0000/00/00'), (''), ('2024/05/17'), ('2024-05-17 10:22:00'), ('17/05/2024')) x(v);

-- == 8. Idempotencia: filas modificadas por esta corrida en algunas tablas
--    (1.ª corrida = todas; 2.ª corrida sin cambios en stg_raw = 0)
SELECT 'listing' AS tabla, count(*) FILTER (WHERE _run_id = (SELECT max(run_id) FROM stg_control.migration_run)) AS tocadas, count(*) AS total FROM stg_transform.listing
UNION ALL SELECT 'app_user', count(*) FILTER (WHERE _run_id = (SELECT max(run_id) FROM stg_control.migration_run)), count(*) FROM stg_transform.app_user
UNION ALL SELECT 'listing_equipment', count(*) FILTER (WHERE _run_id = (SELECT max(run_id) FROM stg_control.migration_run)), count(*) FROM stg_transform.listing_equipment
UNION ALL SELECT 'payment', count(*) FILTER (WHERE _run_id = (SELECT max(run_id) FROM stg_control.migration_run)), count(*) FROM stg_transform.payment;
