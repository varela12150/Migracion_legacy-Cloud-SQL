-- Paso 2d · stg_validated: 32 tablas (versión DBeaver). Ejecutar con Alt+X, Auto-Commit activado.

-- ===== 30_stg_validated/04_catalogos/brand.sql
-- ======================================================================
-- stg_validated.brand
-- Dominio: Catalogos · Destino final: listings_db.brand
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.brands  →  stg_raw.usedcars__brands
--   - newcars.brands  →  stg_raw.newcars__brands
--   - usedcars.premiumbrands  →  stg_raw.usedcars__premiumbrands
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.brand (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    status                       text,
    video_url                    text,
    expo_status                  text,
    brand_id                     uuid,
    premium_min_year             smallint,
    premium_min_price            numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_brand PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.brand IS 'Origen: usedcars.brands, newcars.brands, usedcars.premiumbrands. Destino: listings_db.brand';
COMMENT ON COLUMN stg_validated.brand.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.brand.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.brand.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.brand.name IS 'Homologado: initcap(trim()); unificar con newcars.brands';
COMMENT ON COLUMN stg_validated.brand.status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_validated.brand.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.brand.expo_status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_validated.brand.brand_id IS 'Por confirmar: Lookup brand por premiumid = usedcars.brands.brandid';
COMMENT ON COLUMN stg_validated.brand.premium_min_year IS 'Transformado: Copiar como regla de marca premium';
COMMENT ON COLUMN stg_validated.brand.premium_min_price IS 'Transformado: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_brand_src ON stg_validated.brand (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_brand_brand_id ON stg_validated.brand (brand_id);


-- ===== 30_stg_validated/04_catalogos/body_style.sql
-- ======================================================================
-- stg_validated.body_style
-- Dominio: Catalogos · Destino final: listings_db.body_style
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.styles  →  stg_raw.usedcars__styles
--   - newcars.styles  →  stg_raw.newcars__styles
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.body_style (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_body_style PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.body_style IS 'Origen: usedcars.styles, newcars.styles. Destino: listings_db.body_style';
COMMENT ON COLUMN stg_validated.body_style.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.body_style.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.body_style.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.body_style.name IS 'Homologado: trim(); unificar con newcars.styles';
CREATE INDEX IF NOT EXISTS ix_validated_body_style_src ON stg_validated.body_style (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/04_catalogos/province.sql
-- ======================================================================
-- stg_validated.province
-- Dominio: Catalogos · Destino final: listings_db.province
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.provinces  →  stg_raw.usedcars__provinces
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.province (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_province PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.province IS 'Origen: usedcars.provinces. Destino: listings_db.province';
COMMENT ON COLUMN stg_validated.province.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.province.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.province.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.province.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_province_src ON stg_validated.province (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/03_publicaciones/equipment.sql
-- ======================================================================
-- stg_validated.equipment
-- Dominio: Publicaciones · Destino final: listings_db.equipment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.carextras  →  stg_raw.usedcars__carextras
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_equipment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.equipment IS 'Origen: usedcars.carextras. Destino: listings_db.equipment';
COMMENT ON COLUMN stg_validated.equipment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.equipment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.equipment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.equipment.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_equipment_src ON stg_validated.equipment (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/05_accesorios/accessory_section.sql
-- ======================================================================
-- stg_validated.accessory_section
-- Dominio: Accesorios · Destino final: listings_db.accessory_section
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.sections  →  stg_raw.accesorios__sections
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.accessory_section (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_accessory_section PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.accessory_section IS 'Origen: accesorios.sections. Destino: listings_db.accessory_section';
COMMENT ON COLUMN stg_validated.accessory_section.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.accessory_section.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.accessory_section.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.accessory_section.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_accessory_section_src ON stg_validated.accessory_section (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/04_catalogos/model.sql
-- ======================================================================
-- stg_validated.model
-- Dominio: Catalogos · Destino final: listings_db.model
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.models  →  stg_raw.newcars__models
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.model (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    brand_id                     uuid,
    base_model                   text,
    body_style_id                uuid,
    image_prefix                 text,
    year                         smallint,
    price                        numeric(14,2),
    mdescrip                     text,
    motherspecs                  text,
    mmaintext                    text,
    mnumpics                     integer,
    mnumvideos                   integer,
    mequipment                   text,
    mmotor                       text,
    menginesize                  integer,
    mpower                       text,
    mtorque                      text,
    msuspension                  text,
    msteering                    text,
    mtransmission                text,
    mtransmission2               text,
    mbrakes                      text,
    mtires                       text,
    mwarranty                    text,
    mfuel                        text,
    mdrive                       text,
    mfueltank                    text,
    mmaxspeed                    text,
    mvalves                      integer,
    mdoors                       integer,
    is_visible                   boolean,
    mweight                      text,
    mheight                      text,
    mwidth                       text,
    mlength                      text,
    mdiameter                    text,
    mvideo1                      text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_model PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.model IS 'Origen: newcars.models. Destino: listings_db.model';
COMMENT ON COLUMN stg_validated.model.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.model.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.model.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.model.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_validated.model.brand_id IS 'Derivado: Lookup UUID de brand a partir de newcars.brands.brandid';
COMMENT ON COLUMN stg_validated.model.base_model IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de newcars.styles.styleid';
COMMENT ON COLUMN stg_validated.model.image_prefix IS 'Derivado: Enlace con imágenes en S3';
COMMENT ON COLUMN stg_validated.model.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.model.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mdescrip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.motherspecs IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmaintext IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mnumpics IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mnumvideos IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mequipment IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmotor IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.menginesize IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mpower IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtorque IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.msuspension IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.msteering IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtransmission IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtransmission2 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mbrakes IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtires IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mwarranty IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mfuel IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mdrive IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mfueltank IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmaxspeed IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mvalves IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mdoors IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.is_visible IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.model.mweight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mheight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mwidth IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mlength IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mdiameter IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mvideo1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_model_src ON stg_validated.model (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_model_dealer_id ON stg_validated.model (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_model_brand_id ON stg_validated.model (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_model_body_style_id ON stg_validated.model (body_style_id);


-- ===== 30_stg_validated/01_usuarios/app_user.sql
-- ======================================================================
-- stg_validated.app_user
-- Dominio: Usuarios · Destino final: users_db.app_user
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.users  →  stg_raw.micrautos__users
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.app_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    first_name                   text,
    last_name                    text,
    id_type                      text,
    id_number                    text,
    birth_date                   date,
    gender                       text,
    email                        text,
    created_at                   date,
    last_login_at                timestamptz,
    status                       text,
    address_line1                text,
    address_line2                text,
    city                         text,
    country                      text,
    postal_code                  text,
    phone_home                   text,
    phone_work                   text,
    phone_mobile                 text,
    free_ad_flag                 text,
    accepts_email                boolean,
    nickname                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_app_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.app_user IS 'Origen: micrautos.users. Destino: users_db.app_user';
COMMENT ON COLUMN stg_validated.app_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.app_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.app_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.app_user.first_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.last_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_validated.app_user.id_number IS 'Transformado: trim(); quitar guiones y espacios';
COMMENT ON COLUMN stg_validated.app_user.birth_date IS 'Derivado: make_date(uyear, umonth, uday); inválida → NULL + WARNING';
COMMENT ON COLUMN stg_validated.app_user.gender IS 'Homologado: Homologar con stg_control.map_catalog (GENDER)';
COMMENT ON COLUMN stg_validated.app_user.email IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_validated.app_user.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.app_user.last_login_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.app_user.status IS 'Homologado: Homologar con stg_control.map_catalog (USER_STATUS)';
COMMENT ON COLUMN stg_validated.app_user.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.country IS 'Homologado: Homologar con stg_control.map_catalog (COUNTRY)';
COMMENT ON COLUMN stg_validated.app_user.postal_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.phone_home IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.phone_work IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.phone_mobile IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.free_ad_flag IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.app_user.accepts_email IS 'Transformado: Valores sí/no → boolean';
COMMENT ON COLUMN stg_validated.app_user.nickname IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_app_user_src ON stg_validated.app_user (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/01_usuarios/seller.sql
-- ======================================================================
-- stg_validated.seller
-- Dominio: Usuarios · Destino final: users_db.seller
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.sellers  →  stg_raw.usedcars__sellers
--   - accesorios.sellers  →  stg_raw.accesorios__sellers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.seller (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    phone                        text,
    email                        text,
    start_date                   date,
    expiration_date              date,
    ad_limit                     integer,
    status                       text,
    seller_code                  text,
    plan_amount                  numeric(12,2),
    website                      text,
    plan_amount_usd              numeric(12,2),
    featured_quota               integer,
    department                   text,
    currency                     text,
    address_line1                text,
    address_line2                text,
    province_id                  text,
    city                         text,
    offers_financing             boolean,
    account_balance              numeric(12,2),
    last_deposit_at              timestamptz,
    last_charge_at               timestamptz,
    banner_start_date            date,
    banner_end_date              date,
    is_premium                   boolean,
    video_html                   text,
    whatsapp                     text,
    sales_rep                    text,
    contact_name                 text,
    contact_phone                text,
    contact_email                text,
    phone_2                      text,
    phone_3                      text,
    logo_s3_key                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_seller PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.seller IS 'Origen: usedcars.sellers, accesorios.sellers. Destino: users_db.seller';
COMMENT ON COLUMN stg_validated.seller.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.seller.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.seller.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.seller.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.email IS 'Transformado: lower(trim()); legacy_id = selleremail';
COMMENT ON COLUMN stg_validated.seller.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.expiration_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.ad_limit IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.status IS 'Homologado: Homologar con stg_control.map_catalog (SELLER_STATUS)';
COMMENT ON COLUMN stg_validated.seller.seller_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.plan_amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.plan_amount_usd IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.seller.featured_quota IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.department IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.seller.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.province_id IS 'Homologado: Homologar con stg_control.map_catalog (PROVINCE)';
COMMENT ON COLUMN stg_validated.seller.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.offers_financing IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.seller.account_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.seller.last_deposit_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.seller.last_charge_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.seller.banner_start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.banner_end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.seller.is_premium IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.seller.video_html IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.sales_rep IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.seller.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.contact_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.seller.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.seller.logo_s3_key IS 'Derivado: Ruta → clave en S3 (proceso de imágenes)';
CREATE INDEX IF NOT EXISTS ix_validated_seller_src ON stg_validated.seller (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/01_usuarios/dealer.sql
-- ======================================================================
-- stg_validated.dealer
-- Dominio: Usuarios · Destino final: users_db.dealer
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.dealers  →  stg_raw.usedcars__dealers
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.dealer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    website                      text,
    email                        text,
    address                      text,
    notes                        text,
    username                     text,
    email_2                      text,
    email_3                      text,
    seller_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_dealer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.dealer IS 'Origen: usedcars.dealers, newcars.dealers. Destino: users_db.dealer';
COMMENT ON COLUMN stg_validated.dealer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.dealer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.dealer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.dealer.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.dealer.address IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.username IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.dealer.email_2 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.dealer.email_3 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.dealer.seller_code IS 'Por confirmar: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_dealer_src ON stg_validated.dealer (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/01_usuarios/dealer_contact.sql
-- ======================================================================
-- stg_validated.dealer_contact
-- Dominio: Usuarios · Destino final: users_db.dealer_contact
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.dealer_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    phone                        text,
    phone_label                  text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_dealer_contact PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.dealer_contact.phone IS 'dphoneN normalizado';
COMMENT ON COLUMN stg_validated.dealer_contact.phone_label IS 'dphonerefN';
COMMENT ON COLUMN stg_validated.dealer_contact.sort_order IS 'N del par dphoneN/dphonerefN';
CREATE INDEX IF NOT EXISTS ix_validated_dealer_contact_src ON stg_validated.dealer_contact (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_dealer_contact_dealer_id ON stg_validated.dealer_contact (dealer_id);


-- ===== 30_stg_validated/01_usuarios/admin_user.sql
-- ======================================================================
-- stg_validated.admin_user
-- Dominio: Usuarios · Destino final: users_db.admin_user
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.adminusers  →  stg_raw.usedcars__adminusers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.admin_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    username                     text,
    role                         text,
    full_name                    text,
    phone                        text,
    position                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_admin_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.admin_user IS 'Origen: usedcars.adminusers. Destino: users_db.admin_user';
COMMENT ON COLUMN stg_validated.admin_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.admin_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.admin_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.admin_user.username IS 'Transformado: trim(); legacy_id = userid';
COMMENT ON COLUMN stg_validated.admin_user.role IS 'Homologado: Homologar con stg_control.map_catalog (ADMIN_LEVEL)';
COMMENT ON COLUMN stg_validated.admin_user.full_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.admin_user.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.admin_user.position IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_admin_user_src ON stg_validated.admin_user (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/03_publicaciones/listing.sql
-- ======================================================================
-- stg_validated.listing
-- Dominio: Publicaciones · Destino final: listings_db.listing
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    publication_lifecycle        text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    transfer_cost                numeric(14,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    image_count                  smallint,
    fuel_type                    text,
    ev_range                     numeric(8,1),
    ev_range_unit                text,
    battery_kwh                  numeric(6,1),
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    mileage_unit                 text,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.listing IS 'Origen: usedcars.datafile, usedcars.archive, usedcars.expiredsellers, usedcars.pending, usedcars.pendingpay. Destino: listings_db.listing';
COMMENT ON COLUMN stg_validated.listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.listing.publication_lifecycle IS 'Derivado: Según tabla origen: datafile → ACTIVE · archive → ARCHIVED · expiredsellers → EXPIRED · pending → PENDING_APPROVAL · pendingpay → PENDING_PA';
COMMENT ON COLUMN stg_validated.listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_validated.listing.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_validated.listing.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_validated.listing.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.transfer_cost IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_validated.listing.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_validated.listing.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.image_count IS 'Derivado: Validación: debe coincidir con fotos migradas';
COMMENT ON COLUMN stg_validated.listing.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_validated.listing.ev_range IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.ev_range_unit IS 'Homologado: Homologar con stg_control.map_catalog (RANGE_UNIT)';
COMMENT ON COLUMN stg_validated.listing.battery_kwh IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_validated.listing.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_validated.listing.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.mileage_unit IS 'Homologado: Homologar con stg_control.map_catalog (MILEAGE_UNIT)';
COMMENT ON COLUMN stg_validated.listing.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_validated.listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_validated.listing.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_validated.listing.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_validated.listing.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.listing.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_validated_listing_src ON stg_validated.listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_dealer_id ON stg_validated.listing (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_brand_id ON stg_validated.listing (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_body_style_id ON stg_validated.listing (body_style_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_province_id ON stg_validated.listing (province_id);


-- ===== 30_stg_validated/03_publicaciones/listing_transfer.sql
-- ======================================================================
-- stg_validated.listing_transfer
-- Dominio: Publicaciones · Destino final: listings_db.listing_transfer
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing_transfer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    certification                text,
    fuel_type                    text,
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing_transfer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.listing_transfer IS 'Origen: usedcars.archivetraspaso. Destino: listings_db.listing_transfer';
COMMENT ON COLUMN stg_validated.listing_transfer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.listing_transfer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.listing_transfer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.listing_transfer.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_validated.listing_transfer.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_validated.listing_transfer.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing_transfer.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_validated.listing_transfer.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_validated.listing_transfer.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_validated.listing_transfer.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.certification IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_validated.listing_transfer.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_validated.listing_transfer.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_validated.listing_transfer.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_validated.listing_transfer.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing_transfer.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.listing_transfer.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing_transfer.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_validated.listing_transfer.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing_transfer.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_validated.listing_transfer.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_validated.listing_transfer.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing_transfer.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing_transfer.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing_transfer.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.listing_transfer.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_src ON stg_validated.listing_transfer (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_dealer_id ON stg_validated.listing_transfer (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_brand_id ON stg_validated.listing_transfer (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_body_style_id ON stg_validated.listing_transfer (body_style_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_transfer_province_id ON stg_validated.listing_transfer (province_id);


-- ===== 30_stg_validated/03_publicaciones/listing_image.sql
-- ======================================================================
-- stg_validated.listing_image
-- Dominio: Publicaciones · Destino final: listings_db.listing_image
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing_image (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    s3_key                       text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing_image PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.listing_image.s3_key IS 'Nombre de archivo origen → clave S3';
COMMENT ON COLUMN stg_validated.listing_image.sort_order IS 'Orden de la foto';
CREATE INDEX IF NOT EXISTS ix_validated_listing_image_src ON stg_validated.listing_image (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_image_listing_id ON stg_validated.listing_image (listing_id);


-- ===== 30_stg_validated/03_publicaciones/listing_equipment.sql
-- ======================================================================
-- stg_validated.listing_equipment
-- Dominio: Publicaciones · Destino final: listings_db.listing_equipment
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing_equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    equipment_id                 uuid,
    feature_slot                 smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing_equipment PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.listing_equipment.feature_slot IS 'Posición f1..f40 en el origen';
CREATE INDEX IF NOT EXISTS ix_validated_listing_equipment_src ON stg_validated.listing_equipment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_equipment_listing_id ON stg_validated.listing_equipment (listing_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_equipment_equipment_id ON stg_validated.listing_equipment (equipment_id);


-- ===== 30_stg_validated/03_publicaciones/special_deal.sql
-- ======================================================================
-- stg_validated.special_deal
-- Dominio: Publicaciones · Destino final: listings_db.special_deal
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.specialdeals  →  stg_raw.usedcars__specialdeals
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.special_deal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    deal_date                    date,
    deal_price                   numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_special_deal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.special_deal IS 'Origen: usedcars.specialdeals. Destino: listings_db.special_deal';
COMMENT ON COLUMN stg_validated.special_deal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.special_deal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.special_deal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.special_deal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.special_deal.deal_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.special_deal.deal_price IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_special_deal_src ON stg_validated.special_deal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_special_deal_listing_id ON stg_validated.special_deal (listing_id);


-- ===== 30_stg_validated/03_publicaciones/banner.sql
-- ======================================================================
-- stg_validated.banner
-- Dominio: Publicaciones · Destino final: listings_db.banner
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.mainbanners  →  stg_raw.newcars__mainbanners
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.banner (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    client_name                  text,
    image_s3_key                 text,
    link_url                     text,
    mobile_link_url              text,
    link_target                  text,
    start_date                   date,
    end_date                     date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_banner PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.banner IS 'Origen: newcars.mainbanners. Destino: listings_db.banner';
COMMENT ON COLUMN stg_validated.banner.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.banner.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.banner.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.banner.client_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.image_s3_key IS 'Derivado: Archivo → clave S3';
COMMENT ON COLUMN stg_validated.banner.link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.mobile_link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.link_target IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.banner.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.banner.end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_validated_banner_src ON stg_validated.banner (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/05_accesorios/accessory_listing.sql
-- ======================================================================
-- stg_validated.accessory_listing
-- Dominio: Accesorios · Destino final: listings_db.accessory_listing
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.archive  →  stg_raw.accesorios__archive
--   - accesorios.pendingpay  →  stg_raw.accesorios__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.accessory_listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    condition_code               text,
    created_at                   timestamptz,
    expires_at                   timestamptz,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    visit_count                  integer,
    image_count                  smallint,
    contact_name                 text,
    contact_email                text,
    phone                        text,
    phone_2                      text,
    phone_3                      text,
    price                        numeric(14,2),
    currency                     text,
    reference_price              numeric(14,2),
    title                        text,
    description                  text,
    section_id                   uuid,
    deleted_at                   date,
    deleted_by                   text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_accessory_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.accessory_listing IS 'Origen: accesorios.archive, accesorios.pendingpay. Destino: listings_db.accessory_listing';
COMMENT ON COLUMN stg_validated.accessory_listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.accessory_listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.accessory_listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.accessory_listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (ACC_ESTADO)';
COMMENT ON COLUMN stg_validated.accessory_listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.accessory_listing.expires_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.accessory_listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.visit_count IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.image_count IS 'Derivado: Validación con imágenes';
COMMENT ON COLUMN stg_validated.accessory_listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.contact_email IS 'Derivado: lower(trim()); resuelve seller_id (accesorios.sellers)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.accessory_listing.reference_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.title IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.section_id IS 'Derivado: Lookup UUID de accessory_section a partir de accesorios.sections.sectionid';
COMMENT ON COLUMN stg_validated.accessory_listing.deleted_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.accessory_listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_accessory_listing_src ON stg_validated.accessory_listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_accessory_listing_section_id ON stg_validated.accessory_listing (section_id);


-- ===== 30_stg_validated/01_usuarios/user_favorite.sql
-- ======================================================================
-- stg_validated.user_favorite
-- Dominio: Usuarios · Destino final: users_db.user_favorite
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.favorites  →  stg_raw.micrautos__favorites
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_favorite (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    favorite_type                text,
    created_at                   timestamptz,
    notes                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_favorite PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_favorite IS 'Origen: micrautos.favorites. Destino: users_db.user_favorite';
COMMENT ON COLUMN stg_validated.user_favorite.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_favorite.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_favorite.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_favorite.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_favorite.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.user_favorite.favorite_type IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.user_favorite.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.user_favorite.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_user_favorite_src ON stg_validated.user_favorite (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_favorite_user_id ON stg_validated.user_favorite (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_favorite_listing_id ON stg_validated.user_favorite (listing_id);


-- ===== 30_stg_validated/01_usuarios/user_friend.sql
-- ======================================================================
-- stg_validated.user_friend
-- Dominio: Usuarios · Destino final: users_db.user_friend
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.friends  →  stg_raw.micrautos__friends
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_friend (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    friend_user_id               uuid,
    created_at                   date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_friend PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_friend IS 'Origen: micrautos.friends. Destino: users_db.user_friend';
COMMENT ON COLUMN stg_validated.user_friend.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_friend.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_friend.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_friend.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_friend.friend_user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_friend.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_validated_user_friend_src ON stg_validated.user_friend (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_friend_user_id ON stg_validated.user_friend (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_friend_friend_user_id ON stg_validated.user_friend (friend_user_id);


-- ===== 30_stg_validated/01_usuarios/user_request.sql
-- ======================================================================
-- stg_validated.user_request
-- Dominio: Usuarios · Destino final: users_db.user_request
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.requests  →  stg_raw.micrautos__requests
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_request (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    dealer_id                    uuid,
    request_type                 text,
    attributes                   jsonb,
    message                      text,
    created_at                   timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_request PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_request IS 'Origen: micrautos.requests. Destino: users_db.user_request';
COMMENT ON COLUMN stg_validated.user_request.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_request.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_request.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_request.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_request.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_validated.user_request.request_type IS 'Homologado: Homologar con stg_control.map_catalog (REQUEST_TYPE)';
COMMENT ON COLUMN stg_validated.user_request.attributes IS 'Derivado: jsonb_build_object(''var1'',var1,''var2'',var2,''var3'',var3)';
COMMENT ON COLUMN stg_validated.user_request.message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.user_request.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
CREATE INDEX IF NOT EXISTS ix_validated_user_request_src ON stg_validated.user_request (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_request_user_id ON stg_validated.user_request (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_request_dealer_id ON stg_validated.user_request (dealer_id);


-- ===== 30_stg_validated/01_usuarios/user_suggestion.sql
-- ======================================================================
-- stg_validated.user_suggestion
-- Dominio: Usuarios · Destino final: users_db.user_suggestion
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.suggestions  →  stg_raw.micrautos__suggestions
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_suggestion (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    created_at                   timestamptz,
    suggestion_text              text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_suggestion PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_suggestion IS 'Origen: micrautos.suggestions. Destino: users_db.user_suggestion';
COMMENT ON COLUMN stg_validated.user_suggestion.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_suggestion.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_suggestion.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_suggestion.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_suggestion.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.user_suggestion.suggestion_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_user_suggestion_src ON stg_validated.user_suggestion (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_suggestion_user_id ON stg_validated.user_suggestion (user_id);


-- ===== 30_stg_validated/01_usuarios/user_report.sql
-- ======================================================================
-- stg_validated.user_report
-- Dominio: Usuarios · Destino final: users_db.user_report
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.userreports  →  stg_raw.micrautos__userreports
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_report (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    created_at                   timestamptz,
    report_text                  text,
    action_taken                 text,
    status                       text,
    report_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_report PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_report IS 'Origen: micrautos.userreports. Destino: users_db.user_report';
COMMENT ON COLUMN stg_validated.user_report.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_report.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_report.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_report.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_report.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.user_report.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.user_report.report_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.user_report.action_taken IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.user_report.status IS 'Homologado: Homologar con stg_control.map_catalog (REPORT_STATUS)';
COMMENT ON COLUMN stg_validated.user_report.report_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_user_report_src ON stg_validated.user_report (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_report_user_id ON stg_validated.user_report (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_report_listing_id ON stg_validated.user_report (listing_id);


-- ===== 30_stg_validated/02_seguridad/blocked_contact.sql
-- ======================================================================
-- stg_validated.blocked_contact
-- Dominio: Seguridad · Destino final: users_db.blocked_contact
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.blocked  →  stg_raw.usedcars__blocked
--   - usedcars.blockedemails  →  stg_raw.usedcars__blockedemails
--   - usedcars.blockedips  →  stg_raw.usedcars__blockedips
--   - usedcars.blockedphones  →  stg_raw.usedcars__blockedphones
--   - usedcars.correosfraude  →  stg_raw.usedcars__correosfraude
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.blocked_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    blockedid                    text,
    blockedname                  text,
    blockedemail                 text,
    ip                           text,
    reason                       text,
    blockedphone                 text,
    codigo                       text,
    emailaddr                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_blocked_contact PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.blocked_contact IS 'Origen: usedcars.blocked, usedcars.blockedemails, usedcars.blockedips, usedcars.blockedphones, usedcars.correosfraude. Destino: users_db.blocked_contact';
COMMENT ON COLUMN stg_validated.blocked_contact.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.blocked_contact.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.blocked_contact.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedid IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedemail IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_validated.blocked_contact.ip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.reason IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.blockedphone IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.codigo IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.blocked_contact.emailaddr IS 'Transformado: lower(trim())';
CREATE INDEX IF NOT EXISTS ix_validated_blocked_contact_src ON stg_validated.blocked_contact (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/02_seguridad/ip_allowlist.sql
-- ======================================================================
-- stg_validated.ip_allowlist
-- Dominio: Seguridad · Destino final: users_db.ip_allowlist
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.ipsaccepted  →  stg_raw.usedcars__ipsaccepted
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.ip_allowlist (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    aip                          text,
    alocation                    text,
    actry                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_ip_allowlist PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.ip_allowlist IS 'Origen: usedcars.ipsaccepted. Destino: users_db.ip_allowlist';
COMMENT ON COLUMN stg_validated.ip_allowlist.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.ip_allowlist.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.ip_allowlist.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.ip_allowlist.aip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.ip_allowlist.alocation IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.ip_allowlist.actry IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_ip_allowlist_src ON stg_validated.ip_allowlist (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/02_seguridad/system_parameter.sql
-- ======================================================================
-- stg_validated.system_parameter
-- Dominio: Seguridad · Destino final: users_db.system_parameter
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.parameters  →  stg_raw.usedcars__parameters
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.system_parameter (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    parname                      text,
    parvalue1                    text,
    parvalue2                    numeric(10,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_system_parameter PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.system_parameter IS 'Origen: usedcars.parameters. Destino: users_db.system_parameter';
COMMENT ON COLUMN stg_validated.system_parameter.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.system_parameter.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.system_parameter.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.system_parameter.parname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.system_parameter.parvalue1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.system_parameter.parvalue2 IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_system_parameter_src ON stg_validated.system_parameter (_source_db, _source_table, _source_pk);


-- ===== 30_stg_validated/06_pagos/payment.sql
-- ======================================================================
-- stg_validated.payment
-- Dominio: Pagos · Destino final: payments_db.payment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.charges  →  stg_raw.usedcars__charges
--   - accesorios.charges  →  stg_raw.accesorios__charges
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.payment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    channel                      text,
    paid_at                      timestamptz,
    amount                       numeric(12,2),
    service_code                 text,
    cardholder_name              text,
    card_brand                   text,
    card_last4                   char(4),
    authorization_code           text,
    gateway_response             jsonb,
    invoice_name                 text,
    invoice_email                text,
    invoice_id_type              text,
    invoice_id_number            text,
    einvoice_key                 text,
    einvoice_message             text,
    einvoice_status              text,
    invoice_number               text,
    gateway_payload              jsonb,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_payment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.payment IS 'Origen: usedcars.charges, accesorios.charges. Destino: payments_db.payment';
COMMENT ON COLUMN stg_validated.payment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.payment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.payment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.payment.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.payment.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.channel IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_SOURCE)';
COMMENT ON COLUMN stg_validated.payment.paid_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.payment.amount IS 'Directo: Copiar (nunca float)';
COMMENT ON COLUMN stg_validated.payment.service_code IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_FEATURE)';
COMMENT ON COLUMN stg_validated.payment.cardholder_name IS 'Transformado: trim()';
COMMENT ON COLUMN stg_validated.payment.card_brand IS 'Homologado: Homologar con stg_control.map_catalog (CARD_BRAND)';
COMMENT ON COLUMN stg_validated.payment.card_last4 IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.authorization_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.gateway_response IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
COMMENT ON COLUMN stg_validated.payment.invoice_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.invoice_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.payment.invoice_id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_validated.payment.invoice_id_number IS 'Transformado: trim()';
COMMENT ON COLUMN stg_validated.payment.einvoice_key IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.einvoice_message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.einvoice_status IS 'Homologado: Homologar con stg_control.map_catalog (EINVOICE_STATUS)';
COMMENT ON COLUMN stg_validated.payment.invoice_number IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.gateway_payload IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
CREATE INDEX IF NOT EXISTS ix_validated_payment_src ON stg_validated.payment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_payment_listing_id ON stg_validated.payment (listing_id);


-- ===== 30_stg_validated/06_pagos/payment_log.sql
-- ======================================================================
-- stg_validated.payment_log
-- Dominio: Pagos · Destino final: payments_db.payment_log
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.chargeslog  →  stg_raw.usedcars__chargeslog
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.payment_log (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    attempted_at                 timestamptz,
    amount                       numeric(12,2),
    order_reference              text,
    gateway_response_code        text,
    avs_result                   text,
    cvv_result                   text,
    response_time                text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_payment_log PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.payment_log IS 'Origen: usedcars.chargeslog. Destino: payments_db.payment_log';
COMMENT ON COLUMN stg_validated.payment_log.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.payment_log.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.payment_log.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.payment_log.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.payment_log.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.attempted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.payment_log.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment_log.order_reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.gateway_response_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.avs_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.cvv_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.response_time IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_payment_log_src ON stg_validated.payment_log (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_payment_log_listing_id ON stg_validated.payment_log (listing_id);


-- ===== 30_stg_validated/06_pagos/prepayment.sql
-- ======================================================================
-- stg_validated.prepayment
-- Dominio: Pagos · Destino final: payments_db.prepayment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.prepay  →  stg_raw.usedcars__prepay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.prepayment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    performed_by                 text,
    seller_id                    uuid,
    movement_type                text,
    movement_at                  timestamptz,
    amount                       numeric(12,2),
    detail                       text,
    comment                      text,
    previous_balance             numeric(12,2),
    new_balance                  numeric(12,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_prepayment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.prepayment IS 'Origen: usedcars.prepay. Destino: payments_db.prepayment';
COMMENT ON COLUMN stg_validated.prepayment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.prepayment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.prepayment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.prepayment.performed_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.seller_id IS 'Derivado: Lookup UUID de seller a partir de sellers.sellercode';
COMMENT ON COLUMN stg_validated.prepayment.movement_type IS 'Homologado: Homologar con stg_control.map_catalog (PREPAY_TYPE)';
COMMENT ON COLUMN stg_validated.prepayment.movement_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.prepayment.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.prepayment.detail IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.comment IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.previous_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.prepayment.new_balance IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_prepayment_src ON stg_validated.prepayment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_prepayment_seller_id ON stg_validated.prepayment (seller_id);


-- ===== 30_stg_validated/06_pagos/coupon.sql
-- ======================================================================
-- stg_validated.coupon
-- Dominio: Pagos · Destino final: payments_db.coupon
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.coupons  →  stg_raw.usedcars__coupons
--   - accesorios.coupons  →  stg_raw.accesorios__coupons
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.coupon (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    code                         text,
    valid_from                   date,
    valid_to                     date,
    used_at                      date,
    listing_id                   uuid,
    coupon_type                  text,
    reference                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_coupon PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.coupon IS 'Origen: usedcars.coupons, accesorios.coupons. Destino: payments_db.coupon';
COMMENT ON COLUMN stg_validated.coupon.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.coupon.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.coupon.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.coupon.code IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_validated.coupon.valid_from IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.coupon.valid_to IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.coupon.used_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.coupon.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.coupon.coupon_type IS 'Homologado: Homologar con stg_control.map_catalog (COUPON_TYPE)';
COMMENT ON COLUMN stg_validated.coupon.reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_coupon_src ON stg_validated.coupon (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_coupon_listing_id ON stg_validated.coupon (listing_id);


-- ===== 30_stg_validated/06_pagos/auto_renewal.sql
-- ======================================================================
-- stg_validated.auto_renewal
-- Dominio: Pagos · Destino final: payments_db.auto_renewal
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.autorenewhl  →  stg_raw.usedcars__autorenewhl
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.auto_renewal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    created_at                   timestamptz,
    renew_at                     timestamptz,
    listing_id                   uuid,
    last_run_at                  timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_auto_renewal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.auto_renewal IS 'Origen: usedcars.autorenewhl. Destino: payments_db.auto_renewal';
COMMENT ON COLUMN stg_validated.auto_renewal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.auto_renewal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.auto_renewal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.auto_renewal.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.auto_renewal.renew_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.auto_renewal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.auto_renewal.last_run_at IS 'Transformado: Contiene fechas (''AAAA/MM/DD HH:MI''), no estados → convertir a fecha';
CREATE INDEX IF NOT EXISTS ix_validated_auto_renewal_src ON stg_validated.auto_renewal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_auto_renewal_listing_id ON stg_validated.auto_renewal (listing_id);


-- ===== 30_stg_validated/06_pagos/einvoice_document.sql
-- ======================================================================
-- stg_validated.einvoice_document
-- Dominio: Pagos · Destino final: payments_db.einvoice_document
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.tdtickets  →  stg_raw.usedcars__tdtickets
--   - usedcars.mttdtickets  →  stg_raw.usedcars__mttdtickets
--   - usedcars.tdinvoices  →  stg_raw.usedcars__tdinvoices
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.einvoice_document (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    document_number              text,
    einvoice_key                 text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_einvoice_document PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.einvoice_document IS 'Origen: usedcars.tdtickets, usedcars.mttdtickets, usedcars.tdinvoices. Destino: payments_db.einvoice_document';
COMMENT ON COLUMN stg_validated.einvoice_document.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.einvoice_document.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.einvoice_document.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.einvoice_document.document_number IS 'Transformado: Copiar; document_type = ''TICKET''';
COMMENT ON COLUMN stg_validated.einvoice_document.einvoice_key IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_einvoice_document_src ON stg_validated.einvoice_document (_source_db, _source_table, _source_pk);

