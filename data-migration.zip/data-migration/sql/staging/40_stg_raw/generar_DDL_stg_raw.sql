-- =====================================================================
-- DATA-02 · Generador del DDL de stg_raw (v1 · 23/10/2026)
-- Ejecutar en el MySQL ORIGEN (solo lectura). Devuelve una fila por tabla con
-- el CREATE TABLE para PostgreSQL. Copiar la columna ddl a un archivo .sql.
-- Tablas incluidas: las 47 tablas MAPEADA de la clasificación v1 (T15, 19/10/2026).
-- v1: salen bacge.brands/styles, financing.newbrands/usedbrands (financiamiento),
--     usedcars.services y usedcars.videos (contenido del sitio) → PENDIENTE DE MAPEO.
-- Nota: si DMS crea las tablas (TargetTablePrepMode), usar este DDL como referencia.
-- =====================================================================
SET SESSION group_concat_max_len = 1000000;

SELECT c.TABLE_SCHEMA, c.TABLE_NAME,
  CONCAT('CREATE TABLE IF NOT EXISTS stg_raw.', c.TABLE_SCHEMA, '__',
         REPLACE(LOWER(c.TABLE_NAME), '-', '_'), ' (\n',
    GROUP_CONCAT(CONCAT('  "', LOWER(c.COLUMN_NAME), '" ',
      CASE
        WHEN c.COLUMN_TYPE = 'tinyint(1)'                    THEN 'smallint'
        WHEN c.DATA_TYPE IN ('tinyint','smallint')           THEN 'smallint'
        WHEN c.DATA_TYPE IN ('mediumint','int') AND c.COLUMN_TYPE LIKE '%unsigned%' THEN 'bigint'
        WHEN c.DATA_TYPE IN ('mediumint','int')              THEN 'integer'
        WHEN c.DATA_TYPE = 'bigint' AND c.COLUMN_TYPE LIKE '%unsigned%' THEN 'numeric(20,0)'
        WHEN c.DATA_TYPE = 'bigint'                          THEN 'bigint'
        WHEN c.DATA_TYPE = 'decimal'                         THEN CONCAT('numeric(', c.NUMERIC_PRECISION, ',', c.NUMERIC_SCALE, ')')
        WHEN c.DATA_TYPE IN ('float','double')               THEN 'double precision'
        WHEN c.DATA_TYPE IN ('date')                         THEN 'text'   -- se convierte en sp_transform (0000-00-00)
        WHEN c.DATA_TYPE IN ('datetime','timestamp')         THEN 'text'   -- idem
        WHEN c.DATA_TYPE = 'time'                            THEN 'time'
        WHEN c.DATA_TYPE = 'year'                            THEN 'smallint'
        WHEN c.DATA_TYPE IN ('blob','mediumblob','longblob','tinyblob','binary','varbinary') THEN 'bytea'
        WHEN c.DATA_TYPE = 'json'                            THEN 'jsonb'
        ELSE 'text'
      END) ORDER BY c.ORDINAL_POSITION SEPARATOR ',\n'),
    ',\n  _dms_op char(1),\n  _dms_ts timestamptz,\n  _loaded_at timestamptz DEFAULT now()\n);') AS ddl
FROM information_schema.COLUMNS c
WHERE (c.TABLE_SCHEMA, LOWER(c.TABLE_NAME)) IN (
    ('accesorios','archive'),
    ('accesorios','charges'),
    ('accesorios','coupons'),
    ('accesorios','pendingpay'),
    ('accesorios','sections'),
    ('accesorios','sellers'),
    ('micrautos','favorites'),
    ('micrautos','friends'),
    ('micrautos','requests'),
    ('micrautos','suggestions'),
    ('micrautos','userreports'),
    ('micrautos','users'),
    ('newcars','brands'),
    ('newcars','dealers'),
    ('newcars','mainbanners'),
    ('newcars','models'),
    ('newcars','styles'),
    ('usedcars','adminusers'),
    ('usedcars','archive'),
    ('usedcars','archivetraspaso'),
    ('usedcars','autorenewhl'),
    ('usedcars','blocked'),
    ('usedcars','blockedemails'),
    ('usedcars','blockedips'),
    ('usedcars','blockedphones'),
    ('usedcars','brands'),
    ('usedcars','carextras'),
    ('usedcars','charges'),
    ('usedcars','chargeslog'),
    ('usedcars','correosfraude'),
    ('usedcars','coupons'),
    ('usedcars','datafile'),
    ('usedcars','dealers'),
    ('usedcars','expiredsellers'),
    ('usedcars','ipsaccepted'),
    ('usedcars','mttdtickets'),
    ('usedcars','parameters'),
    ('usedcars','pending'),
    ('usedcars','pendingpay'),
    ('usedcars','premiumbrands'),
    ('usedcars','prepay'),
    ('usedcars','provinces'),
    ('usedcars','sellers'),
    ('usedcars','specialdeals'),
    ('usedcars','styles'),
    ('usedcars','tdinvoices'),
    ('usedcars','tdtickets')
)
GROUP BY c.TABLE_SCHEMA, c.TABLE_NAME
ORDER BY c.TABLE_SCHEMA, c.TABLE_NAME;
