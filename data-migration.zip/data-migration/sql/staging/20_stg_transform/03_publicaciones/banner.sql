-- ======================================================================
-- stg_transform.banner
-- Dominio: Publicaciones · Destino final: listings_db.banner
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.mainbanners  →  stg_raw.newcars__mainbanners
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.banner (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    client_name                  text,
    image_s3_key                 text,
    link_url                     text,
    mobile_link_url              text,
    link_target                  text,
    start_date                   date,
    end_date                     date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_banner PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.banner IS 'Origen: newcars.mainbanners. Destino: listings_db.banner';
COMMENT ON COLUMN stg_transform.banner.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.banner.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.banner.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.banner.client_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.image_s3_key IS 'Derivado: Archivo → clave S3';
COMMENT ON COLUMN stg_transform.banner.link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.mobile_link_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.link_target IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.banner.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.banner.end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_transform_banner_src ON stg_transform.banner (_source_db, _source_table, _source_pk);
