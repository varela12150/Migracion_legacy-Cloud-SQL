-- ======================================================================
-- stg_transform.listing_equipment
-- Dominio: Publicaciones · Destino final: listings_db.listing_equipment
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.listing_equipment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    equipment_id                 uuid,
    feature_slot                 smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_listing_equipment PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_transform.listing_equipment.feature_slot IS 'Posición f1..f40 en el origen';
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_src ON stg_transform.listing_equipment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_listing_id ON stg_transform.listing_equipment (listing_id);
CREATE INDEX IF NOT EXISTS ix_transform_listing_equipment_equipment_id ON stg_transform.listing_equipment (equipment_id);
