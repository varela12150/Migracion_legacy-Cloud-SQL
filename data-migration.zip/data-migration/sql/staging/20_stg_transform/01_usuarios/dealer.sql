-- ======================================================================
-- stg_transform.dealer
-- Dominio: Usuarios · Destino final: users_db.dealer
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.dealers  →  stg_raw.usedcars__dealers
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.dealer (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    website                      text,
    email                        text,
    address                      text,
    notes                        text,
    username                     text,
    email_2                      text,
    email_3                      text,
    seller_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_dealer PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.dealer IS 'Origen: usedcars.dealers, newcars.dealers. Destino: users_db.dealer';
COMMENT ON COLUMN stg_transform.dealer.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.dealer.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.dealer.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.dealer.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.address IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.username IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.dealer.email_2 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.email_3 IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.dealer.seller_code IS 'Por confirmar: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_dealer_src ON stg_transform.dealer (_source_db, _source_table, _source_pk);
