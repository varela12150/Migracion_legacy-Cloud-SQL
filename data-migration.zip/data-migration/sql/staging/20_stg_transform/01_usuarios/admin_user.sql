-- ======================================================================
-- stg_transform.admin_user
-- Dominio: Usuarios · Destino final: users_db.admin_user
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.adminusers  →  stg_raw.usedcars__adminusers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.admin_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    username                     text,
    role                         text,
    full_name                    text,
    phone                        text,
    position                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_admin_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.admin_user IS 'Origen: usedcars.adminusers. Destino: users_db.admin_user';
COMMENT ON COLUMN stg_transform.admin_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.admin_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.admin_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.admin_user.username IS 'Transformado: trim(); legacy_id = userid';
COMMENT ON COLUMN stg_transform.admin_user.role IS 'Homologado: Homologar con stg_control.map_catalog (ADMIN_LEVEL)';
COMMENT ON COLUMN stg_transform.admin_user.full_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.admin_user.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.admin_user.position IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_admin_user_src ON stg_transform.admin_user (_source_db, _source_table, _source_pk);
