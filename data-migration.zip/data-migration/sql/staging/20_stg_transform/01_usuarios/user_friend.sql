-- ======================================================================
-- stg_transform.user_friend
-- Dominio: Usuarios · Destino final: users_db.user_friend
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.friends  →  stg_raw.micrautos__friends
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_friend (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    friend_user_id               uuid,
    created_at                   date,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_friend PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_friend IS 'Origen: micrautos.friends. Destino: users_db.user_friend';
COMMENT ON COLUMN stg_transform.user_friend.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_friend.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_friend.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_friend.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_friend.friend_user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_friend.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_src ON stg_transform.user_friend (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_user_id ON stg_transform.user_friend (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_friend_friend_user_id ON stg_transform.user_friend (friend_user_id);
