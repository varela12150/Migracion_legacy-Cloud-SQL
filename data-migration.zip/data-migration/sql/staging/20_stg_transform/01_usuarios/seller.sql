-- ======================================================================
-- stg_transform.seller
-- Dominio: Usuarios · Destino final: users_db.seller
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.sellers  →  stg_raw.usedcars__sellers
--   - accesorios.sellers  →  stg_raw.accesorios__sellers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.seller (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    phone                        text,
    email                        text,
    start_date                   date,
    expiration_date              date,
    ad_limit                     integer,
    status                       text,
    seller_code                  text,
    plan_amount                  numeric(12,2),
    website                      text,
    plan_amount_usd              numeric(12,2),
    featured_quota               integer,
    department                   text,
    currency                     text,
    address_line1                text,
    address_line2                text,
    province_id                  text,
    city                         text,
    offers_financing             boolean,
    account_balance              numeric(12,2),
    last_deposit_at              timestamptz,
    last_charge_at               timestamptz,
    banner_start_date            date,
    banner_end_date              date,
    is_premium                   boolean,
    video_html                   text,
    whatsapp                     text,
    sales_rep                    text,
    contact_name                 text,
    contact_phone                text,
    contact_email                text,
    phone_2                      text,
    phone_3                      text,
    logo_s3_key                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_seller PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.seller IS 'Origen: usedcars.sellers, accesorios.sellers. Destino: users_db.seller';
COMMENT ON COLUMN stg_transform.seller.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.seller.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.seller.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.seller.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.email IS 'Transformado: lower(trim()); legacy_id = selleremail';
COMMENT ON COLUMN stg_transform.seller.start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.expiration_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.ad_limit IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.status IS 'Homologado: Homologar con stg_control.map_catalog (SELLER_STATUS)';
COMMENT ON COLUMN stg_transform.seller.seller_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.plan_amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.website IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.plan_amount_usd IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.seller.featured_quota IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.department IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_transform.seller.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.province_id IS 'Homologado: Homologar con stg_control.map_catalog (PROVINCE)';
COMMENT ON COLUMN stg_transform.seller.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.offers_financing IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_transform.seller.account_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.seller.last_deposit_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.seller.last_charge_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.seller.banner_start_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.banner_end_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.seller.is_premium IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.seller.video_html IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.sales_rep IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.seller.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.contact_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_transform.seller.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_transform.seller.logo_s3_key IS 'Derivado: Ruta → clave en S3 (proceso de imágenes)';
CREATE INDEX IF NOT EXISTS ix_transform_seller_src ON stg_transform.seller (_source_db, _source_table, _source_pk);
