-- ======================================================================
-- stg_transform.user_favorite
-- Dominio: Usuarios · Destino final: users_db.user_favorite
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.favorites  →  stg_raw.micrautos__favorites
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_favorite (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    favorite_type                text,
    created_at                   timestamptz,
    notes                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_favorite PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_favorite IS 'Origen: micrautos.favorites. Destino: users_db.user_favorite';
COMMENT ON COLUMN stg_transform.user_favorite.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_favorite.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_favorite.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_favorite.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_favorite.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.user_favorite.favorite_type IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_transform.user_favorite.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_favorite.notes IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_src ON stg_transform.user_favorite (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_user_id ON stg_transform.user_favorite (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_favorite_listing_id ON stg_transform.user_favorite (listing_id);
