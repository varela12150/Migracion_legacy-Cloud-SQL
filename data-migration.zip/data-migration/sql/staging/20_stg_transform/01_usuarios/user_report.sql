-- ======================================================================
-- stg_transform.user_report
-- Dominio: Usuarios · Destino final: users_db.user_report
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.userreports  →  stg_raw.micrautos__userreports
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.user_report (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    listing_id                   uuid,
    created_at                   timestamptz,
    report_text                  text,
    action_taken                 text,
    status                       text,
    report_code                  text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_user_report PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.user_report IS 'Origen: micrautos.userreports. Destino: users_db.user_report';
COMMENT ON COLUMN stg_transform.user_report.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.user_report.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.user_report.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.user_report.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_transform.user_report.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.user_report.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_transform.user_report.report_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_report.action_taken IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.user_report.status IS 'Homologado: Homologar con stg_control.map_catalog (REPORT_STATUS)';
COMMENT ON COLUMN stg_transform.user_report.report_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_user_report_src ON stg_transform.user_report (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_user_report_user_id ON stg_transform.user_report (user_id);
CREATE INDEX IF NOT EXISTS ix_transform_user_report_listing_id ON stg_transform.user_report (listing_id);
