-- ======================================================================
-- stg_transform.blocked_contact
-- Dominio: Seguridad · Destino final: users_db.blocked_contact
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.blocked  →  stg_raw.usedcars__blocked
--   - usedcars.blockedemails  →  stg_raw.usedcars__blockedemails
--   - usedcars.blockedips  →  stg_raw.usedcars__blockedips
--   - usedcars.blockedphones  →  stg_raw.usedcars__blockedphones
--   - usedcars.correosfraude  →  stg_raw.usedcars__correosfraude
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.blocked_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    blockedid                    text,
    blockedname                  text,
    blockedemail                 text,
    ip                           text,
    reason                       text,
    blockedphone                 text,
    codigo                       text,
    emailaddr                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_blocked_contact PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.blocked_contact IS 'Origen: usedcars.blocked, usedcars.blockedemails, usedcars.blockedips, usedcars.blockedphones, usedcars.correosfraude. Destino: users_db.blocked_contact';
COMMENT ON COLUMN stg_transform.blocked_contact.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.blocked_contact.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.blocked_contact.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedid IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedemail IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_transform.blocked_contact.ip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.reason IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.blockedphone IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.codigo IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.blocked_contact.emailaddr IS 'Transformado: lower(trim())';
CREATE INDEX IF NOT EXISTS ix_transform_blocked_contact_src ON stg_transform.blocked_contact (_source_db, _source_table, _source_pk);
