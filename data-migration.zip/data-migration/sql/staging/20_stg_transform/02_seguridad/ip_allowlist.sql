-- ======================================================================
-- stg_transform.ip_allowlist
-- Dominio: Seguridad · Destino final: users_db.ip_allowlist
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.ipsaccepted  →  stg_raw.usedcars__ipsaccepted
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.ip_allowlist (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    aip                          text,
    alocation                    text,
    actry                        text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_ip_allowlist PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.ip_allowlist IS 'Origen: usedcars.ipsaccepted. Destino: users_db.ip_allowlist';
COMMENT ON COLUMN stg_transform.ip_allowlist.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.ip_allowlist.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.ip_allowlist.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.ip_allowlist.aip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.ip_allowlist.alocation IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.ip_allowlist.actry IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_ip_allowlist_src ON stg_transform.ip_allowlist (_source_db, _source_table, _source_pk);
