-- ======================================================================
-- stg_transform.accessory_section
-- Dominio: Accesorios · Destino final: listings_db.accessory_section
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.sections  →  stg_raw.accesorios__sections
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.accessory_section (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_accessory_section PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.accessory_section IS 'Origen: accesorios.sections. Destino: listings_db.accessory_section';
COMMENT ON COLUMN stg_transform.accessory_section.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.accessory_section.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.accessory_section.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.accessory_section.name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_accessory_section_src ON stg_transform.accessory_section (_source_db, _source_table, _source_pk);
