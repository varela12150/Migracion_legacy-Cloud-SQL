-- ======================================================================
-- stg_transform.coupon
-- Dominio: Pagos · Destino final: payments_db.coupon
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.coupons  →  stg_raw.usedcars__coupons
--   - accesorios.coupons  →  stg_raw.accesorios__coupons
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.coupon (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    code                         text,
    valid_from                   date,
    valid_to                     date,
    used_at                      date,
    listing_id                   uuid,
    coupon_type                  text,
    reference                    text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_coupon PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.coupon IS 'Origen: usedcars.coupons, accesorios.coupons. Destino: payments_db.coupon';
COMMENT ON COLUMN stg_transform.coupon.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.coupon.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.coupon.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.coupon.code IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_transform.coupon.valid_from IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.valid_to IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.used_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_transform.coupon.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_transform.coupon.coupon_type IS 'Homologado: Homologar con stg_control.map_catalog (COUPON_TYPE)';
COMMENT ON COLUMN stg_transform.coupon.reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_coupon_src ON stg_transform.coupon (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_coupon_listing_id ON stg_transform.coupon (listing_id);
