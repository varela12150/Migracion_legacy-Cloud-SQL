-- ======================================================================
-- stg_transform.einvoice_document
-- Dominio: Pagos · Destino final: payments_db.einvoice_document
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.tdtickets  →  stg_raw.usedcars__tdtickets
--   - usedcars.mttdtickets  →  stg_raw.usedcars__mttdtickets
--   - usedcars.tdinvoices  →  stg_raw.usedcars__tdinvoices
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.einvoice_document (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    document_number              text,
    einvoice_key                 text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_einvoice_document PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.einvoice_document IS 'Origen: usedcars.tdtickets, usedcars.mttdtickets, usedcars.tdinvoices. Destino: payments_db.einvoice_document';
COMMENT ON COLUMN stg_transform.einvoice_document.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.einvoice_document.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.einvoice_document.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.einvoice_document.document_number IS 'Transformado: Copiar; document_type = ''TICKET''';
COMMENT ON COLUMN stg_transform.einvoice_document.einvoice_key IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_einvoice_document_src ON stg_transform.einvoice_document (_source_db, _source_table, _source_pk);
