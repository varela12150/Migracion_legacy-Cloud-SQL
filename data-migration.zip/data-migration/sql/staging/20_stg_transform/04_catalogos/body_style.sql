-- ======================================================================
-- stg_transform.body_style
-- Dominio: Catalogos · Destino final: listings_db.body_style
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.styles  →  stg_raw.usedcars__styles
--   - newcars.styles  →  stg_raw.newcars__styles
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.body_style (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_body_style PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.body_style IS 'Origen: usedcars.styles, newcars.styles. Destino: listings_db.body_style';
COMMENT ON COLUMN stg_transform.body_style.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.body_style.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.body_style.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.body_style.name IS 'Homologado: trim(); unificar con newcars.styles';
CREATE INDEX IF NOT EXISTS ix_transform_body_style_src ON stg_transform.body_style (_source_db, _source_table, _source_pk);
