-- ======================================================================
-- stg_transform.brand
-- Dominio: Catalogos · Destino final: listings_db.brand
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.brands  →  stg_raw.usedcars__brands
--   - newcars.brands  →  stg_raw.newcars__brands
--   - usedcars.premiumbrands  →  stg_raw.usedcars__premiumbrands
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.brand (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    name                         text,
    status                       text,
    video_url                    text,
    expo_status                  text,
    brand_id                     uuid,
    premium_min_year             smallint,
    premium_min_price            numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_brand PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.brand IS 'Origen: usedcars.brands, newcars.brands, usedcars.premiumbrands. Destino: listings_db.brand';
COMMENT ON COLUMN stg_transform.brand.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.brand.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.brand.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.brand.name IS 'Homologado: initcap(trim()); unificar con newcars.brands';
COMMENT ON COLUMN stg_transform.brand.status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_transform.brand.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.brand.expo_status IS 'Homologado: Homologar con stg_control.map_catalog (BRAND_STATUS)';
COMMENT ON COLUMN stg_transform.brand.brand_id IS 'Por confirmar: Lookup brand por premiumid = usedcars.brands.brandid';
COMMENT ON COLUMN stg_transform.brand.premium_min_year IS 'Transformado: Copiar como regla de marca premium';
COMMENT ON COLUMN stg_transform.brand.premium_min_price IS 'Transformado: Copiar';
CREATE INDEX IF NOT EXISTS ix_transform_brand_src ON stg_transform.brand (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_brand_brand_id ON stg_transform.brand (brand_id);
