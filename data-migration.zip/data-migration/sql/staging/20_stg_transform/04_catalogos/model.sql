-- ======================================================================
-- stg_transform.model
-- Dominio: Catalogos · Destino final: listings_db.model
-- Recibe la salida de sp_transform.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.models  →  stg_raw.newcars__models
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_transform.model (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    brand_id                     uuid,
    base_model                   text,
    body_style_id                uuid,
    image_prefix                 text,
    year                         smallint,
    price                        numeric(14,2),
    mdescrip                     text,
    motherspecs                  text,
    mmaintext                    text,
    mnumpics                     integer,
    mnumvideos                   integer,
    mequipment                   text,
    mmotor                       text,
    menginesize                  integer,
    mpower                       text,
    mtorque                      text,
    msuspension                  text,
    msteering                    text,
    mtransmission                text,
    mtransmission2               text,
    mbrakes                      text,
    mtires                       text,
    mwarranty                    text,
    mfuel                        text,
    mdrive                       text,
    mfueltank                    text,
    mmaxspeed                    text,
    mvalves                      integer,
    mdoors                       integer,
    is_visible                   boolean,
    mweight                      text,
    mheight                      text,
    mwidth                       text,
    mlength                      text,
    mdiameter                    text,
    mvideo1                      text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _transformed_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_transform_model PRIMARY KEY (id)
);

COMMENT ON TABLE stg_transform.model IS 'Origen: newcars.models. Destino: listings_db.model';
COMMENT ON COLUMN stg_transform.model.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_transform.model.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_transform.model.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_transform.model.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_transform.model.brand_id IS 'Derivado: Lookup UUID de brand a partir de newcars.brands.brandid';
COMMENT ON COLUMN stg_transform.model.base_model IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de newcars.styles.styleid';
COMMENT ON COLUMN stg_transform.model.image_prefix IS 'Derivado: Enlace con imágenes en S3';
COMMENT ON COLUMN stg_transform.model.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_transform.model.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mdescrip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.motherspecs IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmaintext IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mnumpics IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mnumvideos IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mequipment IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmotor IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.menginesize IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mpower IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtorque IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.msuspension IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.msteering IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtransmission IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtransmission2 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mbrakes IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mtires IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mwarranty IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mfuel IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mdrive IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mfueltank IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mmaxspeed IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mvalves IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.mdoors IS 'Directo: Copiar';
COMMENT ON COLUMN stg_transform.model.is_visible IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_transform.model.mweight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mheight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mwidth IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mlength IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mdiameter IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_transform.model.mvideo1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_transform_model_src ON stg_transform.model (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_transform_model_dealer_id ON stg_transform.model (dealer_id);
CREATE INDEX IF NOT EXISTS ix_transform_model_brand_id ON stg_transform.model (brand_id);
CREATE INDEX IF NOT EXISTS ix_transform_model_body_style_id ON stg_transform.model (body_style_id);
