-- ======================================================================
-- stg_validated.listing_image
-- Dominio: Publicaciones · Destino final: listings_db.listing_image
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
--   - usedcars.archivetraspaso  →  stg_raw.usedcars__archivetraspaso
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing_image (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    s3_key                       text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing_image PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.listing_image.s3_key IS 'Nombre de archivo origen → clave S3';
COMMENT ON COLUMN stg_validated.listing_image.sort_order IS 'Orden de la foto';
CREATE INDEX IF NOT EXISTS ix_validated_listing_image_src ON stg_validated.listing_image (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_image_listing_id ON stg_validated.listing_image (listing_id);
