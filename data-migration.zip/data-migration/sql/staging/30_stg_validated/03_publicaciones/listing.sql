-- ======================================================================
-- stg_validated.listing
-- Dominio: Publicaciones · Destino final: listings_db.listing
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.datafile  →  stg_raw.usedcars__datafile
--   - usedcars.archive  →  stg_raw.usedcars__archive
--   - usedcars.expiredsellers  →  stg_raw.usedcars__expiredsellers
--   - usedcars.pending  →  stg_raw.usedcars__pending
--   - usedcars.pendingpay  →  stg_raw.usedcars__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    publication_lifecycle        text,
    reference_code               text,
    dealer_id                    uuid,
    brand_id                     uuid,
    model_name                   text,
    engine                       text,
    year                         smallint,
    body_style_id                uuid,
    passengers                   smallint,
    price                        numeric(14,2),
    previous_price               numeric(14,2),
    exchange_rate                numeric(10,2),
    transfer_cost                numeric(14,2),
    condition_code               text,
    exterior_color               text,
    contact_phone                text,
    contact_whatsapp             text,
    contact_email                text,
    summary                      text,
    description                  text,
    ai_description               text,
    contact_name                 text,
    image_count                  smallint,
    fuel_type                    text,
    ev_range                     numeric(8,1),
    ev_range_unit                text,
    battery_kwh                  numeric(6,1),
    transmission                 text,
    publication_status           text,
    mileage                      integer,
    mileage_unit                 text,
    source_channel               text,
    created_at                   timestamptz,
    expires_at                   date,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    option_6                     text,
    option_7                     text,
    option_8                     text,
    option_9                     text,
    option_10                    text,
    visit_count                  integer,
    has_interior_360             boolean,
    video_url                    text,
    interior_color               text,
    is_negotiable                boolean,
    is_registered                boolean,
    plate                        text,
    doors                        smallint,
    province_id                  uuid,
    accepts_trade_in             boolean,
    vin                          text,
    approved_by                  text,
    deleted_by                   text,
    deleted_at                   timestamptz,
    is_blocked                   boolean,
    blocked_reason               text,
    blocked_by                   text,
    currency                     text,
    is_premium                   boolean,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.listing IS 'Origen: usedcars.datafile, usedcars.archive, usedcars.expiredsellers, usedcars.pending, usedcars.pendingpay. Destino: listings_db.listing';
COMMENT ON COLUMN stg_validated.listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.listing.publication_lifecycle IS 'Derivado: Según tabla origen: datafile → ACTIVE · archive → ARCHIVED · expiredsellers → EXPIRED · pending → PENDING_APPROVAL · pendingpay → PENDING_PA';
COMMENT ON COLUMN stg_validated.listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.dealer_id IS 'Por confirmar: Lookup a dealer';
COMMENT ON COLUMN stg_validated.listing.brand_id IS 'Derivado: Lookup UUID de brand a partir de usedcars.brands.brandid (vía map_catalog)';
COMMENT ON COLUMN stg_validated.listing.model_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.engine IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de usedcars.styles.styleid';
COMMENT ON COLUMN stg_validated.listing.passengers IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.previous_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.exchange_rate IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.transfer_cost IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_ESTADO)';
COMMENT ON COLUMN stg_validated.listing.exterior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.contact_phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing.contact_whatsapp IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.listing.contact_email IS 'Derivado: lower(trim()); además resuelve seller_id (sellers.selleremail) / user_id (users.uemail)';
COMMENT ON COLUMN stg_validated.listing.summary IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.ai_description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.image_count IS 'Derivado: Validación: debe coincidir con fotos migradas';
COMMENT ON COLUMN stg_validated.listing.fuel_type IS 'Homologado: Homologar con stg_control.map_catalog (FUEL_TYPE)';
COMMENT ON COLUMN stg_validated.listing.ev_range IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.ev_range_unit IS 'Homologado: Homologar con stg_control.map_catalog (RANGE_UNIT)';
COMMENT ON COLUMN stg_validated.listing.battery_kwh IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.transmission IS 'Homologado: Homologar con stg_control.map_catalog (TRANSMISSION)';
COMMENT ON COLUMN stg_validated.listing.publication_status IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_STATUS)';
COMMENT ON COLUMN stg_validated.listing.mileage IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.listing.mileage_unit IS 'Homologado: Homologar con stg_control.map_catalog (MILEAGE_UNIT)';
COMMENT ON COLUMN stg_validated.listing.source_channel IS 'Homologado: Homologar con stg_control.map_catalog (LISTING_SOURCE)';
COMMENT ON COLUMN stg_validated.listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing.expires_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_6 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_7 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_8 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_9 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.option_10 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.listing.visit_count IS 'Directo: Copiar (histórico)';
COMMENT ON COLUMN stg_validated.listing.has_interior_360 IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.video_url IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.interior_color IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.is_negotiable IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.is_registered IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.plate IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.doors IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.listing.province_id IS 'Derivado: Lookup UUID de province a partir de usedcars.provinces.provinceid';
COMMENT ON COLUMN stg_validated.listing.accepts_trade_in IS 'Por confirmar: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.vin IS 'Transformado: upper(trim())';
COMMENT ON COLUMN stg_validated.listing.approved_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.deleted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.listing.is_blocked IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.listing.blocked_reason IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.blocked_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.listing.is_premium IS 'Transformado: Valor → boolean';
CREATE INDEX IF NOT EXISTS ix_validated_listing_src ON stg_validated.listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_listing_dealer_id ON stg_validated.listing (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_brand_id ON stg_validated.listing (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_body_style_id ON stg_validated.listing (body_style_id);
CREATE INDEX IF NOT EXISTS ix_validated_listing_province_id ON stg_validated.listing (province_id);
