-- ======================================================================
-- stg_validated.special_deal
-- Dominio: Publicaciones · Destino final: listings_db.special_deal
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.specialdeals  →  stg_raw.usedcars__specialdeals
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.special_deal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    deal_date                    date,
    deal_price                   numeric(14,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_special_deal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.special_deal IS 'Origen: usedcars.specialdeals. Destino: listings_db.special_deal';
COMMENT ON COLUMN stg_validated.special_deal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.special_deal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.special_deal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.special_deal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.special_deal.deal_date IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.special_deal.deal_price IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_special_deal_src ON stg_validated.special_deal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_special_deal_listing_id ON stg_validated.special_deal (listing_id);
