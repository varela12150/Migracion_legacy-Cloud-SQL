-- ======================================================================
-- stg_validated.model
-- Dominio: Catalogos · Destino final: listings_db.model
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.models  →  stg_raw.newcars__models
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.model (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    brand_id                     uuid,
    base_model                   text,
    body_style_id                uuid,
    image_prefix                 text,
    year                         smallint,
    price                        numeric(14,2),
    mdescrip                     text,
    motherspecs                  text,
    mmaintext                    text,
    mnumpics                     integer,
    mnumvideos                   integer,
    mequipment                   text,
    mmotor                       text,
    menginesize                  integer,
    mpower                       text,
    mtorque                      text,
    msuspension                  text,
    msteering                    text,
    mtransmission                text,
    mtransmission2               text,
    mbrakes                      text,
    mtires                       text,
    mwarranty                    text,
    mfuel                        text,
    mdrive                       text,
    mfueltank                    text,
    mmaxspeed                    text,
    mvalves                      integer,
    mdoors                       integer,
    is_visible                   boolean,
    mweight                      text,
    mheight                      text,
    mwidth                       text,
    mlength                      text,
    mdiameter                    text,
    mvideo1                      text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_model PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.model IS 'Origen: newcars.models. Destino: listings_db.model';
COMMENT ON COLUMN stg_validated.model.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.model.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.model.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.model.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_validated.model.brand_id IS 'Derivado: Lookup UUID de brand a partir de newcars.brands.brandid';
COMMENT ON COLUMN stg_validated.model.base_model IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.body_style_id IS 'Derivado: Lookup UUID de body_style a partir de newcars.styles.styleid';
COMMENT ON COLUMN stg_validated.model.image_prefix IS 'Derivado: Enlace con imágenes en S3';
COMMENT ON COLUMN stg_validated.model.year IS 'Transformado: Texto → smallint';
COMMENT ON COLUMN stg_validated.model.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mdescrip IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.motherspecs IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmaintext IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mnumpics IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mnumvideos IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mequipment IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmotor IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.menginesize IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mpower IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtorque IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.msuspension IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.msteering IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtransmission IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtransmission2 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mbrakes IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mtires IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mwarranty IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mfuel IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mdrive IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mfueltank IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mmaxspeed IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mvalves IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.mdoors IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.model.is_visible IS 'Transformado: Valor → boolean';
COMMENT ON COLUMN stg_validated.model.mweight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mheight IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mwidth IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mlength IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mdiameter IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.model.mvideo1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_model_src ON stg_validated.model (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_model_dealer_id ON stg_validated.model (dealer_id);
CREATE INDEX IF NOT EXISTS ix_validated_model_brand_id ON stg_validated.model (brand_id);
CREATE INDEX IF NOT EXISTS ix_validated_model_body_style_id ON stg_validated.model (body_style_id);
