-- ======================================================================
-- stg_validated.user_request
-- Dominio: Usuarios · Destino final: users_db.user_request
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.requests  →  stg_raw.micrautos__requests
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_request (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    dealer_id                    uuid,
    request_type                 text,
    attributes                   jsonb,
    message                      text,
    created_at                   timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_request PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_request IS 'Origen: micrautos.requests. Destino: users_db.user_request';
COMMENT ON COLUMN stg_validated.user_request.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_request.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_request.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_request.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_request.dealer_id IS 'Derivado: Lookup UUID de dealer a partir de newcars.dealers.dcode';
COMMENT ON COLUMN stg_validated.user_request.request_type IS 'Homologado: Homologar con stg_control.map_catalog (REQUEST_TYPE)';
COMMENT ON COLUMN stg_validated.user_request.attributes IS 'Derivado: jsonb_build_object(''var1'',var1,''var2'',var2,''var3'',var3)';
COMMENT ON COLUMN stg_validated.user_request.message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.user_request.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
CREATE INDEX IF NOT EXISTS ix_validated_user_request_src ON stg_validated.user_request (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_request_user_id ON stg_validated.user_request (user_id);
CREATE INDEX IF NOT EXISTS ix_validated_user_request_dealer_id ON stg_validated.user_request (dealer_id);
