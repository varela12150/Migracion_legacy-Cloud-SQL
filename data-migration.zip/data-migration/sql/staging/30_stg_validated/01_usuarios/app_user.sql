-- ======================================================================
-- stg_validated.app_user
-- Dominio: Usuarios · Destino final: users_db.app_user
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.users  →  stg_raw.micrautos__users
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.app_user (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    first_name                   text,
    last_name                    text,
    id_type                      text,
    id_number                    text,
    birth_date                   date,
    gender                       text,
    email                        text,
    created_at                   date,
    last_login_at                timestamptz,
    status                       text,
    address_line1                text,
    address_line2                text,
    city                         text,
    country                      text,
    postal_code                  text,
    phone_home                   text,
    phone_work                   text,
    phone_mobile                 text,
    free_ad_flag                 text,
    accepts_email                boolean,
    nickname                     text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_app_user PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.app_user IS 'Origen: micrautos.users. Destino: users_db.app_user';
COMMENT ON COLUMN stg_validated.app_user.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.app_user.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.app_user.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.app_user.first_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.last_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_validated.app_user.id_number IS 'Transformado: trim(); quitar guiones y espacios';
COMMENT ON COLUMN stg_validated.app_user.birth_date IS 'Derivado: make_date(uyear, umonth, uday); inválida → NULL + WARNING';
COMMENT ON COLUMN stg_validated.app_user.gender IS 'Homologado: Homologar con stg_control.map_catalog (GENDER)';
COMMENT ON COLUMN stg_validated.app_user.email IS 'Transformado: lower(trim())';
COMMENT ON COLUMN stg_validated.app_user.created_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.app_user.last_login_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.app_user.status IS 'Homologado: Homologar con stg_control.map_catalog (USER_STATUS)';
COMMENT ON COLUMN stg_validated.app_user.address_line1 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.address_line2 IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.city IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.country IS 'Homologado: Homologar con stg_control.map_catalog (COUNTRY)';
COMMENT ON COLUMN stg_validated.app_user.postal_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.app_user.phone_home IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.phone_work IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.phone_mobile IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.app_user.free_ad_flag IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.app_user.accepts_email IS 'Transformado: Valores sí/no → boolean';
COMMENT ON COLUMN stg_validated.app_user.nickname IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_app_user_src ON stg_validated.app_user (_source_db, _source_table, _source_pk);
