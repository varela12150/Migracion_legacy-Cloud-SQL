-- ======================================================================
-- stg_validated.dealer_contact
-- Dominio: Usuarios · Destino final: users_db.dealer_contact
-- Entidad PIVOT: 1 fila origen → N filas.
-- Mapeo (tabla origen → tabla stg_raw):
--   - newcars.dealers  →  stg_raw.newcars__dealers
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.dealer_contact (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    dealer_id                    uuid,
    phone                        text,
    phone_label                  text,
    sort_order                   smallint,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_dealer_contact PRIMARY KEY (id)
);

COMMENT ON COLUMN stg_validated.dealer_contact.phone IS 'dphoneN normalizado';
COMMENT ON COLUMN stg_validated.dealer_contact.phone_label IS 'dphonerefN';
COMMENT ON COLUMN stg_validated.dealer_contact.sort_order IS 'N del par dphoneN/dphonerefN';
CREATE INDEX IF NOT EXISTS ix_validated_dealer_contact_src ON stg_validated.dealer_contact (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_dealer_contact_dealer_id ON stg_validated.dealer_contact (dealer_id);
