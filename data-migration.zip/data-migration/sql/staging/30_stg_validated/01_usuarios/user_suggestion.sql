-- ======================================================================
-- stg_validated.user_suggestion
-- Dominio: Usuarios · Destino final: users_db.user_suggestion
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - micrautos.suggestions  →  stg_raw.micrautos__suggestions
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.user_suggestion (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    user_id                      uuid,
    created_at                   timestamptz,
    suggestion_text              text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_user_suggestion PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.user_suggestion IS 'Origen: micrautos.suggestions. Destino: users_db.user_suggestion';
COMMENT ON COLUMN stg_validated.user_suggestion.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.user_suggestion.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.user_suggestion.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.user_suggestion.user_id IS 'Derivado: Lookup UUID de app_user a partir de ucode';
COMMENT ON COLUMN stg_validated.user_suggestion.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.user_suggestion.suggestion_text IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_user_suggestion_src ON stg_validated.user_suggestion (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_user_suggestion_user_id ON stg_validated.user_suggestion (user_id);
