-- ======================================================================
-- stg_validated.accessory_listing
-- Dominio: Accesorios · Destino final: listings_db.accessory_listing
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - accesorios.archive  →  stg_raw.accesorios__archive
--   - accesorios.pendingpay  →  stg_raw.accesorios__pendingpay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.accessory_listing (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    reference_code               text,
    condition_code               text,
    created_at                   timestamptz,
    expires_at                   timestamptz,
    option_1                     text,
    option_2                     text,
    option_3                     text,
    option_4                     text,
    option_5                     text,
    visit_count                  integer,
    image_count                  smallint,
    contact_name                 text,
    contact_email                text,
    phone                        text,
    phone_2                      text,
    phone_3                      text,
    price                        numeric(14,2),
    currency                     text,
    reference_price              numeric(14,2),
    title                        text,
    description                  text,
    section_id                   uuid,
    deleted_at                   date,
    deleted_by                   text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_accessory_listing PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.accessory_listing IS 'Origen: accesorios.archive, accesorios.pendingpay. Destino: listings_db.accessory_listing';
COMMENT ON COLUMN stg_validated.accessory_listing.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.accessory_listing.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.accessory_listing.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.accessory_listing.reference_code IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.condition_code IS 'Homologado: Homologar con stg_control.map_catalog (ACC_ESTADO)';
COMMENT ON COLUMN stg_validated.accessory_listing.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.accessory_listing.expires_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.accessory_listing.option_1 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_2 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_3 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_4 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.option_5 IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.visit_count IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.image_count IS 'Derivado: Validación con imágenes';
COMMENT ON COLUMN stg_validated.accessory_listing.contact_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.contact_email IS 'Derivado: lower(trim()); resuelve seller_id (accesorios.sellers)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone_2 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.phone_3 IS 'Transformado: Solo dígitos; quitar prefijo 506; validar 8 dígitos (CR)';
COMMENT ON COLUMN stg_validated.accessory_listing.price IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.currency IS 'Homologado: Homologar con stg_control.map_catalog (CURRENCY)';
COMMENT ON COLUMN stg_validated.accessory_listing.reference_price IS 'Por confirmar: Copiar';
COMMENT ON COLUMN stg_validated.accessory_listing.title IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.description IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.accessory_listing.section_id IS 'Derivado: Lookup UUID de accessory_section a partir de accesorios.sections.sectionid';
COMMENT ON COLUMN stg_validated.accessory_listing.deleted_at IS 'Transformado: Texto → date (formato por confirmar); vacío o inválido → NULL + WARNING';
COMMENT ON COLUMN stg_validated.accessory_listing.deleted_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_accessory_listing_src ON stg_validated.accessory_listing (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_accessory_listing_section_id ON stg_validated.accessory_listing (section_id);
