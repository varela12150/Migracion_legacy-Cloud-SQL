-- ======================================================================
-- stg_validated.system_parameter
-- Dominio: Seguridad · Destino final: users_db.system_parameter
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.parameters  →  stg_raw.usedcars__parameters
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.system_parameter (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    parname                      text,
    parvalue1                    text,
    parvalue2                    numeric(10,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_system_parameter PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.system_parameter IS 'Origen: usedcars.parameters. Destino: users_db.system_parameter';
COMMENT ON COLUMN stg_validated.system_parameter.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.system_parameter.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.system_parameter.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.system_parameter.parname IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.system_parameter.parvalue1 IS 'Directo: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.system_parameter.parvalue2 IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_system_parameter_src ON stg_validated.system_parameter (_source_db, _source_table, _source_pk);
