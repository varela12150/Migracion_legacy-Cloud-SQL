-- ======================================================================
-- stg_validated.prepayment
-- Dominio: Pagos · Destino final: payments_db.prepayment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.prepay  →  stg_raw.usedcars__prepay
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.prepayment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    performed_by                 text,
    seller_id                    uuid,
    movement_type                text,
    movement_at                  timestamptz,
    amount                       numeric(12,2),
    detail                       text,
    comment                      text,
    previous_balance             numeric(12,2),
    new_balance                  numeric(12,2),
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_prepayment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.prepayment IS 'Origen: usedcars.prepay. Destino: payments_db.prepayment';
COMMENT ON COLUMN stg_validated.prepayment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.prepayment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.prepayment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.prepayment.performed_by IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.seller_id IS 'Derivado: Lookup UUID de seller a partir de sellers.sellercode';
COMMENT ON COLUMN stg_validated.prepayment.movement_type IS 'Homologado: Homologar con stg_control.map_catalog (PREPAY_TYPE)';
COMMENT ON COLUMN stg_validated.prepayment.movement_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.prepayment.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.prepayment.detail IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.comment IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.prepayment.previous_balance IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.prepayment.new_balance IS 'Directo: Copiar';
CREATE INDEX IF NOT EXISTS ix_validated_prepayment_src ON stg_validated.prepayment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_prepayment_seller_id ON stg_validated.prepayment (seller_id);
