-- ======================================================================
-- stg_validated.payment
-- Dominio: Pagos · Destino final: payments_db.payment
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.charges  →  stg_raw.usedcars__charges
--   - accesorios.charges  →  stg_raw.accesorios__charges
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.payment (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    channel                      text,
    paid_at                      timestamptz,
    amount                       numeric(12,2),
    service_code                 text,
    cardholder_name              text,
    card_brand                   text,
    card_last4                   char(4),
    authorization_code           text,
    gateway_response             jsonb,
    invoice_name                 text,
    invoice_email                text,
    invoice_id_type              text,
    invoice_id_number            text,
    einvoice_key                 text,
    einvoice_message             text,
    einvoice_status              text,
    invoice_number               text,
    gateway_payload              jsonb,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_payment PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.payment IS 'Origen: usedcars.charges, accesorios.charges. Destino: payments_db.payment';
COMMENT ON COLUMN stg_validated.payment.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.payment.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.payment.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.payment.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.payment.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.channel IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_SOURCE)';
COMMENT ON COLUMN stg_validated.payment.paid_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.payment.amount IS 'Directo: Copiar (nunca float)';
COMMENT ON COLUMN stg_validated.payment.service_code IS 'Homologado: Homologar con stg_control.map_catalog (PAYMENT_FEATURE)';
COMMENT ON COLUMN stg_validated.payment.cardholder_name IS 'Transformado: trim()';
COMMENT ON COLUMN stg_validated.payment.card_brand IS 'Homologado: Homologar con stg_control.map_catalog (CARD_BRAND)';
COMMENT ON COLUMN stg_validated.payment.card_last4 IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.authorization_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.gateway_response IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
COMMENT ON COLUMN stg_validated.payment.invoice_name IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.invoice_email IS 'Transformado: lower(trim()); latin1 → UTF-8';
COMMENT ON COLUMN stg_validated.payment.invoice_id_type IS 'Homologado: Homologar con stg_control.map_catalog (ID_TYPE)';
COMMENT ON COLUMN stg_validated.payment.invoice_id_number IS 'Transformado: trim()';
COMMENT ON COLUMN stg_validated.payment.einvoice_key IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.einvoice_message IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment.einvoice_status IS 'Homologado: Homologar con stg_control.map_catalog (EINVOICE_STATUS)';
COMMENT ON COLUMN stg_validated.payment.invoice_number IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment.gateway_payload IS 'Por confirmar: Evaluar: jsonb o archivo en S3';
CREATE INDEX IF NOT EXISTS ix_validated_payment_src ON stg_validated.payment (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_payment_listing_id ON stg_validated.payment (listing_id);
