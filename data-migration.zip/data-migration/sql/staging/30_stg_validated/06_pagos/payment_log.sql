-- ======================================================================
-- stg_validated.payment_log
-- Dominio: Pagos · Destino final: payments_db.payment_log
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.chargeslog  →  stg_raw.usedcars__chargeslog
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.payment_log (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    listing_id                   uuid,
    listing_title_snapshot       text,
    attempted_at                 timestamptz,
    amount                       numeric(12,2),
    order_reference              text,
    gateway_response_code        text,
    avs_result                   text,
    cvv_result                   text,
    response_time                text,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_payment_log PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.payment_log IS 'Origen: usedcars.chargeslog. Destino: payments_db.payment_log';
COMMENT ON COLUMN stg_validated.payment_log.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.payment_log.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.payment_log.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.payment_log.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.payment_log.listing_title_snapshot IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.attempted_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.payment_log.amount IS 'Directo: Copiar';
COMMENT ON COLUMN stg_validated.payment_log.order_reference IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.gateway_response_code IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.avs_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.cvv_result IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
COMMENT ON COLUMN stg_validated.payment_log.response_time IS 'Transformado: trim(); latin1 → UTF-8; vacío → NULL';
CREATE INDEX IF NOT EXISTS ix_validated_payment_log_src ON stg_validated.payment_log (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_payment_log_listing_id ON stg_validated.payment_log (listing_id);
