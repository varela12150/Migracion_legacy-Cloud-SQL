-- ======================================================================
-- stg_validated.auto_renewal
-- Dominio: Pagos · Destino final: payments_db.auto_renewal
-- Recibe solo las filas que pasan sp_validate; sp_publish las lleva al destino.
-- Columnas de negocio tomadas de la matriz S2T v1 (tipo destino + regla).
-- Mapeo (tabla origen → tabla stg_raw):
--   - usedcars.autorenewhl  →  stg_raw.usedcars__autorenewhl
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_validated.auto_renewal (
    id                           uuid NOT NULL,
    legacy_id                    text,
    legacy_source                text,
    created_at                   timestamptz,
    renew_at                     timestamptz,
    listing_id                   uuid,
    last_run_at                  timestamptz,
    _run_id                      bigint,
    _source_db                   text NOT NULL,
    _source_table                text NOT NULL,
    _source_pk                   text NOT NULL,
    _row_hash                    text,
    _is_deleted                  boolean NOT NULL DEFAULT false,
    _validated_at                timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_validated_auto_renewal PRIMARY KEY (id)
);

COMMENT ON TABLE stg_validated.auto_renewal IS 'Origen: usedcars.autorenewhl. Destino: payments_db.auto_renewal';
COMMENT ON COLUMN stg_validated.auto_renewal.id IS 'PK UUID v5 determinístico (bd.tabla:pk_origen)';
COMMENT ON COLUMN stg_validated.auto_renewal.legacy_id IS 'PK del origen como texto (compuesta separada por |)';
COMMENT ON COLUMN stg_validated.auto_renewal.legacy_source IS 'bd.tabla de origen';
COMMENT ON COLUMN stg_validated.auto_renewal.created_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.auto_renewal.renew_at IS 'Transformado: Texto → timestamp (formato por confirmar); vacío o inválido → NULL + WARNING; zona America/Costa_Rica';
COMMENT ON COLUMN stg_validated.auto_renewal.listing_id IS 'Derivado: Lookup UUID de listing a partir de listing.codigo';
COMMENT ON COLUMN stg_validated.auto_renewal.last_run_at IS 'Transformado: Contiene fechas (''AAAA/MM/DD HH:MI''), no estados → convertir a fecha';
CREATE INDEX IF NOT EXISTS ix_validated_auto_renewal_src ON stg_validated.auto_renewal (_source_db, _source_table, _source_pk);
CREATE INDEX IF NOT EXISTS ix_validated_auto_renewal_listing_id ON stg_validated.auto_renewal (listing_id);
