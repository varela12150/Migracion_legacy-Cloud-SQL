-- ======================================================================
-- Verificación de sp_validate · ejecutar después de CALL stg_validated.sp_validate_all(NULL);
-- Funciona igual en psql y DBeaver (Alt+X). Cambie el run_id si quiere otra corrida.
-- ======================================================================

-- 1) Resultado por entidad de la última corrida
SELECT entity, status, rows_in, rows_ok, rows_error, rows_warning, message
FROM stg_control.step_log
WHERE step_name = 'sp_validate'
  AND run_id = (SELECT max(run_id) FROM stg_control.step_log WHERE step_name = 'sp_validate')
ORDER BY step_id;

-- 2) Hallazgos por regla (ERROR primero)
SELECT e.entity, e.rule_code, e.severity, count(*) AS filas, min(e.detail) AS ejemplo
FROM stg_control.error_record e
WHERE e.step_name = 'sp_validate'
  AND e.run_id = (SELECT max(run_id) FROM stg_control.step_log WHERE step_name = 'sp_validate')
GROUP BY 1, 2, 3
ORDER BY (e.severity = 'ERROR') DESC, filas DESC;

-- 3) Cuadre transform vs validated (diferencia = filas rechazadas con ERROR)
SELECT s.entity,
       (xpath('/row/c/text()', query_to_xml(format('SELECT count(*) AS c FROM stg_transform.%I', s.entity), false, true, '')))[1]::text::int AS en_transform,
       (xpath('/row/c/text()', query_to_xml(format('SELECT count(*) AS c FROM stg_validated.%I', s.entity), false, true, '')))[1]::text::int AS en_validated
FROM (SELECT DISTINCT entity FROM stg_control.step_log WHERE step_name = 'sp_validate') s
ORDER BY 1;

-- 4) Reglas activas por entidad
SELECT entity, rule_type, severity, count(*) AS reglas
FROM stg_control.validation_rule
WHERE is_active AND check_sql IS NOT NULL
GROUP BY 1, 2, 3 ORDER BY 1, 2;
