-- ======================================================================
-- stg_validated.sp_validate_entity · Motor de validación stg_transform → stg_validated
-- Un solo procedimiento genérico para las 32 entidades: las reglas viven en
-- stg_control.validation_rule (check_sql), no en el código.
--
-- Pasos por entidad:
--   1. Candidatas: filas de stg_transform.<entity> nuevas o cambiadas frente a stg_validated
--      (no existe, distinto _row_hash o distinto _is_deleted). Así es incremental y re-ejecutable.
--   2. Filas borradas por CDC (_is_deleted = true) no se validan: pasan directo para que
--      sp_publish las borre en el destino.
--   3. Ejecuta cada regla activa de la entidad (orden exec_order) → error_record.
--   4. Regla automática VAL_CATALOG_UNMAPPED sobre todas las columnas de texto.
--   5. Publica en stg_validated.<entity> las candidatas SIN errores (las WARNING sí pasan).
--   6. step_log con rows_in / rows_ok / rows_error / rows_warning.
--
-- Si una fila con ERROR ya estaba en stg_validated (versión anterior buena), se conserva la
-- versión anterior y el error se vuelve a registrar en cada corrida hasta que se corrija.  POR DECIDIR
-- Si una regla tiene SQL inválido, la entidad completa queda FAILED y no publica nada.
--
-- Uso:  CALL stg_validated.sp_validate_entity(p_run_id, 'listing');
-- Proyecto: Migración de datos CRAutos · Historia DATA-04 · sp_validate v0 (esqueleto)
-- Autor: Andrés Varela (Ingeniería de Datos) · 05/11/2026
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_validated.sp_validate_entity(p_run_id bigint, p_entity text)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step      bigint;
    v_in        bigint := 0;
    v_ok        bigint := 0;
    v_err       bigint := 0;
    v_warn      bigint := 0;
    v_rule      record;
    v_col       text;
    v_cols      text;
    v_set       text;
    v_detail    text;
    v_src       text := format('stg_transform.%I', p_entity);
    v_dst       text := format('stg_validated.%I', p_entity);
BEGIN
    -- El step_log se abre FUERA del bloque con EXCEPTION: si algo falla, el rollback del bloque
    -- no borra la fila de step_log y queda marcada como FAILED.
    v_step := stg_control.fn_step_start(p_run_id, 'sp_validate', p_entity);

  BEGIN
    IF to_regclass(v_src) IS NULL OR to_regclass(v_dst) IS NULL THEN
        RAISE EXCEPTION 'No existe % o %', v_src, v_dst;
    END IF;

    -- 1. Candidatas (nuevas o cambiadas)
    IF to_regclass('pg_temp._val_cand') IS NOT NULL THEN DROP TABLE _val_cand; END IF;
    EXECUTE format($q$
        CREATE TEMP TABLE _val_cand AS
        SELECT t.id, t._is_deleted
          FROM %s t
          LEFT JOIN %s v ON v.id = t.id
         WHERE v.id IS NULL
            OR v._row_hash IS DISTINCT FROM t._row_hash
            OR v._is_deleted <> t._is_deleted $q$, v_src, v_dst);
    ALTER TABLE _val_cand ADD PRIMARY KEY (id);
    SELECT count(*) INTO v_in FROM _val_cand;

    -- Filas que fallan (id + severidad), para decidir qué se publica
    IF to_regclass('pg_temp._val_fail') IS NOT NULL THEN DROP TABLE _val_fail; END IF;
    CREATE TEMP TABLE _val_fail (id uuid, severity text);

    -- 3. Reglas configuradas de la entidad
    FOR v_rule IN
        SELECT rule_code, severity, target_column, check_sql, description
          FROM stg_control.validation_rule
         WHERE entity = p_entity AND is_active AND nullif(btrim(check_sql), '') IS NOT NULL
         ORDER BY exec_order, rule_code
    LOOP
        v_detail := CASE WHEN v_rule.target_column IS NOT NULL
                         THEN format('%L || '' = '' || coalesce(t.%I::text, ''NULL'')', v_rule.description, v_rule.target_column)
                         ELSE quote_literal(v_rule.description) END;
        EXECUTE format($q$
            WITH f AS (
                SELECT t.*
                  FROM %s t
                  JOIN _val_cand c ON c.id = t.id AND NOT c._is_deleted
                 WHERE (%s)
            ), ins AS (
                INSERT INTO stg_control.error_record
                       (run_id, step_name, entity, source_db, source_table, source_pk, rule_code, severity, detail, payload)
                SELECT %s, 'sp_validate', %L, t._source_db, t._source_table, t._source_pk, %L, %L, %s, to_jsonb(t)
                  FROM f t
                RETURNING 1
            )
            INSERT INTO _val_fail (id, severity) SELECT id, %L FROM f $q$,
            v_src, v_rule.check_sql, p_run_id, p_entity, v_rule.rule_code, v_rule.severity, v_detail, v_rule.severity);
    END LOOP;

    -- 4. Regla automática: valores sin homologar (UNMAPPED:<valor>) en cualquier columna de texto
    IF EXISTS (SELECT 1 FROM stg_control.validation_rule WHERE rule_code = 'VAL_CATALOG_UNMAPPED' AND is_active) THEN
        FOR v_col IN
            SELECT column_name FROM information_schema.columns
             WHERE table_schema = 'stg_transform' AND table_name = p_entity
               AND data_type IN ('text', 'character varying') AND column_name NOT LIKE '\_%'
             ORDER BY ordinal_position
        LOOP
            EXECUTE format($q$
                WITH f AS (
                    SELECT t.* FROM %1$s t
                      JOIN _val_cand c ON c.id = t.id AND NOT c._is_deleted
                     WHERE t.%2$I LIKE 'UNMAPPED:%%'
                ), ins AS (
                    INSERT INTO stg_control.error_record
                           (run_id, step_name, entity, source_db, source_table, source_pk, rule_code, severity, detail, payload)
                    SELECT %3$s, 'sp_validate', %4$L, t._source_db, t._source_table, t._source_pk,
                           'VAL_CATALOG_UNMAPPED', 'WARNING', %2$L || ' = ' || t.%2$I, NULL
                      FROM f t
                    RETURNING 1
                )
                INSERT INTO _val_fail (id, severity) SELECT id, 'WARNING' FROM f $q$,
                v_src, v_col, p_run_id, p_entity);
        END LOOP;
    END IF;

    SELECT count(DISTINCT id) FILTER (WHERE severity = 'ERROR') INTO v_err FROM _val_fail;
    SELECT count(DISTINCT id) INTO v_warn FROM _val_fail f
     WHERE severity = 'WARNING' AND NOT EXISTS (SELECT 1 FROM _val_fail e WHERE e.id = f.id AND e.severity = 'ERROR');

    -- 5. Publicar en stg_validated las candidatas sin ERROR (mismas columnas, menos _transformed_at)
    SELECT string_agg(quote_ident(d.column_name), ', ' ORDER BY d.ordinal_position),
           string_agg(format('%1$I = EXCLUDED.%1$I', d.column_name), ', ' ORDER BY d.ordinal_position)
             FILTER (WHERE d.column_name <> 'id')
      INTO v_cols, v_set
      FROM information_schema.columns d
      JOIN information_schema.columns s
        ON s.table_schema = 'stg_transform' AND s.table_name = p_entity AND s.column_name = d.column_name
     WHERE d.table_schema = 'stg_validated' AND d.table_name = p_entity;

    EXECUTE format($q$
        INSERT INTO %1$s (%2$s, _validated_at)
        SELECT %4$s, now()
          FROM %5$s t
          JOIN _val_cand c ON c.id = t.id
         WHERE NOT EXISTS (SELECT 1 FROM _val_fail f WHERE f.id = t.id AND f.severity = 'ERROR')
        ON CONFLICT (id) DO UPDATE SET %3$s, _validated_at = now() $q$,
        v_dst, v_cols, v_set,
        (SELECT string_agg('t.' || x, ', ') FROM unnest(string_to_array(v_cols, ', ')) x),
        v_src);
    GET DIAGNOSTICS v_ok = ROW_COUNT;

    DROP TABLE _val_cand;
    DROP TABLE _val_fail;

    -- 6. Bitácora
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, v_err, v_warn,
            CASE WHEN v_err > 0 THEN 'SUCCESS_WITH_ERRORS' ELSE 'SUCCESS' END, NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se sigue con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_validate', p_entity, NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_validated.sp_validate_entity(bigint, text) IS
    'stg_transform → stg_validated con reglas de stg_control.validation_rule (esqueleto v0)';
