-- ======================================================================
-- stg_control.validation_rule · v2 (motor de sp_validate)
-- Agrega las columnas que necesita sp_validate para ejecutar las reglas desde la tabla,
-- sin escribirlas dentro del código. No borra nada: ALTER ... ADD COLUMN IF NOT EXISTS.
--
-- Cómo se escribe una regla:
--   check_sql = condición SQL que es VERDADERA cuando la fila FALLA. La fila se llama "t"
--               y es una fila de stg_transform.<entity>. Ej.: t.price < 0
--   severity  = ERROR   → la fila NO pasa a stg_validated (queda en error_record)
--               WARNING → la fila pasa a stg_validated y queda anotada en error_record
--   target_column = columna evaluada; su valor se copia en error_record.detail
--   rule_type = FK / FORMAT / REQUIRED / RANGE / CATALOG / CUSTOM (solo para reportes)
--   exec_order = orden de ejecución dentro de la entidad
--   source_ref = de dónde sale la regla (fila S2T, T14, respuesta de negocio T19…)
--
-- Proyecto: Migración de datos CRAutos · Historia DATA-04 · sp_validate v0 (esqueleto)
-- Autor: Andrés Varela (Ingeniería de Datos) · 05/11/2026
-- ======================================================================

ALTER TABLE stg_control.validation_rule ADD COLUMN IF NOT EXISTS rule_type     text;
ALTER TABLE stg_control.validation_rule ADD COLUMN IF NOT EXISTS target_column text;
ALTER TABLE stg_control.validation_rule ADD COLUMN IF NOT EXISTS check_sql     text;
ALTER TABLE stg_control.validation_rule ADD COLUMN IF NOT EXISTS exec_order    int  NOT NULL DEFAULT 100;
ALTER TABLE stg_control.validation_rule ADD COLUMN IF NOT EXISTS source_ref    text;
ALTER TABLE stg_control.validation_rule ADD COLUMN IF NOT EXISTS updated_at    timestamptz NOT NULL DEFAULT now();

DO $$ BEGIN
    ALTER TABLE stg_control.validation_rule
        ADD CONSTRAINT ck_validation_rule_severity CHECK (severity IN ('ERROR', 'WARNING'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

COMMENT ON COLUMN stg_control.validation_rule.check_sql     IS 'Condición SQL VERDADERA cuando la fila falla. Alias de la fila: t';
COMMENT ON COLUMN stg_control.validation_rule.target_column IS 'Columna evaluada; su valor va a error_record.detail';
COMMENT ON COLUMN stg_control.validation_rule.rule_type     IS 'FK / FORMAT / REQUIRED / RANGE / CATALOG / CUSTOM';
COMMENT ON COLUMN stg_control.validation_rule.exec_order    IS 'Orden de ejecución dentro de la entidad';
COMMENT ON COLUMN stg_control.validation_rule.source_ref    IS 'Origen de la regla: fila S2T, T14, T19…';

CREATE INDEX IF NOT EXISTS ix_validation_rule_entity ON stg_control.validation_rule (entity, is_active, exec_order);

-- Reglas técnicas que usa el motor (además de SP_FAILED y VAL_CATALOG_UNMAPPED de 09_funciones_comunes)
INSERT INTO stg_control.validation_rule (rule_code, entity, description, severity, rule_type) VALUES
  ('SP_FAILED',            NULL, 'Falla técnica de un procedimiento (ver detail)',      'ERROR',   'CUSTOM'),
  ('VAL_CATALOG_UNMAPPED', NULL, 'Valor de origen sin homologar en map_catalog',          'WARNING', 'CATALOG')
ON CONFLICT (rule_code) DO NOTHING;
-- VAL_CATALOG_UNMAPPED es automática: sp_validate revisa TODAS las columnas de texto de la entidad
-- buscando 'UNMAPPED:%'. No necesita check_sql. Para apagarla: is_active = false.
