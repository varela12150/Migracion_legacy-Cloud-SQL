-- ======================================================================
-- 00_stg_validated_desde_transform.sql · Tablas de stg_validated
-- Crea las 32 tablas de stg_validated con la misma estructura que stg_transform
-- (columnas, PK, índices y defaults) y agrega _validated_at, que usa sp_validate_entity.
-- Se usó en UAT el 13/11/2026 en lugar de 2d_stg_validated_tablas.sql, que no creó tablas.
-- Re-ejecutable: CREATE TABLE IF NOT EXISTS / ADD COLUMN IF NOT EXISTS.
-- Ejecutar después de crear stg_transform y antes de 01–04 de esta carpeta.
-- Proyecto: Migración de datos CRAutos · DATA-04 · Autor: Andrés Varela · 13/11/2026
-- ======================================================================
DO $$
DECLARE r record; n int := 0;
BEGIN
  FOR r IN SELECT table_name FROM information_schema.tables
           WHERE table_schema = 'stg_transform' AND table_type = 'BASE TABLE' ORDER BY table_name
  LOOP
    EXECUTE format('CREATE TABLE IF NOT EXISTS stg_validated.%I (LIKE stg_transform.%I INCLUDING ALL)', r.table_name, r.table_name);
    EXECUTE format('ALTER TABLE stg_validated.%I ADD COLUMN IF NOT EXISTS _validated_at timestamptz', r.table_name);
    n := n + 1;
  END LOOP;
  RAISE NOTICE 'Tablas en stg_validated: %', n;
END $$;

-- Comprobación: 32
SELECT count(*) AS tablas_validated
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'stg_validated' AND c.relkind = 'r';
