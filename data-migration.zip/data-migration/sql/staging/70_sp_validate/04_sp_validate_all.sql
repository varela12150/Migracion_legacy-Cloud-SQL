-- ======================================================================
-- stg_validated.sp_validate_all · Orquestador de sp_validate
-- Orden padre → hijo (las FK se validan contra stg_validated del padre):
--   catálogos → usuarios → model → publicaciones → relaciones de usuario → seguridad → pagos.
-- Diferencia con sp_transform_all: model va DESPUÉS de dealer (model.dealer_id → dealer).
-- COMMIT por entidad: si una falla, queda FAILED en step_log y se sigue con la siguiente.
-- p_run_id NULL → usa el último run de sp_transform terminado (mismo run_id para trazabilidad).
-- Uso (fuera de un bloque de transacción):  CALL stg_validated.sp_validate_all(NULL);
-- Proyecto: Migración de datos CRAutos · Historia DATA-04 · sp_validate v0 (esqueleto)
-- Autor: Andrés Varela (Ingeniería de Datos) · 05/11/2026
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_validated.sp_validate_all(p_run_id bigint DEFAULT NULL)
LANGUAGE plpgsql
AS $$
DECLARE
    v_entity text;
    v_order  text[] := ARRAY[
        'brand', 'body_style', 'province', 'equipment', 'accessory_section',
        'app_user', 'seller', 'dealer', 'dealer_contact', 'admin_user', 'model',
        'listing', 'listing_transfer', 'listing_image', 'listing_equipment', 'special_deal', 'banner',
        'accessory_listing',
        'user_favorite', 'user_friend', 'user_request', 'user_suggestion', 'user_report',
        'blocked_contact', 'ip_allowlist', 'system_parameter',
        'payment', 'payment_log', 'prepayment', 'coupon', 'auto_renewal', 'einvoice_document'];
BEGIN
    IF p_run_id IS NULL THEN
        SELECT max(run_id) INTO p_run_id
          FROM stg_control.migration_run
         WHERE status IN ('SUCCESS', 'FAILED') AND finished_at IS NOT NULL;
        IF p_run_id IS NULL THEN
            RAISE EXCEPTION 'No hay ninguna corrida de sp_transform terminada en migration_run';
        END IF;
    END IF;

    FOREACH v_entity IN ARRAY v_order LOOP
        CALL stg_validated.sp_validate_entity(p_run_id, v_entity);
        COMMIT;
    END LOOP;

    RAISE NOTICE 'sp_validate_all terminado · run_id = %', p_run_id;
END;
$$;

COMMENT ON PROCEDURE stg_validated.sp_validate_all(bigint) IS 'Orquestador stg_transform → stg_validated (esqueleto v0)';
