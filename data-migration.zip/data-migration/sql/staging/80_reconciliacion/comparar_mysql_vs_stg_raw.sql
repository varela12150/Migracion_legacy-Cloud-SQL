-- ======================================================================
-- comparar_mysql_vs_stg_raw.sql · Conteo MySQL (origen) vs stg_raw (UAT)
-- 47 tablas en alcance (las mismas de 00_crear_stg_raw_desde_Q01.sql).
--
-- PASO 1 · Ejecutar en MySQL (origen). Solo lectura. COUNT(*) exacto, no
--          information_schema.TABLE_ROWS (que es un estimado en InnoDB).
--          Copie la columna "fila_values" de las 47 filas.
-- PASO 2 · Ejecutar en PostgreSQL UAT (crautos_db · db-nodemkt-uat) pegando
--          esas filas dentro del bloque VALUES marcado abajo.
--
-- Nota: con el CDC activo, una tabla con mucho movimiento puede diferir por
-- pocas filas entre el momento del conteo en MySQL y en PostgreSQL. Ejecute
-- los dos pasos seguidos.
-- Proyecto: Migración de datos CRAutos · Reconciliación de carga DMS
-- Autor: Andrés Varela (Ingeniería de Datos) · 05/11/2026
-- ======================================================================


-- ======================= PASO 1 · MySQL (origen) =======================
SELECT bd, tabla, filas,
       CONCAT('(''', bd, ''', ''', tabla, ''', ', filas, '),') AS fila_values
FROM (
          SELECT 'accesorios' AS bd, 'archive' AS tabla, COUNT(*) AS filas FROM `accesorios`.`archive`
UNION ALL SELECT 'accesorios' AS bd, 'charges' AS tabla, COUNT(*) AS filas FROM `accesorios`.`charges`
UNION ALL SELECT 'accesorios' AS bd, 'coupons' AS tabla, COUNT(*) AS filas FROM `accesorios`.`coupons`
UNION ALL SELECT 'accesorios' AS bd, 'pendingpay' AS tabla, COUNT(*) AS filas FROM `accesorios`.`pendingpay`
UNION ALL SELECT 'accesorios' AS bd, 'sections' AS tabla, COUNT(*) AS filas FROM `accesorios`.`sections`
UNION ALL SELECT 'accesorios' AS bd, 'sellers' AS tabla, COUNT(*) AS filas FROM `accesorios`.`sellers`
UNION ALL SELECT 'micrautos' AS bd, 'favorites' AS tabla, COUNT(*) AS filas FROM `micrautos`.`favorites`
UNION ALL SELECT 'micrautos' AS bd, 'friends' AS tabla, COUNT(*) AS filas FROM `micrautos`.`friends`
UNION ALL SELECT 'micrautos' AS bd, 'requests' AS tabla, COUNT(*) AS filas FROM `micrautos`.`requests`
UNION ALL SELECT 'micrautos' AS bd, 'suggestions' AS tabla, COUNT(*) AS filas FROM `micrautos`.`suggestions`
UNION ALL SELECT 'micrautos' AS bd, 'userreports' AS tabla, COUNT(*) AS filas FROM `micrautos`.`userreports`
UNION ALL SELECT 'micrautos' AS bd, 'users' AS tabla, COUNT(*) AS filas FROM `micrautos`.`users`
UNION ALL SELECT 'newcars' AS bd, 'brands' AS tabla, COUNT(*) AS filas FROM `newcars`.`brands`
UNION ALL SELECT 'newcars' AS bd, 'dealers' AS tabla, COUNT(*) AS filas FROM `newcars`.`dealers`
UNION ALL SELECT 'newcars' AS bd, 'mainbanners' AS tabla, COUNT(*) AS filas FROM `newcars`.`mainbanners`
UNION ALL SELECT 'newcars' AS bd, 'models' AS tabla, COUNT(*) AS filas FROM `newcars`.`models`
UNION ALL SELECT 'newcars' AS bd, 'styles' AS tabla, COUNT(*) AS filas FROM `newcars`.`styles`
UNION ALL SELECT 'usedcars' AS bd, 'adminusers' AS tabla, COUNT(*) AS filas FROM `usedcars`.`adminusers`
UNION ALL SELECT 'usedcars' AS bd, 'archive' AS tabla, COUNT(*) AS filas FROM `usedcars`.`archive`
UNION ALL SELECT 'usedcars' AS bd, 'archivetraspaso' AS tabla, COUNT(*) AS filas FROM `usedcars`.`archivetraspaso`
UNION ALL SELECT 'usedcars' AS bd, 'autorenewhl' AS tabla, COUNT(*) AS filas FROM `usedcars`.`autorenewhl`
UNION ALL SELECT 'usedcars' AS bd, 'blocked' AS tabla, COUNT(*) AS filas FROM `usedcars`.`blocked`
UNION ALL SELECT 'usedcars' AS bd, 'blockedemails' AS tabla, COUNT(*) AS filas FROM `usedcars`.`blockedemails`
UNION ALL SELECT 'usedcars' AS bd, 'blockedips' AS tabla, COUNT(*) AS filas FROM `usedcars`.`blockedips`
UNION ALL SELECT 'usedcars' AS bd, 'blockedphones' AS tabla, COUNT(*) AS filas FROM `usedcars`.`blockedphones`
UNION ALL SELECT 'usedcars' AS bd, 'brands' AS tabla, COUNT(*) AS filas FROM `usedcars`.`brands`
UNION ALL SELECT 'usedcars' AS bd, 'carextras' AS tabla, COUNT(*) AS filas FROM `usedcars`.`carextras`
UNION ALL SELECT 'usedcars' AS bd, 'charges' AS tabla, COUNT(*) AS filas FROM `usedcars`.`charges`
UNION ALL SELECT 'usedcars' AS bd, 'chargeslog' AS tabla, COUNT(*) AS filas FROM `usedcars`.`chargeslog`
UNION ALL SELECT 'usedcars' AS bd, 'correosfraude' AS tabla, COUNT(*) AS filas FROM `usedcars`.`correosfraude`
UNION ALL SELECT 'usedcars' AS bd, 'coupons' AS tabla, COUNT(*) AS filas FROM `usedcars`.`coupons`
UNION ALL SELECT 'usedcars' AS bd, 'datafile' AS tabla, COUNT(*) AS filas FROM `usedcars`.`datafile`
UNION ALL SELECT 'usedcars' AS bd, 'dealers' AS tabla, COUNT(*) AS filas FROM `usedcars`.`dealers`
UNION ALL SELECT 'usedcars' AS bd, 'expiredsellers' AS tabla, COUNT(*) AS filas FROM `usedcars`.`expiredsellers`
UNION ALL SELECT 'usedcars' AS bd, 'ipsaccepted' AS tabla, COUNT(*) AS filas FROM `usedcars`.`ipsaccepted`
UNION ALL SELECT 'usedcars' AS bd, 'mttdtickets' AS tabla, COUNT(*) AS filas FROM `usedcars`.`mttdtickets`
UNION ALL SELECT 'usedcars' AS bd, 'parameters' AS tabla, COUNT(*) AS filas FROM `usedcars`.`parameters`
UNION ALL SELECT 'usedcars' AS bd, 'pending' AS tabla, COUNT(*) AS filas FROM `usedcars`.`pending`
UNION ALL SELECT 'usedcars' AS bd, 'pendingpay' AS tabla, COUNT(*) AS filas FROM `usedcars`.`pendingpay`
UNION ALL SELECT 'usedcars' AS bd, 'premiumbrands' AS tabla, COUNT(*) AS filas FROM `usedcars`.`premiumbrands`
UNION ALL SELECT 'usedcars' AS bd, 'prepay' AS tabla, COUNT(*) AS filas FROM `usedcars`.`prepay`
UNION ALL SELECT 'usedcars' AS bd, 'provinces' AS tabla, COUNT(*) AS filas FROM `usedcars`.`provinces`
UNION ALL SELECT 'usedcars' AS bd, 'sellers' AS tabla, COUNT(*) AS filas FROM `usedcars`.`sellers`
UNION ALL SELECT 'usedcars' AS bd, 'specialdeals' AS tabla, COUNT(*) AS filas FROM `usedcars`.`specialdeals`
UNION ALL SELECT 'usedcars' AS bd, 'styles' AS tabla, COUNT(*) AS filas FROM `usedcars`.`styles`
UNION ALL SELECT 'usedcars' AS bd, 'tdinvoices' AS tabla, COUNT(*) AS filas FROM `usedcars`.`tdinvoices`
UNION ALL SELECT 'usedcars' AS bd, 'tdtickets' AS tabla, COUNT(*) AS filas FROM `usedcars`.`tdtickets`
) c
ORDER BY bd, tabla;


-- ===================== PASO 2 · PostgreSQL UAT ==========================
-- Pegue las filas de "fila_values" entre las dos marcas.
-- Quite la coma de la ÚLTIMA fila pegada.
WITH mysql (bd, tabla, filas_mysql) AS (
    VALUES
    -- >>> PEGAR AQUÍ (47 filas) >>>
    ('usedcars', 'datafile', 0)
    -- <<< FIN PEGADO <<<
),
alcance AS (
    SELECT split_part(t, '__', 1) AS bd, split_part(t, '__', 2) AS tabla, t AS tabla_raw
    FROM unnest(ARRAY['accesorios__archive', 'accesorios__charges', 'accesorios__coupons', 'accesorios__pendingpay', 'accesorios__sections', 'accesorios__sellers', 'micrautos__favorites', 'micrautos__friends', 'micrautos__requests', 'micrautos__suggestions', 'micrautos__userreports', 'micrautos__users', 'newcars__brands', 'newcars__dealers', 'newcars__mainbanners', 'newcars__models', 'newcars__styles', 'usedcars__adminusers', 'usedcars__archive', 'usedcars__archivetraspaso', 'usedcars__autorenewhl', 'usedcars__blocked', 'usedcars__blockedemails', 'usedcars__blockedips', 'usedcars__blockedphones', 'usedcars__brands', 'usedcars__carextras', 'usedcars__charges', 'usedcars__chargeslog', 'usedcars__correosfraude', 'usedcars__coupons', 'usedcars__datafile', 'usedcars__dealers', 'usedcars__expiredsellers', 'usedcars__ipsaccepted', 'usedcars__mttdtickets', 'usedcars__parameters', 'usedcars__pending', 'usedcars__pendingpay', 'usedcars__premiumbrands', 'usedcars__prepay', 'usedcars__provinces', 'usedcars__sellers', 'usedcars__specialdeals', 'usedcars__styles', 'usedcars__tdinvoices', 'usedcars__tdtickets']) AS t
),
pg AS (
    SELECT a.bd, a.tabla, a.tabla_raw,
           to_regclass('stg_raw.' || quote_ident(a.tabla_raw)) IS NOT NULL AS existe
    FROM alcance a
),
conteo AS (
    SELECT pg.*,
           CASE WHEN existe THEN (xpath('/row/c/text()', query_to_xml(format(
                'SELECT count(*) AS c FROM stg_raw.%I', tabla_raw), false, true, '')))[1]::text::bigint END AS filas_pg,
           CASE WHEN existe THEN (xpath('/row/c/text()', query_to_xml(format(
                'SELECT count(*) FILTER (WHERE _dms_op = ''D'') AS c FROM stg_raw.%I', tabla_raw), false, true, '')))[1]::text::bigint END AS borradas_cdc
    FROM pg
)
SELECT c.bd, c.tabla,
       m.filas_mysql,
       c.filas_pg,
       c.borradas_cdc,
       c.filas_pg - coalesce(c.borradas_cdc, 0)                      AS filas_pg_vigentes,
       c.filas_pg - coalesce(c.borradas_cdc, 0) - m.filas_mysql      AS diferencia,
       CASE
           WHEN NOT c.existe                                        THEN 'NO EXISTE EN stg_raw'
           WHEN m.filas_mysql IS NULL                               THEN 'SIN CONTEO MYSQL (no se pegó)'
           WHEN c.filas_pg - coalesce(c.borradas_cdc, 0) = m.filas_mysql THEN 'OK'
           WHEN c.filas_pg - coalesce(c.borradas_cdc, 0) < m.filas_mysql THEN 'FALTAN EN PG'
           ELSE 'SOBRAN EN PG (¿duplicados?)'
       END AS estado
FROM conteo c
LEFT JOIN mysql m ON m.bd = c.bd AND m.tabla = c.tabla
ORDER BY (CASE WHEN NOT c.existe THEN 0 WHEN c.filas_pg - coalesce(c.borradas_cdc,0) = m.filas_mysql THEN 2 ELSE 1 END),
         c.bd, c.tabla;


-- ===== PASO 3 (opcional) · Tablas en stg_raw que NO están en el alcance =====
SELECT table_name AS tabla_extra_en_stg_raw
FROM information_schema.tables
WHERE table_schema = 'stg_raw' AND table_type = 'BASE TABLE'
  AND table_name NOT IN ('accesorios__archive', 'accesorios__charges', 'accesorios__coupons', 'accesorios__pendingpay', 'accesorios__sections', 'accesorios__sellers', 'micrautos__favorites', 'micrautos__friends', 'micrautos__requests', 'micrautos__suggestions', 'micrautos__userreports', 'micrautos__users', 'newcars__brands', 'newcars__dealers', 'newcars__mainbanners', 'newcars__models', 'newcars__styles', 'usedcars__adminusers', 'usedcars__archive', 'usedcars__archivetraspaso', 'usedcars__autorenewhl', 'usedcars__blocked', 'usedcars__blockedemails', 'usedcars__blockedips', 'usedcars__blockedphones', 'usedcars__brands', 'usedcars__carextras', 'usedcars__charges', 'usedcars__chargeslog', 'usedcars__correosfraude', 'usedcars__coupons', 'usedcars__datafile', 'usedcars__dealers', 'usedcars__expiredsellers', 'usedcars__ipsaccepted', 'usedcars__mttdtickets', 'usedcars__parameters', 'usedcars__pending', 'usedcars__pendingpay', 'usedcars__premiumbrands', 'usedcars__prepay', 'usedcars__provinces', 'usedcars__sellers', 'usedcars__specialdeals', 'usedcars__styles', 'usedcars__tdinvoices', 'usedcars__tdtickets')
ORDER BY 1;
