-- ======================================================================
-- PASO 6 · Verificación de la corrida de sp_transform en UAT
-- ======================================================================

-- 6.1 Estado de la corrida
SELECT run_id, run_type, status, started_at, finished_at, finished_at - started_at AS duracion
FROM stg_control.migration_run ORDER BY run_id DESC LIMIT 3;

-- 6.2 Resultado por entidad (FAILED primero)
SELECT entity, status, rows_in, rows_ok, finished_at - started_at AS duracion, left(message, 150) AS mensaje
FROM stg_control.step_log
WHERE step_name = 'sp_transform'
  AND run_id = (SELECT max(run_id) FROM stg_control.migration_run)
ORDER BY (status = 'FAILED') DESC, step_id;

-- 6.3 Errores técnicos registrados
SELECT entity, rule_code, left(detail, 200) AS detalle
FROM stg_control.error_record
WHERE run_id = (SELECT max(run_id) FROM stg_control.migration_run)
  AND step_name = 'sp_transform';

-- 6.4 Filas por entidad en stg_transform
SELECT c.relname AS entidad, c.reltuples::bigint AS filas_aprox
FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE n.nspname = 'stg_transform' AND c.relkind = 'r'
ORDER BY 2 DESC;

-- 6.5 Valores sin homologar (esperado mientras map_catalog esté vacío)
SELECT 'listing' AS entidad, count(*) FILTER (WHERE condition_code LIKE 'UNMAPPED:%') AS condition_unmapped,
       count(*) FILTER (WHERE brand_id IS NULL) AS sin_marca,
       count(*) FILTER (WHERE length(contact_phone) > 8) AS telefono_largo
FROM stg_transform.listing;
