-- ======================================================================
-- PASO 1 · Extensiones y esquemas de staging en UAT
-- No toca stg_raw ni los esquemas destino (admin_db, listings_db, users_db, …).
-- ======================================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;
CREATE EXTENSION IF NOT EXISTS pgcrypto    WITH SCHEMA public;

CREATE SCHEMA IF NOT EXISTS stg_transform;
CREATE SCHEMA IF NOT EXISTS stg_validated;
CREATE SCHEMA IF NOT EXISTS stg_control;

-- Comprobación: debe devolver 3 filas y las 2 extensiones en 'public'
SELECT nspname FROM pg_namespace WHERE nspname IN ('stg_transform', 'stg_validated', 'stg_control');
SELECT e.extname, n.nspname AS esquema FROM pg_extension e JOIN pg_namespace n ON n.oid = e.extnamespace
WHERE e.extname IN ('uuid-ossp', 'pgcrypto');
