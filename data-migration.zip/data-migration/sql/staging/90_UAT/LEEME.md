# Despliegue del staging en UAT (stg_raw cargado por AWS DMS)

Scripts probados en `crautos_db` de UAT entre el 06/11 y el 13/11/2026. En UAT, DMS crea las tablas como `stg_raw.<bd>_<tabla>` (un guion bajo) y sin las columnas `_dms_op` / `_dms_ts`. Por eso el `sp_transform` de UAT es una versión aparte de `50_sp_transform/`.

## Orden de ejecución (DBeaver: Auto-Commit activado, esquema activo `public`, cada script con Alt+X)

| Paso | Script | Qué hace |
| --- | --- | --- |
| 1 | `90_UAT/01_esquemas_UAT.sql` | Extensiones `uuid-ossp` y `pgcrypto` en `public`; esquemas `stg_transform`, `stg_validated`, `stg_control` |
| 2 | `60_datos_dummy/dbeaver/2b_stg_control.sql` | Tablas de control y funciones comunes `fn_*` |
| 3 | `60_datos_dummy/dbeaver/2c_stg_transform_tablas.sql` | 32 tablas de `stg_transform` |
| 4 | `90_UAT/02_sp_transform_UAT.sql` | 33 procedimientos `sp_transform` (incluye el fix de `blocked_contact` del 13/11) |
| 5 | `CALL stg_transform.sp_transform_all(NULL);` | Corrida de transformación |
| 6 | `90_UAT/03_verificar_transform_UAT.sql` | Verificación por entidad |
| 7 | `70_sp_validate/00_stg_validated_desde_transform.sql` | 32 tablas de `stg_validated` + `_validated_at` |
| 8 | `70_sp_validate/01` a `04` | `validation_rule` v2, 64 reglas iniciales, `sp_validate_entity`, `sp_validate_all` |
| 9 | `SET statement_timeout = 0; CALL stg_validated.sp_validate_all(<run_id>);` | Corrida de validación |
| 10 | `70_sp_validate/05_verificar_validate.sql` | Verificación por entidad y por regla |

Para comprobar la carga de DMS contra el origen: `80_reconciliacion/comparar_mysql_vs_stg_raw.sql`.

## Notas

- `stg_control.validation_rule` ya trae los códigos técnicos (`SP_FAILED`, `VAL_CATALOG_UNMAPPED`, `VAL_DATE_INVALID`, `VAL_FK_MISSING`, `VAL_LISTING_DUP_LIFECYCLE`). No desactivarlos: `error_record.rule_code` tiene FK a esa tabla. El paso 4 agrega `VAL_PK_MISSING`.
- `sp_validate_all(NULL)` toma el último run terminado de `migration_run`; conviene pasar el `run_id` explícito.
- `listing_equipment` (≈7,2 M filas) e `listing_image` (≈1,5 M) son las entidades más lentas: desactivar el `statement_timeout` de la sesión antes del paso 9.
