-- ======================================================================
-- 2e_sp_transform_UAT.sql · sp_transform adaptado a stg_raw de UAT (AWS DMS real)
-- Cambios frente a 2e_sp_transform.sql (dummy):
--   1. Tablas stg_raw.<bd>_<tabla> (un guion bajo, como las crea DMS en UAT).
--   2. UAT no tiene _dms_op / _dms_ts: se reemplazan por NULL (todas las filas = vigentes).
--      Pendiente: detección de borrados por anti-join antes de activar corridas CDC.
--   3. step_log se abre fuera del bloque EXCEPTION: una falla queda FAILED en step_log.
--   4. 13/11/2026: blocked_contact excluye y registra (VAL_PK_MISSING) las filas con llave vacía.
-- Ejecutar en DBeaver con Alt+X, Auto-Commit activado, esquema activo = public.
-- Proyecto: Migración de datos CRAutos · DATA-03 · Autor: Andrés Varela · 06/11/2026
-- ======================================================================

-- Paso 2e · 33 procedimientos sp_transform (versión DBeaver). Ejecutar con Alt+X, Auto-Commit activado.

-- ===== 50_sp_transform/04_catalogos/sp_transform_brand.sql
-- ======================================================================
-- stg_transform.sp_transform_brand
-- stg_raw → stg_transform.brand  ·  Destino final: listings_db.brand
-- Lee: stg_raw.usedcars_brands + stg_raw.newcars_brands + stg_raw.usedcars_premiumbrands
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_brand(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_brand(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'brand');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_brands)
        + (SELECT count(*) FROM stg_raw.newcars_brands)
        + (SELECT count(*) FROM stg_raw.usedcars_premiumbrands)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.brands
    SELECT
        stg_control.fn_legacy_uuid('usedcars.brands', r."brandid"::text)       AS id,
        r."brandid"::text                                                      AS legacy_id,
        'usedcars.brands'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."brandname"::text)                         AS name,
        NULL::text                                                             AS status,  -- no viene de usedcars.brands
        NULL::text                                                             AS video_url,  -- no viene de usedcars.brands
        NULL::text                                                             AS expo_status,  -- no viene de usedcars.brands
        NULL::uuid                                                             AS brand_id,  -- no viene de usedcars.brands
        NULL::smallint                                                         AS premium_min_year,  -- no viene de usedcars.brands
        NULL::numeric(14,2)                                                    AS premium_min_price,  -- no viene de usedcars.brands
        'usedcars'::text AS _source_db, 'brands'::text AS _source_table, r."brandid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_brands r
    UNION ALL
    -- ---- newcars.brands
    -- No se migran: branddir
    SELECT
        stg_control.fn_legacy_uuid('newcars.brands', r."brandid"::text)        AS id,
        r."brandid"::text                                                      AS legacy_id,
        'newcars.brands'                                                       AS legacy_source,
        stg_control.fn_clean_text(r."brandname"::text)                         AS name,
        stg_control.fn_map_code('BRAND_STATUS', 'newcars', r."status"::text)   AS status,
        stg_control.fn_clean_text(r."video1"::text)                            AS video_url,
        stg_control.fn_map_code('BRAND_STATUS', 'newcars', r."expostatus"::text) AS expo_status,
        NULL::uuid                                                             AS brand_id,  -- no viene de newcars.brands
        NULL::smallint                                                         AS premium_min_year,  -- no viene de newcars.brands
        NULL::numeric(14,2)                                                    AS premium_min_price,  -- no viene de newcars.brands
        'newcars'::text AS _source_db, 'brands'::text AS _source_table, r."brandid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.newcars_brands r
    UNION ALL
    -- ---- usedcars.premiumbrands
    SELECT
        stg_control.fn_legacy_uuid('usedcars.premiumbrands', r."premiumid"::text) AS id,
        r."premiumid"::text                                                    AS legacy_id,
        'usedcars.premiumbrands'                                               AS legacy_source,
        NULL::text                                                             AS name,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS status,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS video_url,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS expo_status,  -- no viene de usedcars.premiumbrands
        NULL::uuid                                                             AS brand_id,  -- POR CONFIRMAR · TODO: Lookup brand por premiumid = usedcars.brands.brandid
        stg_control.fn_to_int(r."minyear"::text)::smallint                     AS premium_min_year,
        r."minprice"::numeric(14,2)                                            AS premium_min_price,
        'usedcars'::text AS _source_db, 'premiumbrands'::text AS _source_table, r."premiumid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 3 AS _prio
    FROM stg_raw.usedcars_premiumbrands r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.brand (id, legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        status = EXCLUDED.status,
        video_url = EXCLUDED.video_url,
        expo_status = EXCLUDED.expo_status,
        brand_id = EXCLUDED.brand_id,
        premium_min_year = EXCLUDED.premium_min_year,
        premium_min_price = EXCLUDED.premium_min_price,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.brand._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.brand._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'brand', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_brand(bigint) IS 'stg_raw → stg_transform.brand (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/04_catalogos/sp_transform_body_style.sql
-- ======================================================================
-- stg_transform.sp_transform_body_style
-- stg_raw → stg_transform.body_style  ·  Destino final: listings_db.body_style
-- Lee: stg_raw.usedcars_styles + stg_raw.newcars_styles
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_body_style(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_body_style(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'body_style');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_styles)
        + (SELECT count(*) FROM stg_raw.newcars_styles)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.styles
    SELECT
        stg_control.fn_legacy_uuid('usedcars.styles', r."styleid"::text)       AS id,
        r."styleid"::text                                                      AS legacy_id,
        'usedcars.styles'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."stylename"::text)                         AS name,
        'usedcars'::text AS _source_db, 'styles'::text AS _source_table, r."styleid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_styles r
    UNION ALL
    -- ---- newcars.styles
    SELECT
        stg_control.fn_legacy_uuid('newcars.styles', r."styleid"::text)        AS id,
        r."styleid"::text                                                      AS legacy_id,
        'newcars.styles'                                                       AS legacy_source,
        stg_control.fn_clean_text(r."stylename"::text)                         AS name,
        'newcars'::text AS _source_db, 'styles'::text AS _source_table, r."styleid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.newcars_styles r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.body_style (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.body_style._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.body_style._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'body_style', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_body_style(bigint) IS 'stg_raw → stg_transform.body_style (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/04_catalogos/sp_transform_province.sql
-- ======================================================================
-- stg_transform.sp_transform_province
-- stg_raw → stg_transform.province  ·  Destino final: listings_db.province
-- Lee: stg_raw.usedcars_provinces
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_province(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_province(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'province');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_provinces)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.provinces
    SELECT
        stg_control.fn_legacy_uuid('usedcars.provinces', r."provinceid"::text) AS id,
        r."provinceid"::text                                                   AS legacy_id,
        'usedcars.provinces'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."provincename"::text)                      AS name,
        'usedcars'::text AS _source_db, 'provinces'::text AS _source_table, r."provinceid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_provinces r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.province (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.province._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.province._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'province', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_province(bigint) IS 'stg_raw → stg_transform.province (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_equipment.sql
-- ======================================================================
-- stg_transform.sp_transform_equipment
-- stg_raw → stg_transform.equipment  ·  Destino final: listings_db.equipment
-- Lee: stg_raw.usedcars_carextras
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_equipment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_equipment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'equipment');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_carextras)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.carextras
    SELECT
        stg_control.fn_legacy_uuid('usedcars.carextras', r."idextra"::text)    AS id,
        r."idextra"::text                                                      AS legacy_id,
        'usedcars.carextras'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."description"::text)                       AS name,
        'usedcars'::text AS _source_db, 'carextras'::text AS _source_table, r."idextra"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_carextras r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.equipment (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.equipment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.equipment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'equipment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_equipment(bigint) IS 'stg_raw → stg_transform.equipment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/05_accesorios/sp_transform_accessory_section.sql
-- ======================================================================
-- stg_transform.sp_transform_accessory_section
-- stg_raw → stg_transform.accessory_section  ·  Destino final: listings_db.accessory_section
-- Lee: stg_raw.accesorios_sections
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_accessory_section(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_accessory_section(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'accessory_section');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.accesorios_sections)
      INTO v_in;

    WITH src AS (
    -- ---- accesorios.sections
    SELECT
        stg_control.fn_legacy_uuid('accesorios.sections', r."sectionid"::text) AS id,
        r."sectionid"::text                                                    AS legacy_id,
        'accesorios.sections'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."sectiondesc"::text)                       AS name,
        'accesorios'::text AS _source_db, 'sections'::text AS _source_table, r."sectionid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.accesorios_sections r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.accessory_section (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.accessory_section._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.accessory_section._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'accessory_section', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_accessory_section(bigint) IS 'stg_raw → stg_transform.accessory_section (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/04_catalogos/sp_transform_model.sql
-- ======================================================================
-- stg_transform.sp_transform_model
-- stg_raw → stg_transform.model  ·  Destino final: listings_db.model
-- Lee: stg_raw.newcars_models
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_model(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_model(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'model');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.newcars_models)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.models
    SELECT
        stg_control.fn_legacy_uuid('newcars.models', r."mcode"::text)          AS id,
        r."mcode"::text                                                        AS legacy_id,
        'newcars.models'                                                       AS legacy_source,
        stg_control.fn_legacy_uuid('newcars.dealers', r."mdealer"::text)       AS dealer_id,
        stg_control.fn_legacy_uuid('newcars.brands', r."mbrand"::text)         AS brand_id,
        stg_control.fn_clean_text(r."mbasemodel"::text)                        AS base_model,
        stg_control.fn_legacy_uuid('newcars.styles', r."mstyle"::text)         AS body_style_id,
        r."mpicscode"::text                                                    AS image_prefix,
        stg_control.fn_to_int(r."myear"::text)::smallint                       AS year,
        r."mprice"::numeric(14,2)                                              AS price,
        stg_control.fn_clean_text(r."mdescrip"::text)                          AS mdescrip,
        stg_control.fn_clean_text(r."motherspecs"::text)                       AS motherspecs,
        stg_control.fn_clean_text(r."mmaintext"::text)                         AS mmaintext,
        r."mnumpics"::integer                                                  AS mnumpics,
        r."mnumvideos"::integer                                                AS mnumvideos,
        stg_control.fn_clean_text(r."mequipment"::text)                        AS mequipment,
        stg_control.fn_clean_text(r."mmotor"::text)                            AS mmotor,
        r."menginesize"::integer                                               AS menginesize,
        stg_control.fn_clean_text(r."mpower"::text)                            AS mpower,
        stg_control.fn_clean_text(r."mtorque"::text)                           AS mtorque,
        stg_control.fn_clean_text(r."msuspension"::text)                       AS msuspension,
        stg_control.fn_clean_text(r."msteering"::text)                         AS msteering,
        stg_control.fn_clean_text(r."mtransmission"::text)                     AS mtransmission,
        stg_control.fn_clean_text(r."mtransmission2"::text)                    AS mtransmission2,
        stg_control.fn_clean_text(r."mbrakes"::text)                           AS mbrakes,
        stg_control.fn_clean_text(r."mtires"::text)                            AS mtires,
        stg_control.fn_clean_text(r."mwarranty"::text)                         AS mwarranty,
        stg_control.fn_clean_text(r."mfuel"::text)                             AS mfuel,
        stg_control.fn_clean_text(r."mdrive"::text)                            AS mdrive,
        stg_control.fn_clean_text(r."mfueltank"::text)                         AS mfueltank,
        stg_control.fn_clean_text(r."mmaxspeed"::text)                         AS mmaxspeed,
        r."mvalves"::integer                                                   AS mvalves,
        r."mdoors"::integer                                                    AS mdoors,
        stg_control.fn_to_bool(r."mvisible"::text)                             AS is_visible,
        stg_control.fn_clean_text(r."mweight"::text)                           AS mweight,
        stg_control.fn_clean_text(r."mheight"::text)                           AS mheight,
        stg_control.fn_clean_text(r."mwidth"::text)                            AS mwidth,
        stg_control.fn_clean_text(r."mlength"::text)                           AS mlength,
        stg_control.fn_clean_text(r."mdiameter"::text)                         AS mdiameter,
        stg_control.fn_clean_text(r."mvideo1"::text)                           AS mvideo1,
        'newcars'::text AS _source_db, 'models'::text AS _source_table, r."mcode"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.newcars_models r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.model (id, legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        base_model = EXCLUDED.base_model,
        body_style_id = EXCLUDED.body_style_id,
        image_prefix = EXCLUDED.image_prefix,
        year = EXCLUDED.year,
        price = EXCLUDED.price,
        mdescrip = EXCLUDED.mdescrip,
        motherspecs = EXCLUDED.motherspecs,
        mmaintext = EXCLUDED.mmaintext,
        mnumpics = EXCLUDED.mnumpics,
        mnumvideos = EXCLUDED.mnumvideos,
        mequipment = EXCLUDED.mequipment,
        mmotor = EXCLUDED.mmotor,
        menginesize = EXCLUDED.menginesize,
        mpower = EXCLUDED.mpower,
        mtorque = EXCLUDED.mtorque,
        msuspension = EXCLUDED.msuspension,
        msteering = EXCLUDED.msteering,
        mtransmission = EXCLUDED.mtransmission,
        mtransmission2 = EXCLUDED.mtransmission2,
        mbrakes = EXCLUDED.mbrakes,
        mtires = EXCLUDED.mtires,
        mwarranty = EXCLUDED.mwarranty,
        mfuel = EXCLUDED.mfuel,
        mdrive = EXCLUDED.mdrive,
        mfueltank = EXCLUDED.mfueltank,
        mmaxspeed = EXCLUDED.mmaxspeed,
        mvalves = EXCLUDED.mvalves,
        mdoors = EXCLUDED.mdoors,
        is_visible = EXCLUDED.is_visible,
        mweight = EXCLUDED.mweight,
        mheight = EXCLUDED.mheight,
        mwidth = EXCLUDED.mwidth,
        mlength = EXCLUDED.mlength,
        mdiameter = EXCLUDED.mdiameter,
        mvideo1 = EXCLUDED.mvideo1,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.model._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.model._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'model', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_model(bigint) IS 'stg_raw → stg_transform.model (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_app_user.sql
-- ======================================================================
-- stg_transform.sp_transform_app_user
-- stg_raw → stg_transform.app_user  ·  Destino final: users_db.app_user
-- Lee: stg_raw.micrautos_users
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_app_user(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_app_user(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'app_user');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.micrautos_users)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.users
    -- No se migran: upwd, umenustyle, umainmenubg, umainbgcolor, umodelstitle, umodelnamebg, udestacadoscolor, udestacadosheader, udetailmaintitle, udetailsubtitle, udetailequiptitle, udetailequip, ulisthighlight, umodelborder, unewmenubg, actreqs, actattempts
    SELECT
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS id,
        r."ucode"::text                                                        AS legacy_id,
        'micrautos.users'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."uname"::text)                             AS first_name,
        stg_control.fn_clean_text(r."ulname"::text)                            AS last_name,
        stg_control.fn_map_code('ID_TYPE', 'micrautos', r."uidtype"::text)     AS id_type,
        stg_control.fn_clean_id_number(r."uidnum")                             AS id_number,
        stg_control.fn_make_date(r."uyear", r."umonth", r."uday")              AS birth_date,  -- combina uday, umonth, uyear
        stg_control.fn_map_code('GENDER', 'micrautos', r."usex"::text)         AS gender,
        stg_control.fn_clean_email(r."uemail")                                 AS email,
        stg_control.fn_to_date(r."udatein")                                    AS created_at,
        stg_control.fn_to_timestamptz(r."ulastlogin")                          AS last_login_at,
        stg_control.fn_map_code('USER_STATUS', 'micrautos', r."ustatus"::text) AS status,
        stg_control.fn_clean_text(r."uaddr1"::text)                            AS address_line1,
        stg_control.fn_clean_text(r."uaddr2"::text)                            AS address_line2,
        stg_control.fn_clean_text(r."ucity"::text)                             AS city,
        stg_control.fn_map_code('COUNTRY', 'micrautos', r."ucountry"::text)    AS country,
        stg_control.fn_clean_text(r."upostalcode"::text)                       AS postal_code,
        stg_control.fn_clean_phone_cr(r."uphonehome")                          AS phone_home,
        stg_control.fn_clean_phone_cr(r."uphonework")                          AS phone_work,
        stg_control.fn_clean_phone_cr(r."uphonecel")                           AS phone_mobile,
        r."ufreead"::text                                                      AS free_ad_flag,  -- POR CONFIRMAR
        stg_control.fn_to_bool(r."usendemail"::text)                           AS accepts_email,
        stg_control.fn_clean_text(r."unick"::text)                             AS nickname,
        'micrautos'::text AS _source_db, 'users'::text AS _source_table, r."ucode"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.micrautos_users r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.app_user (id, legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        first_name = EXCLUDED.first_name,
        last_name = EXCLUDED.last_name,
        id_type = EXCLUDED.id_type,
        id_number = EXCLUDED.id_number,
        birth_date = EXCLUDED.birth_date,
        gender = EXCLUDED.gender,
        email = EXCLUDED.email,
        created_at = EXCLUDED.created_at,
        last_login_at = EXCLUDED.last_login_at,
        status = EXCLUDED.status,
        address_line1 = EXCLUDED.address_line1,
        address_line2 = EXCLUDED.address_line2,
        city = EXCLUDED.city,
        country = EXCLUDED.country,
        postal_code = EXCLUDED.postal_code,
        phone_home = EXCLUDED.phone_home,
        phone_work = EXCLUDED.phone_work,
        phone_mobile = EXCLUDED.phone_mobile,
        free_ad_flag = EXCLUDED.free_ad_flag,
        accepts_email = EXCLUDED.accepts_email,
        nickname = EXCLUDED.nickname,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.app_user._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.app_user._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'app_user', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_app_user(bigint) IS 'stg_raw → stg_transform.app_user (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_seller.sql
-- ======================================================================
-- stg_transform.sp_transform_seller
-- stg_raw → stg_transform.seller  ·  Destino final: users_db.seller
-- Lee: stg_raw.usedcars_sellers + stg_raw.accesorios_sellers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_seller(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_seller(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'seller');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_sellers)
        + (SELECT count(*) FROM stg_raw.accesorios_sellers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.sellers
    -- No se migran: sellerpwd, sellerpwd2, favcount
    SELECT
        stg_control.fn_legacy_uuid('usedcars.sellers', r."selleremail"::text)  AS id,
        r."selleremail"::text                                                  AS legacy_id,
        'usedcars.sellers'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."sellername"::text)                        AS name,
        stg_control.fn_clean_phone_cr(r."sellerphone")                         AS phone,
        stg_control.fn_clean_email(r."selleremail")                            AS email,
        stg_control.fn_to_date(r."sellerindate")                               AS start_date,
        stg_control.fn_to_date(r."sellerexpire")                               AS expiration_date,
        r."sellerlimit"::integer                                               AS ad_limit,
        stg_control.fn_map_code('SELLER_STATUS', 'usedcars', r."sellerstatus"::text) AS status,
        r."sellercode"::text                                                   AS seller_code,
        r."sellerplanamt"::numeric(12,2)                                       AS plan_amount,
        stg_control.fn_clean_text(r."sitelink"::text)                          AS website,
        r."dollaramt"::numeric(12,2)                                           AS plan_amount_usd,  -- POR CONFIRMAR
        r."destacados"::integer                                                AS featured_quota,
        stg_control.fn_clean_text(r."dept"::text)                              AS department,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_clean_text(r."selleraddr1"::text)                       AS address_line1,
        stg_control.fn_clean_text(r."selleraddr2"::text)                       AS address_line2,
        stg_control.fn_map_code('PROVINCE', 'usedcars', r."sellerprovince"::text) AS province_id,
        stg_control.fn_clean_text(r."sellercity"::text)                        AS city,
        stg_control.fn_to_bool(r."financeflag"::text)                          AS offers_financing,  -- POR CONFIRMAR
        r."accountamount"::numeric(12,2)                                       AS account_balance,
        stg_control.fn_to_timestamptz(r."accountlastdeposit")                  AS last_deposit_at,
        stg_control.fn_to_timestamptz(r."accountlastcharge")                   AS last_charge_at,
        stg_control.fn_to_date(r."bannerstart")                                AS banner_start_date,
        stg_control.fn_to_date(r."bannerend")                                  AS banner_end_date,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        stg_control.fn_clean_text(r."video"::text)                             AS video_html,
        stg_control.fn_clean_phone_cr(r."sellerwhatsapp")                      AS whatsapp,
        stg_control.fn_clean_text(r."rep"::text)                               AS sales_rep,
        stg_control.fn_clean_text(r."contactname"::text)                       AS contact_name,
        stg_control.fn_clean_phone_cr(r."contactphone")                        AS contact_phone,
        stg_control.fn_clean_email(r."contactemail")                           AS contact_email,
        NULL::text                                                             AS phone_2,  -- no viene de usedcars.sellers
        NULL::text                                                             AS phone_3,  -- no viene de usedcars.sellers
        NULL::text                                                             AS logo_s3_key,  -- no viene de usedcars.sellers
        'usedcars'::text AS _source_db, 'sellers'::text AS _source_table, r."selleremail"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_sellers r
    UNION ALL
    -- ---- accesorios.sellers
    -- No se migran: sellerpwd, favcount
    SELECT
        stg_control.fn_legacy_uuid('accesorios.sellers', r."selleremail"::text) AS id,
        r."selleremail"::text                                                  AS legacy_id,
        'accesorios.sellers'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."sellername"::text)                        AS name,
        stg_control.fn_clean_phone_cr(r."sellertel1")                          AS phone,
        stg_control.fn_clean_email(r."selleremail")                            AS email,
        stg_control.fn_to_date(r."sellerindate")                               AS start_date,
        stg_control.fn_to_date(r."sellerexpire")                               AS expiration_date,
        r."sellerlimit"::integer                                               AS ad_limit,
        stg_control.fn_map_code('SELLER_STATUS', 'accesorios', r."sellerstatus"::text) AS status,
        r."sellercode"::text                                                   AS seller_code,
        r."sellerplanamt"::numeric(12,2)                                       AS plan_amount,
        stg_control.fn_clean_text(r."sitelink"::text)                          AS website,
        r."dollaramt"::numeric(12,2)                                           AS plan_amount_usd,  -- POR CONFIRMAR
        r."destacados"::integer                                                AS featured_quota,
        stg_control.fn_clean_text(r."dept"::text)                              AS department,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."currency"::text)  AS currency,
        stg_control.fn_clean_text(r."selleraddr1"::text)                       AS address_line1,
        stg_control.fn_clean_text(r."selleraddr2"::text)                       AS address_line2,
        stg_control.fn_map_code('PROVINCE', 'accesorios', r."sellerprovince"::text) AS province_id,
        stg_control.fn_clean_text(r."sellercity"::text)                        AS city,
        NULL::boolean                                                          AS offers_financing,  -- no viene de accesorios.sellers
        r."accountamount"::numeric(12,2)                                       AS account_balance,
        stg_control.fn_to_timestamptz(r."accountlastdeposit")                  AS last_deposit_at,
        stg_control.fn_to_timestamptz(r."accountlastcharge")                   AS last_charge_at,
        NULL::date                                                             AS banner_start_date,  -- no viene de accesorios.sellers
        NULL::date                                                             AS banner_end_date,  -- no viene de accesorios.sellers
        NULL::boolean                                                          AS is_premium,  -- no viene de accesorios.sellers
        NULL::text                                                             AS video_html,  -- no viene de accesorios.sellers
        NULL::text                                                             AS whatsapp,  -- no viene de accesorios.sellers
        NULL::text                                                             AS sales_rep,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_name,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_phone,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_email,  -- no viene de accesorios.sellers
        stg_control.fn_clean_phone_cr(r."sellertel2")                          AS phone_2,
        stg_control.fn_clean_phone_cr(r."sellertel3")                          AS phone_3,
        r."logo"::text                                                         AS logo_s3_key,
        'accesorios'::text AS _source_db, 'sellers'::text AS _source_table, r."selleremail"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.accesorios_sellers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.seller (id, legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        start_date = EXCLUDED.start_date,
        expiration_date = EXCLUDED.expiration_date,
        ad_limit = EXCLUDED.ad_limit,
        status = EXCLUDED.status,
        seller_code = EXCLUDED.seller_code,
        plan_amount = EXCLUDED.plan_amount,
        website = EXCLUDED.website,
        plan_amount_usd = EXCLUDED.plan_amount_usd,
        featured_quota = EXCLUDED.featured_quota,
        department = EXCLUDED.department,
        currency = EXCLUDED.currency,
        address_line1 = EXCLUDED.address_line1,
        address_line2 = EXCLUDED.address_line2,
        province_id = EXCLUDED.province_id,
        city = EXCLUDED.city,
        offers_financing = EXCLUDED.offers_financing,
        account_balance = EXCLUDED.account_balance,
        last_deposit_at = EXCLUDED.last_deposit_at,
        last_charge_at = EXCLUDED.last_charge_at,
        banner_start_date = EXCLUDED.banner_start_date,
        banner_end_date = EXCLUDED.banner_end_date,
        is_premium = EXCLUDED.is_premium,
        video_html = EXCLUDED.video_html,
        whatsapp = EXCLUDED.whatsapp,
        sales_rep = EXCLUDED.sales_rep,
        contact_name = EXCLUDED.contact_name,
        contact_phone = EXCLUDED.contact_phone,
        contact_email = EXCLUDED.contact_email,
        phone_2 = EXCLUDED.phone_2,
        phone_3 = EXCLUDED.phone_3,
        logo_s3_key = EXCLUDED.logo_s3_key,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.seller._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.seller._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'seller', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_seller(bigint) IS 'stg_raw → stg_transform.seller (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_dealer.sql
-- ======================================================================
-- stg_transform.sp_transform_dealer
-- stg_raw → stg_transform.dealer  ·  Destino final: users_db.dealer
-- Lee: stg_raw.usedcars_dealers + stg_raw.newcars_dealers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_dealer(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_dealer(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'dealer');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_dealers)
        + (SELECT count(*) FROM stg_raw.newcars_dealers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.dealers  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: folder
    SELECT
        stg_control.fn_legacy_uuid('usedcars.dealers', md5(concat_ws('|', r."dealercode", r."dealername", r."folder", r."link", r."demail"))) AS id,
        r."dealercode"::text                                                   AS legacy_id,
        'usedcars.dealers'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."dealername"::text)                        AS name,
        stg_control.fn_clean_text(r."link"::text)                              AS website,
        stg_control.fn_clean_email(r."demail")                                 AS email,
        NULL::text                                                             AS address,  -- no viene de usedcars.dealers
        NULL::text                                                             AS notes,  -- no viene de usedcars.dealers
        NULL::text                                                             AS username,  -- no viene de usedcars.dealers
        NULL::text                                                             AS email_2,  -- no viene de usedcars.dealers
        NULL::text                                                             AS email_3,  -- no viene de usedcars.dealers
        NULL::text                                                             AS seller_code,  -- no viene de usedcars.dealers
        'usedcars'::text AS _source_db, 'dealers'::text AS _source_table, md5(concat_ws('|', r."dealercode", r."dealername", r."folder", r."link", r."demail")) AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_dealers r
    UNION ALL
    -- ---- newcars.dealers
    -- No se migran: dpwd
    SELECT
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)         AS id,
        r."dcode"::text                                                        AS legacy_id,
        'newcars.dealers'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."dname"::text)                             AS name,
        stg_control.fn_clean_text(r."dwebsite"::text)                          AS website,
        stg_control.fn_clean_email(r."email1")                                 AS email,
        stg_control.fn_clean_text(r."daddress"::text)                          AS address,
        stg_control.fn_clean_text(r."dotherinfo"::text)                        AS notes,
        stg_control.fn_clean_text(r."duser"::text)                             AS username,
        stg_control.fn_clean_email(r."email2")                                 AS email_2,
        stg_control.fn_clean_email(r."email3")                                 AS email_3,
        r."dusedcode"::text                                                    AS seller_code,  -- POR CONFIRMAR
        'newcars'::text AS _source_db, 'dealers'::text AS _source_table, r."dcode"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.newcars_dealers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.dealer (id, legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        website = EXCLUDED.website,
        email = EXCLUDED.email,
        address = EXCLUDED.address,
        notes = EXCLUDED.notes,
        username = EXCLUDED.username,
        email_2 = EXCLUDED.email_2,
        email_3 = EXCLUDED.email_3,
        seller_code = EXCLUDED.seller_code,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.dealer._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.dealer._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'dealer', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_dealer(bigint) IS 'stg_raw → stg_transform.dealer (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_dealer_contact.sql
-- ======================================================================
-- stg_transform.sp_transform_dealer_contact
-- stg_raw → stg_transform.dealer_contact  ·  Destino final: users_db.dealer_contact
-- Lee: stg_raw.newcars_dealers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_dealer_contact(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_dealer_contact(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'dealer_contact');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.newcars_dealers)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.dealers: pivot dphoneN / dphonerefN
    SELECT
        stg_control.fn_legacy_uuid('newcars.dealers:contact', r."dcode"::text || '|' || v.n) AS id,
        r."dcode"::text || '|' || v.n                                        AS legacy_id,
        'newcars.dealers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)                                                   AS dealer_id,
        stg_control.fn_clean_phone_cr(v.phone)                     AS phone,
        stg_control.fn_clean_text(v.label)                         AS phone_label,
        v.n::smallint                                              AS sort_order,
        'newcars'::text AS _source_db, 'dealers'::text AS _source_table, r."dcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.newcars_dealers r
    CROSS JOIN LATERAL (VALUES
            (1, r."dphone1"::text, r."dphoneref1"::text),
            (2, r."dphone2"::text, r."dphoneref2"::text),
            (3, r."dphone3"::text, r."dphoneref3"::text),
            (4, r."dphone4"::text, r."dphoneref4"::text),
            (5, r."dphone5"::text, r."dphoneref5"::text),
            (6, r."dphone6"::text, r."dphoneref6"::text),
            (7, r."dphone7"::text, r."dphoneref7"::text),
            (8, r."dphone8"::text, r."dphoneref8"::text),
            (9, r."dphone9"::text, r."dphoneref9"::text),
            (10, r."dphone10"::text, r."dphoneref10"::text),
            (11, r."dphone11"::text, r."dphoneref11"::text),
            (12, r."dphone12"::text, r."dphoneref12"::text),
            (13, r."dphone13"::text, r."dphoneref13"::text),
            (14, r."dphone14"::text, r."dphoneref14"::text),
            (15, r."dphone15"::text, r."dphoneref15"::text),
            (16, r."dphone16"::text, r."dphoneref16"::text),
            (17, r."dphone17"::text, r."dphoneref17"::text),
            (18, r."dphone18"::text, r."dphoneref18"::text),
            (19, r."dphone19"::text, r."dphoneref19"::text),
            (20, r."dphone20"::text, r."dphoneref20"::text),
            (21, r."dphone21"::text, r."dphoneref21"::text),
            (22, r."dphone22"::text, r."dphoneref22"::text),
            (23, r."dphone23"::text, r."dphoneref23"::text),
            (24, r."dphone24"::text, r."dphoneref24"::text),
            (25, r."dphone25"::text, r."dphoneref25"::text)
         ) AS v(n, phone, label)
    WHERE nullif(trim(v.phone), '') IS NOT NULL
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.dealer_contact (id, legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        dealer_id = EXCLUDED.dealer_id,
        phone = EXCLUDED.phone,
        phone_label = EXCLUDED.phone_label,
        sort_order = EXCLUDED.sort_order,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.dealer_contact._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.dealer_contact._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'dealer_contact', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_dealer_contact(bigint) IS 'stg_raw → stg_transform.dealer_contact (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_admin_user.sql
-- ======================================================================
-- stg_transform.sp_transform_admin_user
-- stg_raw → stg_transform.admin_user  ·  Destino final: users_db.admin_user
-- Lee: stg_raw.usedcars_adminusers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_admin_user(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_admin_user(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'admin_user');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_adminusers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.adminusers
    -- No se migran: userpwd
    SELECT
        stg_control.fn_legacy_uuid('usedcars.adminusers', r."userid"::text)    AS id,
        r."userid"::text                                                       AS legacy_id,
        'usedcars.adminusers'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."userid"::text)                            AS username,
        stg_control.fn_map_code('ADMIN_LEVEL', 'usedcars', r."userlevel"::text) AS role,
        stg_control.fn_clean_text(r."username"::text)                          AS full_name,
        stg_control.fn_clean_phone_cr(r."userphone")                           AS phone,
        stg_control.fn_clean_text(r."userposition"::text)                      AS position,
        'usedcars'::text AS _source_db, 'adminusers'::text AS _source_table, r."userid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_adminusers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.admin_user (id, legacy_id, legacy_source, username, role, full_name, phone, position,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, username, role, full_name, phone, position,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, username, role, full_name, phone, position)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        username = EXCLUDED.username,
        role = EXCLUDED.role,
        full_name = EXCLUDED.full_name,
        phone = EXCLUDED.phone,
        position = EXCLUDED.position,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.admin_user._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.admin_user._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'admin_user', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_admin_user(bigint) IS 'stg_raw → stg_transform.admin_user (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing.sql
-- ======================================================================
-- stg_transform.sp_transform_listing
-- stg_raw → stg_transform.listing  ·  Destino final: listings_db.listing
-- Lee: stg_raw.usedcars_datafile + stg_raw.usedcars_archive + stg_raw.usedcars_expiredsellers + stg_raw.usedcars_pending + stg_raw.usedcars_pendingpay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_datafile)
        + (SELECT count(*) FROM stg_raw.usedcars_archive)
        + (SELECT count(*) FROM stg_raw.usedcars_expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars_pending)
        + (SELECT count(*) FROM stg_raw.usedcars_pendingpay)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.datafile'                                                    AS legacy_source,
        'ACTIVE'                                                               AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_datafile r
    UNION ALL
    -- ---- usedcars.archive
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.archive'                                                     AS legacy_source,
        'ARCHIVED'                                                             AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.usedcars_archive r
    UNION ALL
    -- ---- usedcars.expiredsellers
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.expiredsellers'                                              AS legacy_source,
        'EXPIRED'                                                              AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 3 AS _prio
    FROM stg_raw.usedcars_expiredsellers r
    UNION ALL
    -- ---- usedcars.pending
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.pending'                                                     AS legacy_source,
        'PENDING_APPROVAL'                                                     AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 4 AS _prio
    FROM stg_raw.usedcars_pending r
    UNION ALL
    -- ---- usedcars.pendingpay
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.pendingpay'                                                  AS legacy_source,
        'PENDING_PAYMENT'                                                      AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 5 AS _prio
    FROM stg_raw.usedcars_pendingpay r
    ),
    dedup AS (
    -- Un mismo codigo puede existir en varias tablas del ciclo de vida: gana la de menor _prio
    -- (datafile > archive > expiredsellers > pending > pendingpay) y, dentro de la misma, el último cambio DMS.
    -- Los duplicados reales se reportan en sp_validate (regla VAL_LISTING_DUP_LIFECYCLE).
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing (id, legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        publication_lifecycle = EXCLUDED.publication_lifecycle,
        reference_code = EXCLUDED.reference_code,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        model_name = EXCLUDED.model_name,
        engine = EXCLUDED.engine,
        year = EXCLUDED.year,
        body_style_id = EXCLUDED.body_style_id,
        passengers = EXCLUDED.passengers,
        price = EXCLUDED.price,
        previous_price = EXCLUDED.previous_price,
        exchange_rate = EXCLUDED.exchange_rate,
        transfer_cost = EXCLUDED.transfer_cost,
        condition_code = EXCLUDED.condition_code,
        exterior_color = EXCLUDED.exterior_color,
        contact_phone = EXCLUDED.contact_phone,
        contact_whatsapp = EXCLUDED.contact_whatsapp,
        contact_email = EXCLUDED.contact_email,
        summary = EXCLUDED.summary,
        description = EXCLUDED.description,
        ai_description = EXCLUDED.ai_description,
        contact_name = EXCLUDED.contact_name,
        image_count = EXCLUDED.image_count,
        fuel_type = EXCLUDED.fuel_type,
        ev_range = EXCLUDED.ev_range,
        ev_range_unit = EXCLUDED.ev_range_unit,
        battery_kwh = EXCLUDED.battery_kwh,
        transmission = EXCLUDED.transmission,
        publication_status = EXCLUDED.publication_status,
        mileage = EXCLUDED.mileage,
        mileage_unit = EXCLUDED.mileage_unit,
        source_channel = EXCLUDED.source_channel,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        option_6 = EXCLUDED.option_6,
        option_7 = EXCLUDED.option_7,
        option_8 = EXCLUDED.option_8,
        option_9 = EXCLUDED.option_9,
        option_10 = EXCLUDED.option_10,
        visit_count = EXCLUDED.visit_count,
        has_interior_360 = EXCLUDED.has_interior_360,
        video_url = EXCLUDED.video_url,
        interior_color = EXCLUDED.interior_color,
        is_negotiable = EXCLUDED.is_negotiable,
        is_registered = EXCLUDED.is_registered,
        plate = EXCLUDED.plate,
        doors = EXCLUDED.doors,
        province_id = EXCLUDED.province_id,
        accepts_trade_in = EXCLUDED.accepts_trade_in,
        vin = EXCLUDED.vin,
        approved_by = EXCLUDED.approved_by,
        deleted_by = EXCLUDED.deleted_by,
        deleted_at = EXCLUDED.deleted_at,
        is_blocked = EXCLUDED.is_blocked,
        blocked_reason = EXCLUDED.blocked_reason,
        blocked_by = EXCLUDED.blocked_by,
        currency = EXCLUDED.currency,
        is_premium = EXCLUDED.is_premium,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing(bigint) IS 'stg_raw → stg_transform.listing (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing_transfer.sql
-- ======================================================================
-- stg_transform.sp_transform_listing_transfer
-- stg_raw → stg_transform.listing_transfer  ·  Destino final: listings_db.listing_transfer
-- Lee: stg_raw.usedcars_archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_transfer(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_transfer(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_transfer');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.archivetraspaso
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('usedcars.archivetraspaso', concat_ws('|', r."refcode", r."codigo")) AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.archivetraspaso'                                             AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_text(r."certificar"::text)                        AS certification,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_archivetraspaso r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_transfer (id, legacy_id, legacy_source, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, certification, fuel_type, transmission, publication_status, mileage, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, certification, fuel_type, transmission, publication_status, mileage, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, certification, fuel_type, transmission, publication_status, mileage, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        reference_code = EXCLUDED.reference_code,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        model_name = EXCLUDED.model_name,
        engine = EXCLUDED.engine,
        year = EXCLUDED.year,
        body_style_id = EXCLUDED.body_style_id,
        passengers = EXCLUDED.passengers,
        price = EXCLUDED.price,
        previous_price = EXCLUDED.previous_price,
        exchange_rate = EXCLUDED.exchange_rate,
        condition_code = EXCLUDED.condition_code,
        exterior_color = EXCLUDED.exterior_color,
        contact_phone = EXCLUDED.contact_phone,
        contact_whatsapp = EXCLUDED.contact_whatsapp,
        contact_email = EXCLUDED.contact_email,
        summary = EXCLUDED.summary,
        description = EXCLUDED.description,
        ai_description = EXCLUDED.ai_description,
        contact_name = EXCLUDED.contact_name,
        certification = EXCLUDED.certification,
        fuel_type = EXCLUDED.fuel_type,
        transmission = EXCLUDED.transmission,
        publication_status = EXCLUDED.publication_status,
        mileage = EXCLUDED.mileage,
        source_channel = EXCLUDED.source_channel,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        option_6 = EXCLUDED.option_6,
        option_7 = EXCLUDED.option_7,
        option_8 = EXCLUDED.option_8,
        option_9 = EXCLUDED.option_9,
        option_10 = EXCLUDED.option_10,
        visit_count = EXCLUDED.visit_count,
        has_interior_360 = EXCLUDED.has_interior_360,
        video_url = EXCLUDED.video_url,
        interior_color = EXCLUDED.interior_color,
        is_negotiable = EXCLUDED.is_negotiable,
        is_registered = EXCLUDED.is_registered,
        plate = EXCLUDED.plate,
        doors = EXCLUDED.doors,
        province_id = EXCLUDED.province_id,
        accepts_trade_in = EXCLUDED.accepts_trade_in,
        vin = EXCLUDED.vin,
        approved_by = EXCLUDED.approved_by,
        deleted_by = EXCLUDED.deleted_by,
        deleted_at = EXCLUDED.deleted_at,
        is_blocked = EXCLUDED.is_blocked,
        blocked_reason = EXCLUDED.blocked_reason,
        blocked_by = EXCLUDED.blocked_by,
        currency = EXCLUDED.currency,
        is_premium = EXCLUDED.is_premium,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_transfer._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_transfer._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_transfer', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_transfer(bigint) IS 'stg_raw → stg_transform.listing_transfer (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing_image.sql
-- ======================================================================
-- stg_transform.sp_transform_listing_image
-- stg_raw → stg_transform.listing_image  ·  Destino final: listings_db.listing_image
-- Lee: stg_raw.usedcars_datafile + stg_raw.usedcars_archive + stg_raw.usedcars_expiredsellers + stg_raw.usedcars_pending + stg_raw.usedcars_pendingpay + stg_raw.usedcars_archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_image(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_image(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_image');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_datafile)
        + (SELECT count(*) FROM stg_raw.usedcars_archive)
        + (SELECT count(*) FROM stg_raw.usedcars_expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars_pending)
        + (SELECT count(*) FROM stg_raw.usedcars_pendingpay)
        + (SELECT count(*) FROM stg_raw.usedcars_archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.datafile'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_datafile r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.archive: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archive'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.usedcars_archive r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.expiredsellers: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.expiredsellers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 3 AS _prio
    FROM stg_raw.usedcars_expiredsellers r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.pending: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pending'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 4 AS _prio
    FROM stg_raw.usedcars_pending r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.pendingpay: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pendingpay'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 5 AS _prio
    FROM stg_raw.usedcars_pendingpay r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.archivetraspaso: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archivetraspaso'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 6 AS _prio
    FROM stg_raw.usedcars_archivetraspaso r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_image (id, legacy_id, legacy_source, listing_id, s3_key, sort_order,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, s3_key, sort_order,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, s3_key, sort_order)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        s3_key = EXCLUDED.s3_key,
        sort_order = EXCLUDED.sort_order,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_image._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_image._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_image', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_image(bigint) IS 'stg_raw → stg_transform.listing_image (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_listing_equipment.sql
-- ======================================================================
-- stg_transform.sp_transform_listing_equipment
-- stg_raw → stg_transform.listing_equipment  ·  Destino final: listings_db.listing_equipment
-- Lee: stg_raw.usedcars_datafile + stg_raw.usedcars_archive + stg_raw.usedcars_expiredsellers + stg_raw.usedcars_pending + stg_raw.usedcars_pendingpay + stg_raw.usedcars_archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_equipment(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_equipment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_equipment');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_datafile)
        + (SELECT count(*) FROM stg_raw.usedcars_archive)
        + (SELECT count(*) FROM stg_raw.usedcars_expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars_pending)
        + (SELECT count(*) FROM stg_raw.usedcars_pendingpay)
        + (SELECT count(*) FROM stg_raw.usedcars_archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.datafile'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_datafile r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.archive: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archive'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.usedcars_archive r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.expiredsellers: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.expiredsellers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 3 AS _prio
    FROM stg_raw.usedcars_expiredsellers r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.pending: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pending'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 4 AS _prio
    FROM stg_raw.usedcars_pending r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.pendingpay: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pendingpay'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 5 AS _prio
    FROM stg_raw.usedcars_pendingpay r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.archivetraspaso: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archivetraspaso'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 6 AS _prio
    FROM stg_raw.usedcars_archivetraspaso r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_equipment (id, legacy_id, legacy_source, listing_id, equipment_id, feature_slot,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, equipment_id, feature_slot,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, equipment_id, feature_slot)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        equipment_id = EXCLUDED.equipment_id,
        feature_slot = EXCLUDED.feature_slot,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_equipment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_equipment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_equipment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_equipment(bigint) IS 'stg_raw → stg_transform.listing_equipment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_special_deal.sql
-- ======================================================================
-- stg_transform.sp_transform_special_deal
-- stg_raw → stg_transform.special_deal  ·  Destino final: listings_db.special_deal
-- Lee: stg_raw.usedcars_specialdeals
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_special_deal(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_special_deal(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'special_deal');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_specialdeals)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.specialdeals
    SELECT
        stg_control.fn_legacy_uuid('usedcars.specialdeals', concat_ws('|', r."adcode", r."ddate")) AS id,
        concat_ws('|', r."adcode", r."ddate")                                  AS legacy_id,
        'usedcars.specialdeals'                                                AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."adcode"::text)                AS listing_id,
        stg_control.fn_to_date(r."ddate")                                      AS deal_date,
        r."dprice"::numeric(14,2)                                              AS deal_price,
        'usedcars'::text AS _source_db, 'specialdeals'::text AS _source_table, concat_ws('|', r."adcode", r."ddate") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_specialdeals r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.special_deal (id, legacy_id, legacy_source, listing_id, deal_date, deal_price,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, deal_date, deal_price,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, deal_date, deal_price)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        deal_date = EXCLUDED.deal_date,
        deal_price = EXCLUDED.deal_price,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.special_deal._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.special_deal._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'special_deal', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_special_deal(bigint) IS 'stg_raw → stg_transform.special_deal (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/03_publicaciones/sp_transform_banner.sql
-- ======================================================================
-- stg_transform.sp_transform_banner
-- stg_raw → stg_transform.banner  ·  Destino final: listings_db.banner
-- Lee: stg_raw.newcars_mainbanners
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_banner(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_banner(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'banner');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.newcars_mainbanners)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.mainbanners
    SELECT
        stg_control.fn_legacy_uuid('newcars.mainbanners', r."codigo"::text)    AS id,
        r."codigo"::text                                                       AS legacy_id,
        'newcars.mainbanners'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."client"::text)                            AS client_name,
        r."filename"::text                                                     AS image_s3_key,
        stg_control.fn_clean_text(r."link"::text)                              AS link_url,
        stg_control.fn_clean_text(r."mobilelink"::text)                        AS mobile_link_url,
        stg_control.fn_clean_text(r."target"::text)                            AS link_target,
        stg_control.fn_to_date(r."startdate")                                  AS start_date,
        stg_control.fn_to_date(r."enddate")                                    AS end_date,
        'newcars'::text AS _source_db, 'mainbanners'::text AS _source_table, r."codigo"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.newcars_mainbanners r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.banner (id, legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        client_name = EXCLUDED.client_name,
        image_s3_key = EXCLUDED.image_s3_key,
        link_url = EXCLUDED.link_url,
        mobile_link_url = EXCLUDED.mobile_link_url,
        link_target = EXCLUDED.link_target,
        start_date = EXCLUDED.start_date,
        end_date = EXCLUDED.end_date,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.banner._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.banner._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'banner', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_banner(bigint) IS 'stg_raw → stg_transform.banner (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/05_accesorios/sp_transform_accessory_listing.sql
-- ======================================================================
-- stg_transform.sp_transform_accessory_listing
-- stg_raw → stg_transform.accessory_listing  ·  Destino final: listings_db.accessory_listing
-- Lee: stg_raw.accesorios_archive + stg_raw.accesorios_pendingpay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_accessory_listing(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_accessory_listing(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'accessory_listing');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.accesorios_archive)
        + (SELECT count(*) FROM stg_raw.accesorios_pendingpay)
      INTO v_in;

    WITH src AS (
    -- ---- accesorios.archive
    -- No se migran: ip, pwd
    SELECT
        stg_control.fn_legacy_uuid('accesorios.archive', r."codigo"::text)     AS id,
        r."codigo"::text                                                       AS legacy_id,
        'accesorios.archive'                                                   AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        stg_control.fn_map_code('ACC_ESTADO', 'accesorios', r."estado"::text)  AS condition_code,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."expdate")                             AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_phone_cr(r."tel1")                                AS phone,
        stg_control.fn_clean_phone_cr(r."tel2")                                AS phone_2,
        stg_control.fn_clean_phone_cr(r."tel3")                                AS phone_3,
        r."precio"::numeric(14,2)                                              AS price,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."moneda"::text)    AS currency,
        r."refprice"::numeric(14,2)                                            AS reference_price,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."titulo"::text)                            AS title,
        stg_control.fn_clean_text(r."itemdesc"::text)                          AS description,
        stg_control.fn_legacy_uuid('accesorios.sections', r."seccion"::text)   AS section_id,
        stg_control.fn_to_date(r."deldate")                                    AS deleted_at,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        'accesorios'::text AS _source_db, 'archive'::text AS _source_table, r."codigo"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.accesorios_archive r
    UNION ALL
    -- ---- accesorios.pendingpay
    -- No se migran: ip, pwd
    SELECT
        stg_control.fn_legacy_uuid('accesorios.pendingpay', r."codigo"::text)  AS id,
        r."codigo"::text                                                       AS legacy_id,
        'accesorios.pendingpay'                                                AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        stg_control.fn_map_code('ACC_ESTADO', 'accesorios', r."estado"::text)  AS condition_code,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."expdate")                             AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_phone_cr(r."tel1")                                AS phone,
        stg_control.fn_clean_phone_cr(r."tel2")                                AS phone_2,
        stg_control.fn_clean_phone_cr(r."tel3")                                AS phone_3,
        r."precio"::numeric(14,2)                                              AS price,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."moneda"::text)    AS currency,
        r."refprice"::numeric(14,2)                                            AS reference_price,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."titulo"::text)                            AS title,
        stg_control.fn_clean_text(r."itemdesc"::text)                          AS description,
        stg_control.fn_legacy_uuid('accesorios.sections', r."seccion"::text)   AS section_id,
        stg_control.fn_to_date(r."deldate")                                    AS deleted_at,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        'accesorios'::text AS _source_db, 'pendingpay'::text AS _source_table, r."codigo"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.accesorios_pendingpay r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.accessory_listing (id, legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        reference_code = EXCLUDED.reference_code,
        condition_code = EXCLUDED.condition_code,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        visit_count = EXCLUDED.visit_count,
        image_count = EXCLUDED.image_count,
        contact_name = EXCLUDED.contact_name,
        contact_email = EXCLUDED.contact_email,
        phone = EXCLUDED.phone,
        phone_2 = EXCLUDED.phone_2,
        phone_3 = EXCLUDED.phone_3,
        price = EXCLUDED.price,
        currency = EXCLUDED.currency,
        reference_price = EXCLUDED.reference_price,
        title = EXCLUDED.title,
        description = EXCLUDED.description,
        section_id = EXCLUDED.section_id,
        deleted_at = EXCLUDED.deleted_at,
        deleted_by = EXCLUDED.deleted_by,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.accessory_listing._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.accessory_listing._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'accessory_listing', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_accessory_listing(bigint) IS 'stg_raw → stg_transform.accessory_listing (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_favorite.sql
-- ======================================================================
-- stg_transform.sp_transform_user_favorite
-- stg_raw → stg_transform.user_favorite  ·  Destino final: users_db.user_favorite
-- Lee: stg_raw.micrautos_favorites
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_favorite(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_favorite(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_favorite');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.micrautos_favorites)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.favorites
    SELECT
        stg_control.fn_legacy_uuid('micrautos.favorites', concat_ws('|', r."ucode", r."xcode")) AS id,
        concat_ws('|', r."ucode", r."xcode")                                   AS legacy_id,
        'micrautos.favorites'                                                  AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS user_id,
        stg_control.fn_legacy_uuid('listing', r."xcode"::text)                 AS listing_id,
        r."fcode"::text                                                        AS favorite_type,  -- POR CONFIRMAR
        stg_control.fn_to_timestamptz(r."fdate")                               AS created_at,
        stg_control.fn_clean_text(r."fextra"::text)                            AS notes,
        'micrautos'::text AS _source_db, 'favorites'::text AS _source_table, concat_ws('|', r."ucode", r."xcode") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.micrautos_favorites r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_favorite (id, legacy_id, legacy_source, user_id, listing_id, favorite_type, created_at, notes,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, listing_id, favorite_type, created_at, notes,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, listing_id, favorite_type, created_at, notes)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        listing_id = EXCLUDED.listing_id,
        favorite_type = EXCLUDED.favorite_type,
        created_at = EXCLUDED.created_at,
        notes = EXCLUDED.notes,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_favorite._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_favorite._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_favorite', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_favorite(bigint) IS 'stg_raw → stg_transform.user_favorite (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_friend.sql
-- ======================================================================
-- stg_transform.sp_transform_user_friend
-- stg_raw → stg_transform.user_friend  ·  Destino final: users_db.user_friend
-- Lee: stg_raw.micrautos_friends
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_friend(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_friend(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_friend');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.micrautos_friends)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.friends
    SELECT
        stg_control.fn_legacy_uuid('micrautos.friends', concat_ws('|', r."ucode", r."fcode")) AS id,
        r."fid"::text                                                          AS legacy_id,
        'micrautos.friends'                                                    AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS user_id,
        stg_control.fn_legacy_uuid('micrautos.users', r."fcode"::text)         AS friend_user_id,
        stg_control.fn_to_date(r."fdate")                                      AS created_at,
        'micrautos'::text AS _source_db, 'friends'::text AS _source_table, concat_ws('|', r."ucode", r."fcode") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.micrautos_friends r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_friend (id, legacy_id, legacy_source, user_id, friend_user_id, created_at,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, friend_user_id, created_at,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, friend_user_id, created_at)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        friend_user_id = EXCLUDED.friend_user_id,
        created_at = EXCLUDED.created_at,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_friend._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_friend._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_friend', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_friend(bigint) IS 'stg_raw → stg_transform.user_friend (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_request.sql
-- ======================================================================
-- stg_transform.sp_transform_user_request
-- stg_raw → stg_transform.user_request  ·  Destino final: users_db.user_request
-- Lee: stg_raw.micrautos_requests
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_request(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_request(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_request');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.micrautos_requests)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.requests
    SELECT
        stg_control.fn_legacy_uuid('micrautos.requests', r."reqid"::text)      AS id,
        r."reqid"::text                                                        AS legacy_id,
        'micrautos.requests'                                                   AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS user_id,
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)         AS dealer_id,
        stg_control.fn_map_code('REQUEST_TYPE', 'micrautos', r."reqtype"::text) AS request_type,
        jsonb_build_object('var1', r."var1", 'var2', r."var2", 'var3', r."var3") AS attributes,  -- combina var1, var2, var3
        stg_control.fn_clean_text(r."mtext"::text)                             AS message,
        stg_control.fn_to_timestamptz(r."rdate")                               AS created_at,
        'micrautos'::text AS _source_db, 'requests'::text AS _source_table, r."reqid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.micrautos_requests r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_request (id, legacy_id, legacy_source, user_id, dealer_id, request_type, attributes, message, created_at,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, dealer_id, request_type, attributes, message, created_at,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, dealer_id, request_type, attributes, message, created_at)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        dealer_id = EXCLUDED.dealer_id,
        request_type = EXCLUDED.request_type,
        attributes = EXCLUDED.attributes,
        message = EXCLUDED.message,
        created_at = EXCLUDED.created_at,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_request._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_request._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_request', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_request(bigint) IS 'stg_raw → stg_transform.user_request (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_suggestion.sql
-- ======================================================================
-- stg_transform.sp_transform_user_suggestion
-- stg_raw → stg_transform.user_suggestion  ·  Destino final: users_db.user_suggestion
-- Lee: stg_raw.micrautos_suggestions
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_suggestion(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_suggestion(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_suggestion');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.micrautos_suggestions)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.suggestions
    SELECT
        stg_control.fn_legacy_uuid('micrautos.suggestions', concat_ws('|', r."userid", r."datein")) AS id,
        concat_ws('|', r."userid", r."datein")                                 AS legacy_id,
        'micrautos.suggestions'                                                AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."userid"::text)        AS user_id,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_clean_text(r."suggestion"::text)                        AS suggestion_text,
        'micrautos'::text AS _source_db, 'suggestions'::text AS _source_table, concat_ws('|', r."userid", r."datein") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.micrautos_suggestions r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_suggestion (id, legacy_id, legacy_source, user_id, created_at, suggestion_text,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, created_at, suggestion_text,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, created_at, suggestion_text)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        created_at = EXCLUDED.created_at,
        suggestion_text = EXCLUDED.suggestion_text,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_suggestion._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_suggestion._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_suggestion', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_suggestion(bigint) IS 'stg_raw → stg_transform.user_suggestion (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/01_usuarios/sp_transform_user_report.sql
-- ======================================================================
-- stg_transform.sp_transform_user_report
-- stg_raw → stg_transform.user_report  ·  Destino final: users_db.user_report
-- Lee: stg_raw.micrautos_userreports
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_user_report(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_user_report(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'user_report');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.micrautos_userreports)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.userreports
    SELECT
        stg_control.fn_legacy_uuid('micrautos.userreports', concat_ws('|', r."userid", r."datein", r."adcode")) AS id,
        concat_ws('|', r."userid", r."datein", r."adcode")                     AS legacy_id,
        'micrautos.userreports'                                                AS legacy_source,
        stg_control.fn_legacy_uuid('micrautos.users', r."userid"::text)        AS user_id,
        stg_control.fn_legacy_uuid('listing', r."adcode"::text)                AS listing_id,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_clean_text(r."report"::text)                            AS report_text,
        stg_control.fn_clean_text(r."action"::text)                            AS action_taken,
        stg_control.fn_map_code('REPORT_STATUS', 'micrautos', r."repstatus"::text) AS status,
        stg_control.fn_clean_text(r."repcode"::text)                           AS report_code,
        'micrautos'::text AS _source_db, 'userreports'::text AS _source_table, concat_ws('|', r."userid", r."datein", r."adcode") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.micrautos_userreports r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.user_report (id, legacy_id, legacy_source, user_id, listing_id, created_at, report_text, action_taken, status, report_code,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, user_id, listing_id, created_at, report_text, action_taken, status, report_code,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, user_id, listing_id, created_at, report_text, action_taken, status, report_code)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        user_id = EXCLUDED.user_id,
        listing_id = EXCLUDED.listing_id,
        created_at = EXCLUDED.created_at,
        report_text = EXCLUDED.report_text,
        action_taken = EXCLUDED.action_taken,
        status = EXCLUDED.status,
        report_code = EXCLUDED.report_code,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.user_report._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.user_report._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'user_report', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_user_report(bigint) IS 'stg_raw → stg_transform.user_report (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/02_seguridad/sp_transform_blocked_contact.sql
-- ======================================================================
-- stg_transform.sp_transform_blocked_contact
-- stg_raw → stg_transform.blocked_contact  ·  Destino final: users_db.blocked_contact
-- Lee: stg_raw.usedcars_blocked + stg_raw.usedcars_blockedemails + stg_raw.usedcars_blockedips + stg_raw.usedcars_blockedphones + stg_raw.usedcars_correosfraude
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_blocked_contact(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

-- Código de error usado por sp_transform_blocked_contact (error_record.rule_code tiene FK a validation_rule)
INSERT INTO stg_control.validation_rule (rule_code, entity, description, severity, is_active)
VALUES ('VAL_PK_MISSING', NULL, 'Llave de origen vacía: la fila no se puede identificar y se excluye', 'ERROR', true)
ON CONFLICT (rule_code) DO NOTHING;

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_blocked_contact(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
    v_err    bigint := 0;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'blocked_contact');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_blocked)
        + (SELECT count(*) FROM stg_raw.usedcars_blockedemails)
        + (SELECT count(*) FROM stg_raw.usedcars_blockedips)
        + (SELECT count(*) FROM stg_raw.usedcars_blockedphones)
        + (SELECT count(*) FROM stg_raw.usedcars_correosfraude)
      INTO v_in;

    -- FIX 13/11/2026: filas con llave de origen vacía → fn_legacy_uuid devuelve NULL e id NULL
    -- hacía fallar la entidad completa (23502). Se excluyen y se registran como VAL_PK_MISSING.
    CREATE TEMP TABLE IF NOT EXISTS tmp_bc_pk_missing (tbl text, col text, payload jsonb) ON COMMIT DROP;
    TRUNCATE tmp_bc_pk_missing;
    INSERT INTO tmp_bc_pk_missing
        SELECT 'blocked', 'blockedid', to_jsonb(r) FROM stg_raw.usedcars_blocked r
         WHERE nullif(trim(r."blockedid"::text), '') IS NULL
        UNION ALL
        SELECT 'blockedemails', 'blockedemail', to_jsonb(r) FROM stg_raw.usedcars_blockedemails r
         WHERE nullif(trim(r."blockedemail"::text), '') IS NULL
        UNION ALL
        SELECT 'blockedips', 'ip', to_jsonb(r) FROM stg_raw.usedcars_blockedips r
         WHERE nullif(trim(r."ip"::text), '') IS NULL
        UNION ALL
        SELECT 'blockedphones', 'blockedphone', to_jsonb(r) FROM stg_raw.usedcars_blockedphones r
         WHERE nullif(trim(r."blockedphone"::text), '') IS NULL
        UNION ALL
        SELECT 'correosfraude', 'codigo', to_jsonb(r) FROM stg_raw.usedcars_correosfraude r
         WHERE nullif(trim(r."codigo"::text), '') IS NULL;
    GET DIAGNOSTICS v_err = ROW_COUNT;

    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'blocked_contact', 'usedcars', m.tbl, NULL,
                                     'VAL_PK_MISSING', 'ERROR',
                                     'Llave de origen vacía (' || m.col || '): fila excluida', m.payload)
      FROM tmp_bc_pk_missing m;


    WITH src AS (
    -- ---- usedcars.blocked
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blocked', r."blockedid"::text)    AS id,
        r."blockedid"::text                                                    AS legacy_id,
        'usedcars.blocked'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."blockedid"::text)                         AS blockedid,
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blocked
        NULL::text                                                             AS ip,  -- no viene de usedcars.blocked
        NULL::text                                                             AS reason,  -- no viene de usedcars.blocked
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blocked
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blocked
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blocked
        'usedcars'::text AS _source_db, 'blocked'::text AS _source_table, r."blockedid"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_blocked r
    WHERE nullif(trim(r."blockedid"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.blockedemails
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedemails', r."blockedemail"::text) AS id,
        r."blockedemail"::text                                                 AS legacy_id,
        'usedcars.blockedemails'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedemails
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        stg_control.fn_clean_email(r."blockedemail")                           AS blockedemail,
        NULL::text                                                             AS ip,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS reason,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedemails
        'usedcars'::text AS _source_db, 'blockedemails'::text AS _source_table, r."blockedemail"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.usedcars_blockedemails r
    WHERE nullif(trim(r."blockedemail"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.blockedips
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedips', r."ip"::text)        AS id,
        r."ip"::text                                                           AS legacy_id,
        'usedcars.blockedips'                                                  AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS blockedname,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blockedips
        stg_control.fn_clean_text(r."ip"::text)                                AS ip,
        stg_control.fn_clean_text(r."reason"::text)                            AS reason,
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedips
        'usedcars'::text AS _source_db, 'blockedips'::text AS _source_table, r."ip"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 3 AS _prio
    FROM stg_raw.usedcars_blockedips r
    WHERE nullif(trim(r."ip"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.blockedphones
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedphones', r."blockedphone"::text) AS id,
        r."blockedphone"::text                                                 AS legacy_id,
        'usedcars.blockedphones'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedphones
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS ip,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS reason,  -- no viene de usedcars.blockedphones
        stg_control.fn_clean_text(r."blockedphone"::text)                      AS blockedphone,
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedphones
        'usedcars'::text AS _source_db, 'blockedphones'::text AS _source_table, r."blockedphone"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 4 AS _prio
    FROM stg_raw.usedcars_blockedphones r
    WHERE nullif(trim(r."blockedphone"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.correosfraude
    SELECT
        stg_control.fn_legacy_uuid('usedcars.correosfraude', r."codigo"::text) AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.correosfraude'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedname,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS ip,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS reason,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.correosfraude
        stg_control.fn_clean_text(r."codigo"::text)                            AS codigo,
        stg_control.fn_clean_email(r."emailaddr")                              AS emailaddr,
        'usedcars'::text AS _source_db, 'correosfraude'::text AS _source_table, r."codigo"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 5 AS _prio
    FROM stg_raw.usedcars_correosfraude r
    WHERE nullif(trim(r."codigo"::text), '') IS NOT NULL
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.blocked_contact (id, legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        blockedid = EXCLUDED.blockedid,
        blockedname = EXCLUDED.blockedname,
        blockedemail = EXCLUDED.blockedemail,
        ip = EXCLUDED.ip,
        reason = EXCLUDED.reason,
        blockedphone = EXCLUDED.blockedphone,
        codigo = EXCLUDED.codigo,
        emailaddr = EXCLUDED.emailaddr,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.blocked_contact._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.blocked_contact._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, v_err, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'blocked_contact', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_blocked_contact(bigint) IS 'stg_raw → stg_transform.blocked_contact (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/02_seguridad/sp_transform_ip_allowlist.sql
-- ======================================================================
-- stg_transform.sp_transform_ip_allowlist
-- stg_raw → stg_transform.ip_allowlist  ·  Destino final: users_db.ip_allowlist
-- Lee: stg_raw.usedcars_ipsaccepted
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_ip_allowlist(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_ip_allowlist(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'ip_allowlist');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_ipsaccepted)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.ipsaccepted
    SELECT
        stg_control.fn_legacy_uuid('usedcars.ipsaccepted', r."aip"::text)      AS id,
        r."aip"::text                                                          AS legacy_id,
        'usedcars.ipsaccepted'                                                 AS legacy_source,
        stg_control.fn_clean_text(r."aip"::text)                               AS aip,
        stg_control.fn_clean_text(r."alocation"::text)                         AS alocation,
        stg_control.fn_clean_text(r."actry"::text)                             AS actry,
        'usedcars'::text AS _source_db, 'ipsaccepted'::text AS _source_table, r."aip"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_ipsaccepted r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.ip_allowlist (id, legacy_id, legacy_source, aip, alocation, actry,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, aip, alocation, actry,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, aip, alocation, actry)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        aip = EXCLUDED.aip,
        alocation = EXCLUDED.alocation,
        actry = EXCLUDED.actry,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.ip_allowlist._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.ip_allowlist._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'ip_allowlist', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_ip_allowlist(bigint) IS 'stg_raw → stg_transform.ip_allowlist (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/02_seguridad/sp_transform_system_parameter.sql
-- ======================================================================
-- stg_transform.sp_transform_system_parameter
-- stg_raw → stg_transform.system_parameter  ·  Destino final: users_db.system_parameter
-- Lee: stg_raw.usedcars_parameters
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_system_parameter(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_system_parameter(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'system_parameter');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_parameters)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.parameters
    SELECT
        stg_control.fn_legacy_uuid('usedcars.parameters', r."parname"::text)   AS id,
        r."parname"::text                                                      AS legacy_id,
        'usedcars.parameters'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."parname"::text)                           AS parname,
        stg_control.fn_clean_text(r."parvalue1"::text)                         AS parvalue1,
        r."parvalue2"::numeric(10,2)                                           AS parvalue2,
        'usedcars'::text AS _source_db, 'parameters'::text AS _source_table, r."parname"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_parameters r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.system_parameter (id, legacy_id, legacy_source, parname, parvalue1, parvalue2,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, parname, parvalue1, parvalue2,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, parname, parvalue1, parvalue2)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        parname = EXCLUDED.parname,
        parvalue1 = EXCLUDED.parvalue1,
        parvalue2 = EXCLUDED.parvalue2,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.system_parameter._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.system_parameter._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'system_parameter', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_system_parameter(bigint) IS 'stg_raw → stg_transform.system_parameter (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_payment.sql
-- ======================================================================
-- stg_transform.sp_transform_payment
-- stg_raw → stg_transform.payment  ·  Destino final: payments_db.payment
-- Lee: stg_raw.usedcars_charges + stg_raw.accesorios_charges
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_payment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_payment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'payment');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_charges)
        + (SELECT count(*) FROM stg_raw.accesorios_charges)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.charges
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.charges', concat_ws('|', r."codigo", r."datein", r."tdinvoicenum")) AS id,
        concat_ws('|', r."codigo", r."datein", r."tdinvoicenum")               AS legacy_id,
        'usedcars.charges'                                                     AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_map_code('PAYMENT_SOURCE', 'usedcars', r."source"::text) AS channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS paid_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_map_code('PAYMENT_FEATURE', 'usedcars', r."feature"::text) AS service_code,
        stg_control.fn_clean_text(r."cname"::text)                             AS cardholder_name,
        stg_control.fn_map_code('CARD_BRAND', 'usedcars', r."ctype"::text)     AS card_brand,
        stg_control.fn_clean_text(r."clast4"::text)::char(4)                   AS card_last4,
        stg_control.fn_clean_text(r."approval"::text)                          AS authorization_code,
        to_jsonb(r."tdresponse")                                               AS gateway_response,  -- POR CONFIRMAR · TODO: evaluar jsonb vs archivo en S3
        stg_control.fn_clean_text(r."tdname"::text)                            AS invoice_name,
        stg_control.fn_clean_email(r."tdemail")                                AS invoice_email,
        stg_control.fn_map_code('ID_TYPE', 'usedcars', r."tdidtype"::text)     AS invoice_id_type,
        stg_control.fn_clean_text(r."tdidnum"::text)                           AS invoice_id_number,
        r."tdclave"::text                                                      AS einvoice_key,
        stg_control.fn_clean_text(r."tdmsg"::text)                             AS einvoice_message,
        stg_control.fn_map_code('EINVOICE_STATUS', 'usedcars', r."tdstatus"::text) AS einvoice_status,
        r."tdinvoicenum"::text                                                 AS invoice_number,
        to_jsonb(r."json")                                                     AS gateway_payload,  -- POR CONFIRMAR · TODO: evaluar jsonb vs archivo en S3
        'usedcars'::text AS _source_db, 'charges'::text AS _source_table, concat_ws('|', r."codigo", r."datein", r."tdinvoicenum") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_charges r
    UNION ALL
    -- ---- accesorios.charges  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('accesorios.charges', md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval"))) AS id,
        md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval")) AS legacy_id,
        'accesorios.charges'                                                   AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_map_code('PAYMENT_SOURCE', 'accesorios', r."source"::text) AS channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS paid_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_map_code('PAYMENT_FEATURE', 'accesorios', r."feature"::text) AS service_code,
        stg_control.fn_clean_text(r."cname"::text)                             AS cardholder_name,
        stg_control.fn_map_code('CARD_BRAND', 'accesorios', r."ctype"::text)   AS card_brand,
        stg_control.fn_clean_text(r."clast4"::text)::char(4)                   AS card_last4,
        stg_control.fn_clean_text(r."approval"::text)                          AS authorization_code,
        NULL::jsonb                                                            AS gateway_response,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_name,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_email,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_id_type,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_id_number,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_key,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_message,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_status,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_number,  -- no viene de accesorios.charges
        NULL::jsonb                                                            AS gateway_payload,  -- no viene de accesorios.charges
        'accesorios'::text AS _source_db, 'charges'::text AS _source_table, md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval")) AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.accesorios_charges r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.payment (id, legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        listing_title_snapshot = EXCLUDED.listing_title_snapshot,
        channel = EXCLUDED.channel,
        paid_at = EXCLUDED.paid_at,
        amount = EXCLUDED.amount,
        service_code = EXCLUDED.service_code,
        cardholder_name = EXCLUDED.cardholder_name,
        card_brand = EXCLUDED.card_brand,
        card_last4 = EXCLUDED.card_last4,
        authorization_code = EXCLUDED.authorization_code,
        gateway_response = EXCLUDED.gateway_response,
        invoice_name = EXCLUDED.invoice_name,
        invoice_email = EXCLUDED.invoice_email,
        invoice_id_type = EXCLUDED.invoice_id_type,
        invoice_id_number = EXCLUDED.invoice_id_number,
        einvoice_key = EXCLUDED.einvoice_key,
        einvoice_message = EXCLUDED.einvoice_message,
        einvoice_status = EXCLUDED.einvoice_status,
        invoice_number = EXCLUDED.invoice_number,
        gateway_payload = EXCLUDED.gateway_payload,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.payment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.payment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'payment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_payment(bigint) IS 'stg_raw → stg_transform.payment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_payment_log.sql
-- ======================================================================
-- stg_transform.sp_transform_payment_log
-- stg_raw → stg_transform.payment_log  ·  Destino final: payments_db.payment_log
-- Lee: stg_raw.usedcars_chargeslog
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_payment_log(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_payment_log(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'payment_log');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_chargeslog)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.chargeslog  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.chargeslog', md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime"))) AS id,
        md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime")) AS legacy_id,
        'usedcars.chargeslog'                                                  AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_to_timestamptz(r."datein")                              AS attempted_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_clean_text(r."fullorder"::text)                         AS order_reference,
        stg_control.fn_clean_text(r."response"::text)                          AS gateway_response_code,
        stg_control.fn_clean_text(r."avsresponse"::text)                       AS avs_result,
        stg_control.fn_clean_text(r."cvvresponse"::text)                       AS cvv_result,
        stg_control.fn_clean_text(r."responsetime"::text)                      AS response_time,
        'usedcars'::text AS _source_db, 'chargeslog'::text AS _source_table, md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime")) AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_chargeslog r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.payment_log (id, legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        listing_title_snapshot = EXCLUDED.listing_title_snapshot,
        attempted_at = EXCLUDED.attempted_at,
        amount = EXCLUDED.amount,
        order_reference = EXCLUDED.order_reference,
        gateway_response_code = EXCLUDED.gateway_response_code,
        avs_result = EXCLUDED.avs_result,
        cvv_result = EXCLUDED.cvv_result,
        response_time = EXCLUDED.response_time,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.payment_log._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.payment_log._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'payment_log', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_payment_log(bigint) IS 'stg_raw → stg_transform.payment_log (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_prepayment.sql
-- ======================================================================
-- stg_transform.sp_transform_prepayment
-- stg_raw → stg_transform.prepayment  ·  Destino final: payments_db.prepayment
-- Lee: stg_raw.usedcars_prepay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_prepayment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_prepayment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'prepayment');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_prepay)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.prepay
    -- No se migran: ppip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.prepay', concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal")) AS id,
        concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal")                 AS legacy_id,
        'usedcars.prepay'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."ppuser"::text)                            AS performed_by,
        stg_control.fn_legacy_uuid('usedcars.sellers', r."ppseller"::text) /* TODO: confirmar que sellers.sellercode es la PK del padre */ AS seller_id,
        stg_control.fn_map_code('PREPAY_TYPE', 'usedcars', r."ppttype"::text)  AS movement_type,
        stg_control.fn_to_timestamptz(r."ppdate")                              AS movement_at,
        r."ppamount"::numeric(12,2)                                            AS amount,
        stg_control.fn_clean_text(r."ppdetail"::text)                          AS detail,
        stg_control.fn_clean_text(r."ppcomment"::text)                         AS comment,
        r."ppprevbal"::numeric(12,2)                                           AS previous_balance,
        r."ppnewbal"::numeric(12,2)                                            AS new_balance,
        'usedcars'::text AS _source_db, 'prepay'::text AS _source_table, concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_prepay r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.prepayment (id, legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        performed_by = EXCLUDED.performed_by,
        seller_id = EXCLUDED.seller_id,
        movement_type = EXCLUDED.movement_type,
        movement_at = EXCLUDED.movement_at,
        amount = EXCLUDED.amount,
        detail = EXCLUDED.detail,
        comment = EXCLUDED.comment,
        previous_balance = EXCLUDED.previous_balance,
        new_balance = EXCLUDED.new_balance,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.prepayment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.prepayment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'prepayment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_prepayment(bigint) IS 'stg_raw → stg_transform.prepayment (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_coupon.sql
-- ======================================================================
-- stg_transform.sp_transform_coupon
-- stg_raw → stg_transform.coupon  ·  Destino final: payments_db.coupon
-- Lee: stg_raw.usedcars_coupons + stg_raw.accesorios_coupons
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_coupon(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_coupon(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'coupon');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_coupons)
        + (SELECT count(*) FROM stg_raw.accesorios_coupons)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.coupons
    SELECT
        stg_control.fn_legacy_uuid('usedcars.coupons', r."ccoupon"::text)      AS id,
        r."ccoupon"::text                                                      AS legacy_id,
        'usedcars.coupons'                                                     AS legacy_source,
        upper(stg_control.fn_clean_text(r."ccoupon"))                          AS code,
        stg_control.fn_to_date(r."cactivedate")                                AS valid_from,
        stg_control.fn_to_date(r."cexpdate")                                   AS valid_to,
        stg_control.fn_to_date(r."cdateused")                                  AS used_at,
        stg_control.fn_legacy_uuid('listing', r."cadcode"::text)               AS listing_id,
        stg_control.fn_map_code('COUPON_TYPE', 'usedcars', r."ctype"::text)    AS coupon_type,
        stg_control.fn_clean_text(r."creference"::text)                        AS reference,
        'usedcars'::text AS _source_db, 'coupons'::text AS _source_table, r."ccoupon"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_coupons r
    UNION ALL
    -- ---- accesorios.coupons
    SELECT
        stg_control.fn_legacy_uuid('accesorios.coupons', r."ccoupon"::text)    AS id,
        r."ccoupon"::text                                                      AS legacy_id,
        'accesorios.coupons'                                                   AS legacy_source,
        upper(stg_control.fn_clean_text(r."ccoupon"))                          AS code,
        stg_control.fn_to_date(r."cactivedate")                                AS valid_from,
        stg_control.fn_to_date(r."cexpdate")                                   AS valid_to,
        stg_control.fn_to_date(r."cdateused")                                  AS used_at,
        stg_control.fn_legacy_uuid('listing', r."cadcode"::text)               AS listing_id,
        stg_control.fn_map_code('COUPON_TYPE', 'accesorios', r."ctype"::text)  AS coupon_type,
        stg_control.fn_clean_text(r."creference"::text)                        AS reference,
        'accesorios'::text AS _source_db, 'coupons'::text AS _source_table, r."ccoupon"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.accesorios_coupons r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.coupon (id, legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        code = EXCLUDED.code,
        valid_from = EXCLUDED.valid_from,
        valid_to = EXCLUDED.valid_to,
        used_at = EXCLUDED.used_at,
        listing_id = EXCLUDED.listing_id,
        coupon_type = EXCLUDED.coupon_type,
        reference = EXCLUDED.reference,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.coupon._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.coupon._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'coupon', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_coupon(bigint) IS 'stg_raw → stg_transform.coupon (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_auto_renewal.sql
-- ======================================================================
-- stg_transform.sp_transform_auto_renewal
-- stg_raw → stg_transform.auto_renewal  ·  Destino final: payments_db.auto_renewal
-- Lee: stg_raw.usedcars_autorenewhl
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_auto_renewal(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_auto_renewal(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'auto_renewal');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_autorenewhl)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.autorenewhl
    SELECT
        stg_control.fn_legacy_uuid('usedcars.autorenewhl', concat_ws('|', r."datein", r."renewdate")) AS id,
        concat_ws('|', r."datein", r."renewdate")                              AS legacy_id,
        'usedcars.autorenewhl'                                                 AS legacy_source,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."renewdate")                           AS renew_at,
        stg_control.fn_legacy_uuid('listing', r."adcode"::text)                AS listing_id,
        stg_control.fn_to_timestamptz(r."rstatus")                             AS last_run_at,
        'usedcars'::text AS _source_db, 'autorenewhl'::text AS _source_table, concat_ws('|', r."datein", r."renewdate") AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_autorenewhl r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.auto_renewal (id, legacy_id, legacy_source, created_at, renew_at, listing_id, last_run_at,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, created_at, renew_at, listing_id, last_run_at,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, created_at, renew_at, listing_id, last_run_at)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        created_at = EXCLUDED.created_at,
        renew_at = EXCLUDED.renew_at,
        listing_id = EXCLUDED.listing_id,
        last_run_at = EXCLUDED.last_run_at,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.auto_renewal._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.auto_renewal._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'auto_renewal', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_auto_renewal(bigint) IS 'stg_raw → stg_transform.auto_renewal (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/06_pagos/sp_transform_einvoice_document.sql
-- ======================================================================
-- stg_transform.sp_transform_einvoice_document
-- stg_raw → stg_transform.einvoice_document  ·  Destino final: payments_db.einvoice_document
-- Lee: stg_raw.usedcars_tdtickets + stg_raw.usedcars_mttdtickets + stg_raw.usedcars_tdinvoices
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_einvoice_document(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_einvoice_document(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'einvoice_document');
  BEGIN

    SELECT (SELECT count(*) FROM stg_raw.usedcars_tdtickets)
        + (SELECT count(*) FROM stg_raw.usedcars_mttdtickets)
        + (SELECT count(*) FROM stg_raw.usedcars_tdinvoices)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.tdtickets
    SELECT
        stg_control.fn_legacy_uuid('usedcars.tdtickets', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.tdtickets'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'tdtickets'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 1 AS _prio
    FROM stg_raw.usedcars_tdtickets r
    UNION ALL
    -- ---- usedcars.mttdtickets
    SELECT
        stg_control.fn_legacy_uuid('usedcars.mttdtickets', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.mttdtickets'                                                 AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'mttdtickets'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 2 AS _prio
    FROM stg_raw.usedcars_mttdtickets r
    UNION ALL
    -- ---- usedcars.tdinvoices
    SELECT
        stg_control.fn_legacy_uuid('usedcars.tdinvoices', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.tdinvoices'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'tdinvoices'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        NULL::text AS _dms_op, NULL::timestamptz AS _dms_ts, 3 AS _prio
    FROM stg_raw.usedcars_tdinvoices r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.einvoice_document (id, legacy_id, legacy_source, document_number, einvoice_key,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, document_number, einvoice_key,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, document_number, einvoice_key)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        document_number = EXCLUDED.document_number,
        einvoice_key = EXCLUDED.einvoice_key,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.einvoice_document._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.einvoice_document._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

  EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'einvoice_document', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
  END;
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_einvoice_document(bigint) IS 'stg_raw → stg_transform.einvoice_document (esqueleto v1 desde S2T)';


-- ===== 50_sp_transform/00_sp_transform_all.sql
-- ======================================================================
-- stg_transform.sp_transform_all · Orquestador stg_raw → stg_transform
-- Orden: catálogos → usuarios → publicaciones → relaciones de usuario → seguridad → pagos.
-- Como los UUID son determinísticos, el orden no es obligatorio para transformar;
-- sí lo es para sp_validate (FK contra la entidad padre ya transformada).
-- COMMIT por entidad: si una falla, queda FAILED en step_log y se sigue con la siguiente.
-- Uso (fuera de un bloque de transacción):  CALL stg_transform.sp_transform_all(NULL);
-- -- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_all(p_run_id bigint DEFAULT NULL, p_run_type text DEFAULT 'FULL')
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_run_id IS NULL THEN
        INSERT INTO stg_control.migration_run (run_type, status, triggered_by)
        VALUES (p_run_type, 'RUNNING', current_user)
        RETURNING run_id INTO p_run_id;
        COMMIT;
    END IF;

    CALL stg_transform.sp_transform_brand(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_body_style(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_province(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_equipment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_accessory_section(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_model(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_app_user(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_seller(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_dealer(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_dealer_contact(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_admin_user(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_transfer(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_image(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_equipment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_special_deal(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_banner(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_accessory_listing(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_favorite(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_friend(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_request(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_suggestion(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_report(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_blocked_contact(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_ip_allowlist(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_system_parameter(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_payment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_payment_log(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_prepayment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_coupon(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_auto_renewal(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_einvoice_document(p_run_id);  COMMIT;

    UPDATE stg_control.migration_run
       SET status = CASE WHEN EXISTS (SELECT 1 FROM stg_control.step_log
                                       WHERE run_id = p_run_id AND step_name = 'sp_transform' AND status = 'FAILED')
                         THEN 'FAILED' ELSE 'SUCCESS' END,
           finished_at = now()
     WHERE run_id = p_run_id;
    COMMIT;
    RAISE NOTICE 'sp_transform_all terminado · run_id = %', p_run_id;
END;
$$;

