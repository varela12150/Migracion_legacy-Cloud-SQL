-- ======================================================================
-- stg_control.reconciliation
-- Grano: 1 fila por entidad y ejecución
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.reconciliation (
    recon_id             bigserial NOT NULL,
    run_id               bigint NOT NULL,
    entity               text,
    source_count         bigint,
    target_count         bigint,
    error_count          bigint,
    excluded_count       bigint,
    source_checksum      text,
    target_checksum      text,
    is_match             boolean,
    checked_at           timestamptz DEFAULT now(),
    CONSTRAINT pk_reconciliation PRIMARY KEY (recon_id),
    CONSTRAINT fk_reconciliation_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.reconciliation IS '1 fila por entidad y ejecución';
CREATE INDEX IF NOT EXISTS ix_reconciliation_run_id ON stg_control.reconciliation (run_id);
