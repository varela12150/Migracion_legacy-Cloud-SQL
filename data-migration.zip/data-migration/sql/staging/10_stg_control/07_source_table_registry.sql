-- ======================================================================
-- stg_control.source_table_registry
-- Grano: 1 fila por objeto del origen (soporta CA-02)
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.source_table_registry (
    source_db            text NOT NULL,
    source_table         text NOT NULL,
    scope_status         text NOT NULL,                       -- MAPEADA / PENDIENTE DE MAPEO / FUERA DE ALCANCE
    stg_raw_table        text,
    target_entity        text,
    load_type            text,                                -- FULL / FULL+CDC / N/A
    reason               text,
    approved_by          text,                                -- Arquitectura
    approved_at          date,
    CONSTRAINT pk_source_table_registry PRIMARY KEY (source_db, source_table)
);

COMMENT ON TABLE stg_control.source_table_registry IS '1 fila por objeto del origen (soporta CA-02)';
COMMENT ON COLUMN stg_control.source_table_registry.scope_status IS 'MAPEADA / PENDIENTE DE MAPEO / FUERA DE ALCANCE';
COMMENT ON COLUMN stg_control.source_table_registry.load_type IS 'FULL / FULL+CDC / N/A';
COMMENT ON COLUMN stg_control.source_table_registry.approved_by IS 'Arquitectura';
