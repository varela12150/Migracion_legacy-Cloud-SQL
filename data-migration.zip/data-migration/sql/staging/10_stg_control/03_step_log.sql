-- ======================================================================
-- stg_control.step_log
-- Grano: 1 fila por paso y entidad dentro de una ejecución
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.step_log (
    step_id              bigserial NOT NULL,
    run_id               bigint NOT NULL,
    step_name            text NOT NULL,                       -- sp_transform / sp_validate / sp_publish / sp_reconcile
    entity               text,                                -- app_user, listing, payment…
    rows_in              bigint,
    rows_ok              bigint,
    rows_error           bigint,
    rows_warning         bigint,
    started_at           timestamptz DEFAULT now(),
    finished_at          timestamptz,
    status               text NOT NULL,
    message              text,
    CONSTRAINT pk_step_log PRIMARY KEY (step_id),
    CONSTRAINT fk_step_log_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.step_log IS '1 fila por paso y entidad dentro de una ejecución';
COMMENT ON COLUMN stg_control.step_log.step_name IS 'sp_transform / sp_validate / sp_publish / sp_reconcile';
COMMENT ON COLUMN stg_control.step_log.entity IS 'app_user, listing, payment…';
CREATE INDEX IF NOT EXISTS ix_step_log_run_id ON stg_control.step_log (run_id);
