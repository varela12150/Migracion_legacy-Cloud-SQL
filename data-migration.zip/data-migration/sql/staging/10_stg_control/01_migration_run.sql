-- ======================================================================
-- stg_control.migration_run
-- Grano: 1 fila por ejecución del pipeline
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.migration_run (
    run_id               bigserial NOT NULL,
    run_type             text NOT NULL,                       -- FULL / CDC / TEST / REPROCESS
    status               text NOT NULL,                       -- RUNNING / SUCCESS / FAILED
    parent_run_id        bigint,                              -- run original cuando es reproceso
    started_at           timestamptz DEFAULT now(),
    finished_at          timestamptz,
    triggered_by         text,                                -- step_functions / manual
    sfn_execution_arn    text,                                -- trazabilidad con Step Functions
    CONSTRAINT pk_migration_run PRIMARY KEY (run_id),
    CONSTRAINT fk_migration_run_parent_run_id FOREIGN KEY (parent_run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.migration_run IS '1 fila por ejecución del pipeline';
COMMENT ON COLUMN stg_control.migration_run.run_type IS 'FULL / CDC / TEST / REPROCESS';
COMMENT ON COLUMN stg_control.migration_run.status IS 'RUNNING / SUCCESS / FAILED';
COMMENT ON COLUMN stg_control.migration_run.parent_run_id IS 'run original cuando es reproceso';
COMMENT ON COLUMN stg_control.migration_run.triggered_by IS 'step_functions / manual';
COMMENT ON COLUMN stg_control.migration_run.sfn_execution_arn IS 'trazabilidad con Step Functions';
CREATE INDEX IF NOT EXISTS ix_migration_run_parent_run_id ON stg_control.migration_run (parent_run_id);
