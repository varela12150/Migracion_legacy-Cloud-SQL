-- ======================================================================
-- stg_control.validation_rule
-- Grano: 1 fila por regla de validación
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.validation_rule (
    rule_code            text NOT NULL,                       -- p. ej. VAL_FK_USER, VAL_EMAIL_FMT
    entity               text,
    description          text,
    severity             text NOT NULL,                       -- ERROR / WARNING
    is_active            boolean NOT NULL DEFAULT true,
    CONSTRAINT pk_validation_rule PRIMARY KEY (rule_code)
);

COMMENT ON TABLE stg_control.validation_rule IS '1 fila por regla de validación';
COMMENT ON COLUMN stg_control.validation_rule.rule_code IS 'p. ej. VAL_FK_USER, VAL_EMAIL_FMT';
COMMENT ON COLUMN stg_control.validation_rule.severity IS 'ERROR / WARNING';
