-- ======================================================================
-- stg_control.watermark
-- Grano: 1 fila por tabla origen con CDC
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.watermark (
    source_db            text NOT NULL,
    source_table         text NOT NULL,
    last_processed_at    timestamptz,                         -- último cambio CDC procesado
    last_run_id          bigint,
    CONSTRAINT pk_watermark PRIMARY KEY (source_db, source_table),
    CONSTRAINT fk_watermark_last_run_id FOREIGN KEY (last_run_id) REFERENCES stg_control.migration_run (run_id)
);

COMMENT ON TABLE stg_control.watermark IS '1 fila por tabla origen con CDC';
COMMENT ON COLUMN stg_control.watermark.last_processed_at IS 'último cambio CDC procesado';
CREATE INDEX IF NOT EXISTS ix_watermark_last_run_id ON stg_control.watermark (last_run_id);
