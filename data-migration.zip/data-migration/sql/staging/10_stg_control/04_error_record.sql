-- ======================================================================
-- stg_control.error_record
-- Grano: 1 fila por registro rechazado o con advertencia
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.error_record (
    error_id             bigserial NOT NULL,
    run_id               bigint,
    step_name            text,
    entity               text,
    source_db            text,
    source_table         text,
    source_pk            text,
    rule_code            text,
    severity             text,                                -- ERROR = no publica · WARNING = publica
    detail               text,
    payload              jsonb,                               -- registro completo para análisis
    is_resolved          boolean NOT NULL DEFAULT false,      -- para reprocesos
    created_at           timestamptz DEFAULT now(),
    CONSTRAINT pk_error_record PRIMARY KEY (error_id),
    CONSTRAINT fk_error_record_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id),
    CONSTRAINT fk_error_record_rule_code FOREIGN KEY (rule_code) REFERENCES stg_control.validation_rule (rule_code)
);

COMMENT ON TABLE stg_control.error_record IS '1 fila por registro rechazado o con advertencia';
COMMENT ON COLUMN stg_control.error_record.severity IS 'ERROR = no publica · WARNING = publica';
COMMENT ON COLUMN stg_control.error_record.payload IS 'registro completo para análisis';
COMMENT ON COLUMN stg_control.error_record.is_resolved IS 'para reprocesos';
CREATE INDEX IF NOT EXISTS ix_error_record_run_id ON stg_control.error_record (run_id);
CREATE INDEX IF NOT EXISTS ix_error_record_rule_code ON stg_control.error_record (rule_code);
CREATE INDEX IF NOT EXISTS ix_error_record_entity ON stg_control.error_record (entity, severity);
