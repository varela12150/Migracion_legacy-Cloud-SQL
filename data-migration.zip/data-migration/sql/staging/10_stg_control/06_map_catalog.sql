-- ======================================================================
-- stg_control.map_catalog
-- Grano: 1 fila por valor origen a homologar
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE TABLE IF NOT EXISTS stg_control.map_catalog (
    catalog_type         text NOT NULL,                       -- BRAND / STYLE / PROVINCE / LISTING_STATUS / PAYMENT_STATUS…
    source_db            text NOT NULL,
    source_value         text NOT NULL,
    target_id            uuid,                                -- id en la entidad de catálogo destino
    target_code          text,
    target_label         text,
    approved_by          text,                                -- negocio
    CONSTRAINT pk_map_catalog PRIMARY KEY (catalog_type, source_db, source_value)
);

COMMENT ON TABLE stg_control.map_catalog IS '1 fila por valor origen a homologar';
COMMENT ON COLUMN stg_control.map_catalog.catalog_type IS 'BRAND / STYLE / PROVINCE / LISTING_STATUS / PAYMENT_STATUS…';
COMMENT ON COLUMN stg_control.map_catalog.target_id IS 'id en la entidad de catálogo destino';
COMMENT ON COLUMN stg_control.map_catalog.approved_by IS 'negocio';
