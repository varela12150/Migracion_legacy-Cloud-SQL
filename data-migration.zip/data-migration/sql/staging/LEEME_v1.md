# Staging CRAutos · v1 (23/10/2026)

DDL del staging alineado con la clasificación v1 (T15) y las matrices S2T v1 (T16–T18). Incluye los esqueletos de `sp_transform` que pasan los datos de `stg_raw` a `stg_transform` cuando DMS termine de cargar.

## Cómo ejecutar

```
psql -d crautos_db -f 00_ejecutar_todo.sql      -- esquemas, control, transform, validated y procedimientos
CALL stg_transform.sp_transform_all(NULL);       -- cuando stg_raw tenga datos (crea un run_id)
```

Se probó en PostgreSQL 16: se crearon las 47 tablas `stg_raw` con los tipos de Q01, se corrió el script maestro sin errores y se ejecutó `sp_transform_all` con datos de muestra, dos veces. La segunda corrida no duplicó ni actualizó filas.

## Qué cambió frente a v0

| Área | v0 (15/10) | v1 (23/10) |
| --- | --- | --- |
| Columnas de negocio | `-- TODO` en todas las tablas | Columnas y tipos tomados de la S2T, con la regla de la S2T como comentario en cada columna |
| Entidades | 37, con service_plan, listing_video, listing_pending, pending_payment, gateway_ticket e invoice | 32: salen esas 6; entran dealer_contact y einvoice_document |
| listing | 2 tablas de origen | 5 tablas del ciclo de vida + `publication_lifecycle` |
| stg_raw | 53 tablas | 47 tablas: salen bacge.*, financing.*, services y videos (ahora PENDIENTE) |
| Transformación | No existía | `50_sp_transform/`: un procedimiento por entidad + orquestador |
| Funciones comunes | No existían | `10_stg_control/09_funciones_comunes.sql` |

## Cómo funcionan los `sp_transform`

- **UUID determinístico.** `fn_legacy_uuid('bd.tabla', pk)` devuelve el mismo UUID en cada corrida, así que las FK se calculan sin buscar en la tabla padre. Por ejemplo, `payment.listing_id = fn_legacy_uuid('listing', codigo)`.
- **Idempotente.** Cada procedimiento hace `INSERT … ON CONFLICT (id) DO UPDATE` y solo actualiza cuando cambia `_row_hash`. Una fila con `_dms_op = 'D'` de CDC queda como `_is_deleted = true`.
- **No pierde datos.** Un valor sin homologar queda como `UNMAPPED:<valor>`, y una fecha inválida queda en `NULL` para que `sp_validate` la reporte como WARNING.
- **Pivots.** `listing_equipment` (columnas f1–f40), `listing_image` (fotos) y `dealer_contact` (pares dphoneN/dphonerefN) generan N filas por cada fila de origen.
- **Bitácora.** Cada procedimiento escribe en `step_log`, y si falla también en `error_record`. El orquestador hace COMMIT por entidad, así que una falla no detiene las demás.

## Pendientes marcados en el código

- `TODO Q07`: la lógica de presencia de equipamiento y el cruce f<N> ↔ `carextras` (`fn_equipment_present`).
- `POR CONFIRMAR`: 121 columnas que la S2T marca así. Se cargan con la regla propuesta y se revisan en la T19.
- `fn_to_timestamptz`: confirmar los formatos de fecha reales; el parámetro `DATE_FORMATS` está en `stg_control.migration_parameter`.
- `fn_image_s3_key`: confirmar la convención de llaves de S3.
- `map_catalog`: falta cargar los valores homologados (Q05/Q06 + T19). Mientras no estén, los valores salen como `UNMAPPED:`.
- Siguiente paso: `sp_validate`, `sp_publish` y `sp_reconcile` (DATA-04/05).

## Archivos obsoletos

Los 12 archivos de las 6 entidades retiradas (en 20_stg_transform y 30_stg_validated) quedaron con un encabezado "OBSOLETO" y ya no se ejecutan. Se pueden borrar. `DDL_staging_v0.sql` se conserva como historial.
