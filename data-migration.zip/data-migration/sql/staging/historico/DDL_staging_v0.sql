-- =====================================================================
-- DATA-02 · Modelo de staging v0 · crautos_db (Aurora PostgreSQL 17.7)
-- Generado a partir del diseño. Columnas de negocio de stg_transform/stg_validated:
-- se completan con la matriz S2T (DATA-03).
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS stg_raw;
CREATE SCHEMA IF NOT EXISTS stg_transform;
CREATE SCHEMA IF NOT EXISTS stg_validated;
CREATE SCHEMA IF NOT EXISTS stg_control;

-- ---------------------------------------------------------------- stg_control
-- 1 fila por ejecución del pipeline
CREATE TABLE IF NOT EXISTS stg_control.migration_run (
  run_id bigserial,
  run_type text,  -- FULL / CDC / TEST / REPROCESS
  status text,  -- RUNNING / SUCCESS / FAILED
  parent_run_id bigint,  -- run original cuando es reproceso
  started_at timestamptz DEFAULT now(),
  finished_at timestamptz,
  triggered_by text,  -- step_functions / manual
  sfn_execution_arn text,  -- trazabilidad con Step Functions
  CONSTRAINT pk_migration_run PRIMARY KEY (run_id),
  CONSTRAINT fk_migration_run_parent_run_id FOREIGN KEY (parent_run_id) REFERENCES stg_control.migration_run (run_id)
);

-- 1 fila por regla de validación
CREATE TABLE IF NOT EXISTS stg_control.validation_rule (
  rule_code text,  -- p. ej. VAL_FK_USER, VAL_EMAIL_FMT
  entity text,
  description text,
  severity text,  -- ERROR / WARNING
  is_active boolean,
  CONSTRAINT pk_validation_rule PRIMARY KEY (rule_code)
);

-- 1 fila por paso y entidad dentro de una ejecución
CREATE TABLE IF NOT EXISTS stg_control.step_log (
  step_id bigserial,
  run_id bigint,
  step_name text,  -- sp_transform / sp_validate / sp_publish / sp_reconcile
  entity text,  -- app_user, listing, payment…
  rows_in bigint,
  rows_ok bigint,
  rows_error bigint,
  rows_warning bigint,
  started_at timestamptz DEFAULT now(),
  finished_at timestamptz,
  status text,
  message text,
  CONSTRAINT pk_step_log PRIMARY KEY (step_id),
  CONSTRAINT fk_step_log_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

-- 1 fila por registro rechazado o con advertencia
CREATE TABLE IF NOT EXISTS stg_control.error_record (
  error_id bigserial,
  run_id bigint,
  step_name text,
  entity text,
  source_db text,
  source_table text,
  source_pk text,
  rule_code text,
  severity text,  -- ERROR = no publica · WARNING = publica
  detail text,
  payload jsonb,  -- registro completo para análisis
  is_resolved boolean,  -- para reprocesos
  created_at timestamptz DEFAULT now(),
  CONSTRAINT pk_error_record PRIMARY KEY (error_id),
  CONSTRAINT fk_error_record_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id),
  CONSTRAINT fk_error_record_rule_code FOREIGN KEY (rule_code) REFERENCES stg_control.validation_rule (rule_code)
);

-- 1 fila por entidad y ejecución
CREATE TABLE IF NOT EXISTS stg_control.reconciliation (
  recon_id bigserial,
  run_id bigint,
  entity text,
  source_count bigint,
  target_count bigint,
  error_count bigint,
  excluded_count bigint,
  source_checksum text,
  target_checksum text,
  is_match boolean,
  checked_at timestamptz DEFAULT now(),
  CONSTRAINT pk_reconciliation PRIMARY KEY (recon_id),
  CONSTRAINT fk_reconciliation_run_id FOREIGN KEY (run_id) REFERENCES stg_control.migration_run (run_id)
);

-- 1 fila por valor origen a homologar
CREATE TABLE IF NOT EXISTS stg_control.map_catalog (
  catalog_type text,  -- BRAND / STYLE / PROVINCE / LISTING_STATUS / PAYMENT_STATUS…
  source_db text,
  source_value text,
  target_id uuid,  -- id en la entidad de catálogo destino
  target_code text,
  target_label text,
  approved_by text,  -- negocio
  CONSTRAINT pk_map_catalog PRIMARY KEY (catalog_type, source_db, source_value)
);

-- 1 fila por objeto del origen (soporta CA-02)
CREATE TABLE IF NOT EXISTS stg_control.source_table_registry (
  source_db text,
  source_table text,
  scope_status text,  -- MAPEADA / PENDIENTE DE MAPEO / FUERA DE ALCANCE
  stg_raw_table text,
  target_entity text,
  load_type text,  -- FULL / FULL+CDC / N/A
  reason text,
  approved_by text,  -- Arquitectura
  approved_at date,
  CONSTRAINT pk_source_table_registry PRIMARY KEY (source_db, source_table)
);

-- 1 fila por tabla origen con CDC
CREATE TABLE IF NOT EXISTS stg_control.watermark (
  source_db text,
  source_table text,
  last_processed_at timestamptz,  -- último cambio CDC procesado
  last_run_id bigint,
  CONSTRAINT pk_watermark PRIMARY KEY (source_db, source_table),
  CONSTRAINT fk_watermark_last_run_id FOREIGN KEY (last_run_id) REFERENCES stg_control.migration_run (run_id)
);

-- ---------------------------------------------------------------- stg_transform / stg_validated
-- 1 fila por usuario registrado · origen: micrautos.users
CREATE TABLE IF NOT EXISTS stg_transform.app_user (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  email text,  -- UK normalizado a minúsculas
  status text,  --  homologado vía map_catalog
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_app_user PRIMARY KEY (id)
);

-- 1 fila por vendedor (particular o de accesorios) · origen: usedcars.sellers, usedcars.expiredsellers, accesorios.sellers
CREATE TABLE IF NOT EXISTS stg_transform.seller (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user a confirmar relación con users
  is_expired boolean,  --  true si proviene de expiredsellers
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_seller PRIMARY KEY (id)
);

-- 1 fila por agencia / concesionario · origen: usedcars.dealers, newcars.dealers
CREATE TABLE IF NOT EXISTS stg_transform.dealer (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_dealer PRIMARY KEY (id)
);

-- 1 fila por usuario administrador · origen: usedcars.adminusers
CREATE TABLE IF NOT EXISTS stg_transform.admin_user (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_admin_user PRIMARY KEY (id)
);

-- 1 fila por usuario + anuncio favorito · origen: micrautos.favorites
CREATE TABLE IF NOT EXISTS stg_transform.user_favorite (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_user_favorite PRIMARY KEY (id)
);

-- 1 fila por relación de amistad · origen: micrautos.friends
CREATE TABLE IF NOT EXISTS stg_transform.user_friend (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  friend_user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_user_friend PRIMARY KEY (id)
);

-- 1 fila por solicitud del usuario · origen: micrautos.requests
CREATE TABLE IF NOT EXISTS stg_transform.user_request (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_user_request PRIMARY KEY (id)
);

-- 1 fila por sugerencia · origen: micrautos.suggestions
CREATE TABLE IF NOT EXISTS stg_transform.user_suggestion (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_user_suggestion PRIMARY KEY (id)
);

-- 1 fila por reporte de usuario · origen: micrautos.userreports
CREATE TABLE IF NOT EXISTS stg_transform.user_report (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_user_report PRIMARY KEY (id)
);

-- 1 fila por dato bloqueado (email, IP, teléfono) · origen: usedcars.blocked, usedcars.blockedemails, usedcars.blockedips, usedcars.blockedphones, usedcars.correosfraude
CREATE TABLE IF NOT EXISTS stg_transform.blocked_contact (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  contact_type text,  --  EMAIL / IP / PHONE / FRAUD_EMAIL / OTHER
  contact_value text,
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_blocked_contact PRIMARY KEY (id)
);

-- 1 fila por IP permitida · origen: usedcars.ipsaccepted
CREATE TABLE IF NOT EXISTS stg_transform.ip_allowlist (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_ip_allowlist PRIMARY KEY (id)
);

-- 1 fila por parámetro · origen: usedcars.parameters
CREATE TABLE IF NOT EXISTS stg_transform.system_parameter (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_system_parameter PRIMARY KEY (id)
);

-- 1 fila por anuncio de vehículo · origen: usedcars.archive, usedcars.datafile
CREATE TABLE IF NOT EXISTS stg_transform.listing (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  seller_id uuid,  -- FK seller
  dealer_id uuid,  -- FK dealer nullable
  brand_id uuid,  -- FK brand
  model_id uuid,  -- FK model nullable
  style_id uuid,  -- FK body_style
  province_id uuid,  -- FK province
  status text,  --  homologado
  equipment_mask bigint,  --  decodificado con fn_decode_equipment
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_listing PRIMARY KEY (id)
);

-- 1 fila por traspaso de anuncio · origen: usedcars.archivetraspaso
CREATE TABLE IF NOT EXISTS stg_transform.listing_transfer (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_listing_transfer PRIMARY KEY (id)
);

-- 1 fila por anuncio pendiente de aprobación · origen: usedcars.pending
CREATE TABLE IF NOT EXISTS stg_transform.listing_pending (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_listing_pending PRIMARY KEY (id)
);

-- 1 fila por video asociado · origen: usedcars.videos
CREATE TABLE IF NOT EXISTS stg_transform.listing_video (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_listing_video PRIMARY KEY (id)
);

-- 1 fila por imagen migrada a S3 · origen: (proceso de imágenes – no es tabla origen)
CREATE TABLE IF NOT EXISTS stg_transform.listing_image (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  s3_key text,  --  ruta en s3-multimedia
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_listing_image PRIMARY KEY (id)
);

-- 1 fila por anuncio + equipamiento · origen: (derivada: funciones CheckEquipment*)
CREATE TABLE IF NOT EXISTS stg_transform.listing_equipment (
  listing_id uuid NOT NULL,  -- PK/FK listing
  equipment_id uuid NOT NULL,  -- PK/FK equipment
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_listing_equipment PRIMARY KEY (listing_id, equipment_id)
);

-- 1 fila por tipo de equipamiento / extra · origen: usedcars.carextras
CREATE TABLE IF NOT EXISTS stg_transform.equipment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_equipment PRIMARY KEY (id)
);

-- 1 fila por oferta especial · origen: usedcars.specialdeals
CREATE TABLE IF NOT EXISTS stg_transform.special_deal (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_special_deal PRIMARY KEY (id)
);

-- 1 fila por marca homologada · origen: usedcars.brands, newcars.brands, bacge.brands, financing.newbrands, financing.usedbrands, usedcars.premiumbrands
CREATE TABLE IF NOT EXISTS stg_transform.brand (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  name text,  -- UK
  is_premium boolean,  --  desde premiumbrands
  applies_new boolean,
  applies_used boolean,
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_brand PRIMARY KEY (id)
);

-- 1 fila por modelo · origen: newcars.models
CREATE TABLE IF NOT EXISTS stg_transform.model (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  brand_id uuid,  -- FK brand
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_model PRIMARY KEY (id)
);

-- 1 fila por estilo de carrocería homologado · origen: usedcars.styles, newcars.styles, bacge.styles
CREATE TABLE IF NOT EXISTS stg_transform.body_style (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_body_style PRIMARY KEY (id)
);

-- 1 fila por provincia · origen: usedcars.provinces
CREATE TABLE IF NOT EXISTS stg_transform.province (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_province PRIMARY KEY (id)
);

-- 1 fila por banner principal · origen: newcars.mainbanners
CREATE TABLE IF NOT EXISTS stg_transform.banner (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  brand_id uuid,  -- FK brand a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_banner PRIMARY KEY (id)
);

-- 1 fila por anuncio de accesorio · origen: accesorios.archive
CREATE TABLE IF NOT EXISTS stg_transform.accessory_listing (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  seller_id uuid,  -- FK seller
  section_id uuid,  -- FK accessory_section
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_accessory_listing PRIMARY KEY (id)
);

-- 1 fila por sección de accesorios · origen: accesorios.sections
CREATE TABLE IF NOT EXISTS stg_transform.accessory_section (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_accessory_section PRIMARY KEY (id)
);

-- 1 fila por cobro · origen: usedcars.charges, accesorios.charges
CREATE TABLE IF NOT EXISTS stg_transform.payment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing nullable
  service_plan_id uuid,  -- FK service_plan
  coupon_id uuid,  -- FK coupon nullable
  amount numeric(14,2),
  status text,  --  homologado
  paid_at timestamptz,
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_payment PRIMARY KEY (id)
);

-- 1 fila por evento de cobro · origen: usedcars.chargeslog
CREATE TABLE IF NOT EXISTS stg_transform.payment_log (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  payment_id uuid,  -- FK payment
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_payment_log PRIMARY KEY (id)
);

-- 1 fila por prepago / saldo · origen: usedcars.prepay
CREATE TABLE IF NOT EXISTS stg_transform.prepayment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_prepayment PRIMARY KEY (id)
);

-- 1 fila por pago pendiente · origen: usedcars.pendingpay, accesorios.pendingpay
CREATE TABLE IF NOT EXISTS stg_transform.pending_payment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing nullable
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_pending_payment PRIMARY KEY (id)
);

-- 1 fila por cupón · origen: usedcars.coupons, accesorios.coupons
CREATE TABLE IF NOT EXISTS stg_transform.coupon (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  code text,  -- UK
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_coupon PRIMARY KEY (id)
);

-- 1 fila por plan / servicio contratable · origen: usedcars.services
CREATE TABLE IF NOT EXISTS stg_transform.service_plan (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_service_plan PRIMARY KEY (id)
);

-- 1 fila por renovación automática · origen: usedcars.autorenewhl
CREATE TABLE IF NOT EXISTS stg_transform.auto_renewal (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  service_plan_id uuid,  -- FK service_plan a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_auto_renewal PRIMARY KEY (id)
);

-- 1 fila por transacción en pasarela · origen: usedcars.tdtickets, usedcars.mttdtickets
CREATE TABLE IF NOT EXISTS stg_transform.gateway_ticket (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  payment_id uuid,  -- FK payment a confirmar
  gateway text,  --  TD / MTTD
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_gateway_ticket PRIMARY KEY (id)
);

-- 1 fila por factura · origen: usedcars.tdinvoices
CREATE TABLE IF NOT EXISTS stg_transform.invoice (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  payment_id uuid,  -- FK payment a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _transformed_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_transform_invoice PRIMARY KEY (id)
);

-- 1 fila por usuario registrado · origen: micrautos.users
CREATE TABLE IF NOT EXISTS stg_validated.app_user (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  email text,  -- UK normalizado a minúsculas
  status text,  --  homologado vía map_catalog
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_app_user PRIMARY KEY (id)
);

-- 1 fila por vendedor (particular o de accesorios) · origen: usedcars.sellers, usedcars.expiredsellers, accesorios.sellers
CREATE TABLE IF NOT EXISTS stg_validated.seller (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user a confirmar relación con users
  is_expired boolean,  --  true si proviene de expiredsellers
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_seller PRIMARY KEY (id)
);

-- 1 fila por agencia / concesionario · origen: usedcars.dealers, newcars.dealers
CREATE TABLE IF NOT EXISTS stg_validated.dealer (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_dealer PRIMARY KEY (id)
);

-- 1 fila por usuario administrador · origen: usedcars.adminusers
CREATE TABLE IF NOT EXISTS stg_validated.admin_user (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_admin_user PRIMARY KEY (id)
);

-- 1 fila por usuario + anuncio favorito · origen: micrautos.favorites
CREATE TABLE IF NOT EXISTS stg_validated.user_favorite (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_user_favorite PRIMARY KEY (id)
);

-- 1 fila por relación de amistad · origen: micrautos.friends
CREATE TABLE IF NOT EXISTS stg_validated.user_friend (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  friend_user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_user_friend PRIMARY KEY (id)
);

-- 1 fila por solicitud del usuario · origen: micrautos.requests
CREATE TABLE IF NOT EXISTS stg_validated.user_request (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_user_request PRIMARY KEY (id)
);

-- 1 fila por sugerencia · origen: micrautos.suggestions
CREATE TABLE IF NOT EXISTS stg_validated.user_suggestion (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_user_suggestion PRIMARY KEY (id)
);

-- 1 fila por reporte de usuario · origen: micrautos.userreports
CREATE TABLE IF NOT EXISTS stg_validated.user_report (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_user_report PRIMARY KEY (id)
);

-- 1 fila por dato bloqueado (email, IP, teléfono) · origen: usedcars.blocked, usedcars.blockedemails, usedcars.blockedips, usedcars.blockedphones, usedcars.correosfraude
CREATE TABLE IF NOT EXISTS stg_validated.blocked_contact (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  contact_type text,  --  EMAIL / IP / PHONE / FRAUD_EMAIL / OTHER
  contact_value text,
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_blocked_contact PRIMARY KEY (id)
);

-- 1 fila por IP permitida · origen: usedcars.ipsaccepted
CREATE TABLE IF NOT EXISTS stg_validated.ip_allowlist (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_ip_allowlist PRIMARY KEY (id)
);

-- 1 fila por parámetro · origen: usedcars.parameters
CREATE TABLE IF NOT EXISTS stg_validated.system_parameter (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_system_parameter PRIMARY KEY (id)
);

-- 1 fila por anuncio de vehículo · origen: usedcars.archive, usedcars.datafile
CREATE TABLE IF NOT EXISTS stg_validated.listing (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  seller_id uuid,  -- FK seller
  dealer_id uuid,  -- FK dealer nullable
  brand_id uuid,  -- FK brand
  model_id uuid,  -- FK model nullable
  style_id uuid,  -- FK body_style
  province_id uuid,  -- FK province
  status text,  --  homologado
  equipment_mask bigint,  --  decodificado con fn_decode_equipment
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_listing PRIMARY KEY (id)
);

-- 1 fila por traspaso de anuncio · origen: usedcars.archivetraspaso
CREATE TABLE IF NOT EXISTS stg_validated.listing_transfer (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_listing_transfer PRIMARY KEY (id)
);

-- 1 fila por anuncio pendiente de aprobación · origen: usedcars.pending
CREATE TABLE IF NOT EXISTS stg_validated.listing_pending (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_listing_pending PRIMARY KEY (id)
);

-- 1 fila por video asociado · origen: usedcars.videos
CREATE TABLE IF NOT EXISTS stg_validated.listing_video (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_listing_video PRIMARY KEY (id)
);

-- 1 fila por imagen migrada a S3 · origen: (proceso de imágenes – no es tabla origen)
CREATE TABLE IF NOT EXISTS stg_validated.listing_image (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  s3_key text,  --  ruta en s3-multimedia
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_listing_image PRIMARY KEY (id)
);

-- 1 fila por anuncio + equipamiento · origen: (derivada: funciones CheckEquipment*)
CREATE TABLE IF NOT EXISTS stg_validated.listing_equipment (
  listing_id uuid NOT NULL,  -- PK/FK listing
  equipment_id uuid NOT NULL,  -- PK/FK equipment
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_listing_equipment PRIMARY KEY (listing_id, equipment_id)
);

-- 1 fila por tipo de equipamiento / extra · origen: usedcars.carextras
CREATE TABLE IF NOT EXISTS stg_validated.equipment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_equipment PRIMARY KEY (id)
);

-- 1 fila por oferta especial · origen: usedcars.specialdeals
CREATE TABLE IF NOT EXISTS stg_validated.special_deal (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_special_deal PRIMARY KEY (id)
);

-- 1 fila por marca homologada · origen: usedcars.brands, newcars.brands, bacge.brands, financing.newbrands, financing.usedbrands, usedcars.premiumbrands
CREATE TABLE IF NOT EXISTS stg_validated.brand (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  name text,  -- UK
  is_premium boolean,  --  desde premiumbrands
  applies_new boolean,
  applies_used boolean,
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_brand PRIMARY KEY (id)
);

-- 1 fila por modelo · origen: newcars.models
CREATE TABLE IF NOT EXISTS stg_validated.model (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  brand_id uuid,  -- FK brand
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_model PRIMARY KEY (id)
);

-- 1 fila por estilo de carrocería homologado · origen: usedcars.styles, newcars.styles, bacge.styles
CREATE TABLE IF NOT EXISTS stg_validated.body_style (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_body_style PRIMARY KEY (id)
);

-- 1 fila por provincia · origen: usedcars.provinces
CREATE TABLE IF NOT EXISTS stg_validated.province (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_province PRIMARY KEY (id)
);

-- 1 fila por banner principal · origen: newcars.mainbanners
CREATE TABLE IF NOT EXISTS stg_validated.banner (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  brand_id uuid,  -- FK brand a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_banner PRIMARY KEY (id)
);

-- 1 fila por anuncio de accesorio · origen: accesorios.archive
CREATE TABLE IF NOT EXISTS stg_validated.accessory_listing (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  seller_id uuid,  -- FK seller
  section_id uuid,  -- FK accessory_section
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_accessory_listing PRIMARY KEY (id)
);

-- 1 fila por sección de accesorios · origen: accesorios.sections
CREATE TABLE IF NOT EXISTS stg_validated.accessory_section (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_accessory_section PRIMARY KEY (id)
);

-- 1 fila por cobro · origen: usedcars.charges, accesorios.charges
CREATE TABLE IF NOT EXISTS stg_validated.payment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing nullable
  service_plan_id uuid,  -- FK service_plan
  coupon_id uuid,  -- FK coupon nullable
  amount numeric(14,2),
  status text,  --  homologado
  paid_at timestamptz,
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_payment PRIMARY KEY (id)
);

-- 1 fila por evento de cobro · origen: usedcars.chargeslog
CREATE TABLE IF NOT EXISTS stg_validated.payment_log (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  payment_id uuid,  -- FK payment
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_payment_log PRIMARY KEY (id)
);

-- 1 fila por prepago / saldo · origen: usedcars.prepay
CREATE TABLE IF NOT EXISTS stg_validated.prepayment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_prepayment PRIMARY KEY (id)
);

-- 1 fila por pago pendiente · origen: usedcars.pendingpay, accesorios.pendingpay
CREATE TABLE IF NOT EXISTS stg_validated.pending_payment (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  user_id uuid,  -- FK app_user
  listing_id uuid,  -- FK listing nullable
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_pending_payment PRIMARY KEY (id)
);

-- 1 fila por cupón · origen: usedcars.coupons, accesorios.coupons
CREATE TABLE IF NOT EXISTS stg_validated.coupon (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  code text,  -- UK
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_coupon PRIMARY KEY (id)
);

-- 1 fila por plan / servicio contratable · origen: usedcars.services
CREATE TABLE IF NOT EXISTS stg_validated.service_plan (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_service_plan PRIMARY KEY (id)
);

-- 1 fila por renovación automática · origen: usedcars.autorenewhl
CREATE TABLE IF NOT EXISTS stg_validated.auto_renewal (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  listing_id uuid,  -- FK listing
  service_plan_id uuid,  -- FK service_plan a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_auto_renewal PRIMARY KEY (id)
);

-- 1 fila por transacción en pasarela · origen: usedcars.tdtickets, usedcars.mttdtickets
CREATE TABLE IF NOT EXISTS stg_validated.gateway_ticket (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  payment_id uuid,  -- FK payment a confirmar
  gateway text,  --  TD / MTTD
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_gateway_ticket PRIMARY KEY (id)
);

-- 1 fila por factura · origen: usedcars.tdinvoices
CREATE TABLE IF NOT EXISTS stg_validated.invoice (
  id uuid NOT NULL,  -- PK UUID v5 determinístico a partir de bd.tabla:pk_origen
  legacy_id text,  --  PK del origen (texto, admite PK compuesta)
  legacy_source text,  --  bd.tabla de origen
  payment_id uuid,  -- FK payment a confirmar
  -- TODO columnas de negocio (S2T / DATA-03)
  _run_id bigint,
  _source_db text,
  _source_table text,
  _source_pk text,
  _row_hash text,
  _is_deleted boolean NOT NULL DEFAULT false,
  _validated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pk_validated_invoice PRIMARY KEY (id)
);

