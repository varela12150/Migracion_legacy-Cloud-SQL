-- ======================================================================
-- stg_transform.sp_transform_accessory_listing
-- stg_raw → stg_transform.accessory_listing  ·  Destino final: listings_db.accessory_listing
-- Lee: stg_raw.accesorios__archive + stg_raw.accesorios__pendingpay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_accessory_listing(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_accessory_listing(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'accessory_listing');

    SELECT (SELECT count(*) FROM stg_raw.accesorios__archive)
        + (SELECT count(*) FROM stg_raw.accesorios__pendingpay)
      INTO v_in;

    WITH src AS (
    -- ---- accesorios.archive
    -- No se migran: ip, pwd
    SELECT
        stg_control.fn_legacy_uuid('accesorios.archive', r."codigo"::text)     AS id,
        r."codigo"::text                                                       AS legacy_id,
        'accesorios.archive'                                                   AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        stg_control.fn_map_code('ACC_ESTADO', 'accesorios', r."estado"::text)  AS condition_code,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."expdate")                             AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_phone_cr(r."tel1")                                AS phone,
        stg_control.fn_clean_phone_cr(r."tel2")                                AS phone_2,
        stg_control.fn_clean_phone_cr(r."tel3")                                AS phone_3,
        r."precio"::numeric(14,2)                                              AS price,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."moneda"::text)    AS currency,
        r."refprice"::numeric(14,2)                                            AS reference_price,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."titulo"::text)                            AS title,
        stg_control.fn_clean_text(r."itemdesc"::text)                          AS description,
        stg_control.fn_legacy_uuid('accesorios.sections', r."seccion"::text)   AS section_id,
        stg_control.fn_to_date(r."deldate")                                    AS deleted_at,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        'accesorios'::text AS _source_db, 'archive'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.accesorios__archive r
    UNION ALL
    -- ---- accesorios.pendingpay
    -- No se migran: ip, pwd
    SELECT
        stg_control.fn_legacy_uuid('accesorios.pendingpay', r."codigo"::text)  AS id,
        r."codigo"::text                                                       AS legacy_id,
        'accesorios.pendingpay'                                                AS legacy_source,
        r."refcode"::text                                                      AS reference_code,
        stg_control.fn_map_code('ACC_ESTADO', 'accesorios', r."estado"::text)  AS condition_code,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_timestamptz(r."expdate")                             AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_phone_cr(r."tel1")                                AS phone,
        stg_control.fn_clean_phone_cr(r."tel2")                                AS phone_2,
        stg_control.fn_clean_phone_cr(r."tel3")                                AS phone_3,
        r."precio"::numeric(14,2)                                              AS price,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."moneda"::text)    AS currency,
        r."refprice"::numeric(14,2)                                            AS reference_price,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."titulo"::text)                            AS title,
        stg_control.fn_clean_text(r."itemdesc"::text)                          AS description,
        stg_control.fn_legacy_uuid('accesorios.sections', r."seccion"::text)   AS section_id,
        stg_control.fn_to_date(r."deldate")                                    AS deleted_at,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        'accesorios'::text AS _source_db, 'pendingpay'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__pendingpay r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.accessory_listing (id, legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, reference_code, condition_code, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, visit_count, image_count, contact_name, contact_email, phone, phone_2, phone_3, price, currency, reference_price, title, description, section_id, deleted_at, deleted_by)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        reference_code = EXCLUDED.reference_code,
        condition_code = EXCLUDED.condition_code,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        visit_count = EXCLUDED.visit_count,
        image_count = EXCLUDED.image_count,
        contact_name = EXCLUDED.contact_name,
        contact_email = EXCLUDED.contact_email,
        phone = EXCLUDED.phone,
        phone_2 = EXCLUDED.phone_2,
        phone_3 = EXCLUDED.phone_3,
        price = EXCLUDED.price,
        currency = EXCLUDED.currency,
        reference_price = EXCLUDED.reference_price,
        title = EXCLUDED.title,
        description = EXCLUDED.description,
        section_id = EXCLUDED.section_id,
        deleted_at = EXCLUDED.deleted_at,
        deleted_by = EXCLUDED.deleted_by,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.accessory_listing._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.accessory_listing._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'accessory_listing', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_accessory_listing(bigint) IS 'stg_raw → stg_transform.accessory_listing (esqueleto v1 desde S2T)';
