-- ======================================================================
-- stg_transform.sp_transform_seller
-- stg_raw → stg_transform.seller  ·  Destino final: users_db.seller
-- Lee: stg_raw.usedcars__sellers + stg_raw.accesorios__sellers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_seller(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_seller(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'seller');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__sellers)
        + (SELECT count(*) FROM stg_raw.accesorios__sellers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.sellers
    -- No se migran: sellerpwd, sellerpwd2, favcount
    SELECT
        stg_control.fn_legacy_uuid('usedcars.sellers', r."selleremail"::text)  AS id,
        r."selleremail"::text                                                  AS legacy_id,
        'usedcars.sellers'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."sellername"::text)                        AS name,
        stg_control.fn_clean_phone_cr(r."sellerphone")                         AS phone,
        stg_control.fn_clean_email(r."selleremail")                            AS email,
        stg_control.fn_to_date(r."sellerindate")                               AS start_date,
        stg_control.fn_to_date(r."sellerexpire")                               AS expiration_date,
        r."sellerlimit"::integer                                               AS ad_limit,
        stg_control.fn_map_code('SELLER_STATUS', 'usedcars', r."sellerstatus"::text) AS status,
        r."sellercode"::text                                                   AS seller_code,
        r."sellerplanamt"::numeric(12,2)                                       AS plan_amount,
        stg_control.fn_clean_text(r."sitelink"::text)                          AS website,
        r."dollaramt"::numeric(12,2)                                           AS plan_amount_usd,  -- POR CONFIRMAR
        r."destacados"::integer                                                AS featured_quota,
        stg_control.fn_clean_text(r."dept"::text)                              AS department,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_clean_text(r."selleraddr1"::text)                       AS address_line1,
        stg_control.fn_clean_text(r."selleraddr2"::text)                       AS address_line2,
        stg_control.fn_map_code('PROVINCE', 'usedcars', r."sellerprovince"::text) AS province_id,
        stg_control.fn_clean_text(r."sellercity"::text)                        AS city,
        stg_control.fn_to_bool(r."financeflag"::text)                          AS offers_financing,  -- POR CONFIRMAR
        r."accountamount"::numeric(12,2)                                       AS account_balance,
        stg_control.fn_to_timestamptz(r."accountlastdeposit")                  AS last_deposit_at,
        stg_control.fn_to_timestamptz(r."accountlastcharge")                   AS last_charge_at,
        stg_control.fn_to_date(r."bannerstart")                                AS banner_start_date,
        stg_control.fn_to_date(r."bannerend")                                  AS banner_end_date,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        stg_control.fn_clean_text(r."video"::text)                             AS video_html,
        stg_control.fn_clean_phone_cr(r."sellerwhatsapp")                      AS whatsapp,
        stg_control.fn_clean_text(r."rep"::text)                               AS sales_rep,
        stg_control.fn_clean_text(r."contactname"::text)                       AS contact_name,
        stg_control.fn_clean_phone_cr(r."contactphone")                        AS contact_phone,
        stg_control.fn_clean_email(r."contactemail")                           AS contact_email,
        NULL::text                                                             AS phone_2,  -- no viene de usedcars.sellers
        NULL::text                                                             AS phone_3,  -- no viene de usedcars.sellers
        NULL::text                                                             AS logo_s3_key,  -- no viene de usedcars.sellers
        'usedcars'::text AS _source_db, 'sellers'::text AS _source_table, r."selleremail"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__sellers r
    UNION ALL
    -- ---- accesorios.sellers
    -- No se migran: sellerpwd, favcount
    SELECT
        stg_control.fn_legacy_uuid('accesorios.sellers', r."selleremail"::text) AS id,
        r."selleremail"::text                                                  AS legacy_id,
        'accesorios.sellers'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."sellername"::text)                        AS name,
        stg_control.fn_clean_phone_cr(r."sellertel1")                          AS phone,
        stg_control.fn_clean_email(r."selleremail")                            AS email,
        stg_control.fn_to_date(r."sellerindate")                               AS start_date,
        stg_control.fn_to_date(r."sellerexpire")                               AS expiration_date,
        r."sellerlimit"::integer                                               AS ad_limit,
        stg_control.fn_map_code('SELLER_STATUS', 'accesorios', r."sellerstatus"::text) AS status,
        r."sellercode"::text                                                   AS seller_code,
        r."sellerplanamt"::numeric(12,2)                                       AS plan_amount,
        stg_control.fn_clean_text(r."sitelink"::text)                          AS website,
        r."dollaramt"::numeric(12,2)                                           AS plan_amount_usd,  -- POR CONFIRMAR
        r."destacados"::integer                                                AS featured_quota,
        stg_control.fn_clean_text(r."dept"::text)                              AS department,
        stg_control.fn_map_code('CURRENCY', 'accesorios', r."currency"::text)  AS currency,
        stg_control.fn_clean_text(r."selleraddr1"::text)                       AS address_line1,
        stg_control.fn_clean_text(r."selleraddr2"::text)                       AS address_line2,
        stg_control.fn_map_code('PROVINCE', 'accesorios', r."sellerprovince"::text) AS province_id,
        stg_control.fn_clean_text(r."sellercity"::text)                        AS city,
        NULL::boolean                                                          AS offers_financing,  -- no viene de accesorios.sellers
        r."accountamount"::numeric(12,2)                                       AS account_balance,
        stg_control.fn_to_timestamptz(r."accountlastdeposit")                  AS last_deposit_at,
        stg_control.fn_to_timestamptz(r."accountlastcharge")                   AS last_charge_at,
        NULL::date                                                             AS banner_start_date,  -- no viene de accesorios.sellers
        NULL::date                                                             AS banner_end_date,  -- no viene de accesorios.sellers
        NULL::boolean                                                          AS is_premium,  -- no viene de accesorios.sellers
        NULL::text                                                             AS video_html,  -- no viene de accesorios.sellers
        NULL::text                                                             AS whatsapp,  -- no viene de accesorios.sellers
        NULL::text                                                             AS sales_rep,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_name,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_phone,  -- no viene de accesorios.sellers
        NULL::text                                                             AS contact_email,  -- no viene de accesorios.sellers
        stg_control.fn_clean_phone_cr(r."sellertel2")                          AS phone_2,
        stg_control.fn_clean_phone_cr(r."sellertel3")                          AS phone_3,
        r."logo"::text                                                         AS logo_s3_key,
        'accesorios'::text AS _source_db, 'sellers'::text AS _source_table, r."selleremail"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__sellers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.seller (id, legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, phone, email, start_date, expiration_date, ad_limit, status, seller_code, plan_amount, website, plan_amount_usd, featured_quota, department, currency, address_line1, address_line2, province_id, city, offers_financing, account_balance, last_deposit_at, last_charge_at, banner_start_date, banner_end_date, is_premium, video_html, whatsapp, sales_rep, contact_name, contact_phone, contact_email, phone_2, phone_3, logo_s3_key)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        phone = EXCLUDED.phone,
        email = EXCLUDED.email,
        start_date = EXCLUDED.start_date,
        expiration_date = EXCLUDED.expiration_date,
        ad_limit = EXCLUDED.ad_limit,
        status = EXCLUDED.status,
        seller_code = EXCLUDED.seller_code,
        plan_amount = EXCLUDED.plan_amount,
        website = EXCLUDED.website,
        plan_amount_usd = EXCLUDED.plan_amount_usd,
        featured_quota = EXCLUDED.featured_quota,
        department = EXCLUDED.department,
        currency = EXCLUDED.currency,
        address_line1 = EXCLUDED.address_line1,
        address_line2 = EXCLUDED.address_line2,
        province_id = EXCLUDED.province_id,
        city = EXCLUDED.city,
        offers_financing = EXCLUDED.offers_financing,
        account_balance = EXCLUDED.account_balance,
        last_deposit_at = EXCLUDED.last_deposit_at,
        last_charge_at = EXCLUDED.last_charge_at,
        banner_start_date = EXCLUDED.banner_start_date,
        banner_end_date = EXCLUDED.banner_end_date,
        is_premium = EXCLUDED.is_premium,
        video_html = EXCLUDED.video_html,
        whatsapp = EXCLUDED.whatsapp,
        sales_rep = EXCLUDED.sales_rep,
        contact_name = EXCLUDED.contact_name,
        contact_phone = EXCLUDED.contact_phone,
        contact_email = EXCLUDED.contact_email,
        phone_2 = EXCLUDED.phone_2,
        phone_3 = EXCLUDED.phone_3,
        logo_s3_key = EXCLUDED.logo_s3_key,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.seller._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.seller._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'seller', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_seller(bigint) IS 'stg_raw → stg_transform.seller (esqueleto v1 desde S2T)';
