-- ======================================================================
-- stg_transform.sp_transform_dealer
-- stg_raw → stg_transform.dealer  ·  Destino final: users_db.dealer
-- Lee: stg_raw.usedcars__dealers + stg_raw.newcars__dealers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_dealer(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_dealer(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'dealer');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__dealers)
        + (SELECT count(*) FROM stg_raw.newcars__dealers)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.dealers  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: folder
    SELECT
        stg_control.fn_legacy_uuid('usedcars.dealers', md5(concat_ws('|', r."dealercode", r."dealername", r."folder", r."link", r."demail"))) AS id,
        r."dealercode"::text                                                   AS legacy_id,
        'usedcars.dealers'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."dealername"::text)                        AS name,
        stg_control.fn_clean_text(r."link"::text)                              AS website,
        stg_control.fn_clean_email(r."demail")                                 AS email,
        NULL::text                                                             AS address,  -- no viene de usedcars.dealers
        NULL::text                                                             AS notes,  -- no viene de usedcars.dealers
        NULL::text                                                             AS username,  -- no viene de usedcars.dealers
        NULL::text                                                             AS email_2,  -- no viene de usedcars.dealers
        NULL::text                                                             AS email_3,  -- no viene de usedcars.dealers
        NULL::text                                                             AS seller_code,  -- no viene de usedcars.dealers
        'usedcars'::text AS _source_db, 'dealers'::text AS _source_table, md5(concat_ws('|', r."dealercode", r."dealername", r."folder", r."link", r."demail")) AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__dealers r
    UNION ALL
    -- ---- newcars.dealers
    -- No se migran: dpwd
    SELECT
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)         AS id,
        r."dcode"::text                                                        AS legacy_id,
        'newcars.dealers'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."dname"::text)                             AS name,
        stg_control.fn_clean_text(r."dwebsite"::text)                          AS website,
        stg_control.fn_clean_email(r."email1")                                 AS email,
        stg_control.fn_clean_text(r."daddress"::text)                          AS address,
        stg_control.fn_clean_text(r."dotherinfo"::text)                        AS notes,
        stg_control.fn_clean_text(r."duser"::text)                             AS username,
        stg_control.fn_clean_email(r."email2")                                 AS email_2,
        stg_control.fn_clean_email(r."email3")                                 AS email_3,
        r."dusedcode"::text                                                    AS seller_code,  -- POR CONFIRMAR
        'newcars'::text AS _source_db, 'dealers'::text AS _source_table, r."dcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.newcars__dealers r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.dealer (id, legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, website, email, address, notes, username, email_2, email_3, seller_code)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        website = EXCLUDED.website,
        email = EXCLUDED.email,
        address = EXCLUDED.address,
        notes = EXCLUDED.notes,
        username = EXCLUDED.username,
        email_2 = EXCLUDED.email_2,
        email_3 = EXCLUDED.email_3,
        seller_code = EXCLUDED.seller_code,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.dealer._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.dealer._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'dealer', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_dealer(bigint) IS 'stg_raw → stg_transform.dealer (esqueleto v1 desde S2T)';
