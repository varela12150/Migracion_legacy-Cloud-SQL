-- ======================================================================
-- stg_transform.sp_transform_app_user
-- stg_raw → stg_transform.app_user  ·  Destino final: users_db.app_user
-- Lee: stg_raw.micrautos__users
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_app_user(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_app_user(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'app_user');

    SELECT (SELECT count(*) FROM stg_raw.micrautos__users)
      INTO v_in;

    WITH src AS (
    -- ---- micrautos.users
    -- No se migran: upwd, umenustyle, umainmenubg, umainbgcolor, umodelstitle, umodelnamebg, udestacadoscolor, udestacadosheader, udetailmaintitle, udetailsubtitle, udetailequiptitle, udetailequip, ulisthighlight, umodelborder, unewmenubg, actreqs, actattempts
    SELECT
        stg_control.fn_legacy_uuid('micrautos.users', r."ucode"::text)         AS id,
        r."ucode"::text                                                        AS legacy_id,
        'micrautos.users'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."uname"::text)                             AS first_name,
        stg_control.fn_clean_text(r."ulname"::text)                            AS last_name,
        stg_control.fn_map_code('ID_TYPE', 'micrautos', r."uidtype"::text)     AS id_type,
        stg_control.fn_clean_id_number(r."uidnum")                             AS id_number,
        stg_control.fn_make_date(r."uyear", r."umonth", r."uday")              AS birth_date,  -- combina uday, umonth, uyear
        stg_control.fn_map_code('GENDER', 'micrautos', r."usex"::text)         AS gender,
        stg_control.fn_clean_email(r."uemail")                                 AS email,
        stg_control.fn_to_date(r."udatein")                                    AS created_at,
        stg_control.fn_to_timestamptz(r."ulastlogin")                          AS last_login_at,
        stg_control.fn_map_code('USER_STATUS', 'micrautos', r."ustatus"::text) AS status,
        stg_control.fn_clean_text(r."uaddr1"::text)                            AS address_line1,
        stg_control.fn_clean_text(r."uaddr2"::text)                            AS address_line2,
        stg_control.fn_clean_text(r."ucity"::text)                             AS city,
        stg_control.fn_map_code('COUNTRY', 'micrautos', r."ucountry"::text)    AS country,
        stg_control.fn_clean_text(r."upostalcode"::text)                       AS postal_code,
        stg_control.fn_clean_phone_cr(r."uphonehome")                          AS phone_home,
        stg_control.fn_clean_phone_cr(r."uphonework")                          AS phone_work,
        stg_control.fn_clean_phone_cr(r."uphonecel")                           AS phone_mobile,
        r."ufreead"::text                                                      AS free_ad_flag,  -- POR CONFIRMAR
        stg_control.fn_to_bool(r."usendemail"::text)                           AS accepts_email,
        stg_control.fn_clean_text(r."unick"::text)                             AS nickname,
        'micrautos'::text AS _source_db, 'users'::text AS _source_table, r."ucode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.micrautos__users r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.app_user (id, legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, first_name, last_name, id_type, id_number, birth_date, gender, email, created_at, last_login_at, status, address_line1, address_line2, city, country, postal_code, phone_home, phone_work, phone_mobile, free_ad_flag, accepts_email, nickname)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        first_name = EXCLUDED.first_name,
        last_name = EXCLUDED.last_name,
        id_type = EXCLUDED.id_type,
        id_number = EXCLUDED.id_number,
        birth_date = EXCLUDED.birth_date,
        gender = EXCLUDED.gender,
        email = EXCLUDED.email,
        created_at = EXCLUDED.created_at,
        last_login_at = EXCLUDED.last_login_at,
        status = EXCLUDED.status,
        address_line1 = EXCLUDED.address_line1,
        address_line2 = EXCLUDED.address_line2,
        city = EXCLUDED.city,
        country = EXCLUDED.country,
        postal_code = EXCLUDED.postal_code,
        phone_home = EXCLUDED.phone_home,
        phone_work = EXCLUDED.phone_work,
        phone_mobile = EXCLUDED.phone_mobile,
        free_ad_flag = EXCLUDED.free_ad_flag,
        accepts_email = EXCLUDED.accepts_email,
        nickname = EXCLUDED.nickname,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.app_user._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.app_user._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'app_user', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_app_user(bigint) IS 'stg_raw → stg_transform.app_user (esqueleto v1 desde S2T)';
