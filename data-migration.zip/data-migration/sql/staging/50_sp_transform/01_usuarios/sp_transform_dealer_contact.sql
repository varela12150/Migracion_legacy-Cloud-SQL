-- ======================================================================
-- stg_transform.sp_transform_dealer_contact
-- stg_raw → stg_transform.dealer_contact  ·  Destino final: users_db.dealer_contact
-- Lee: stg_raw.newcars__dealers
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_dealer_contact(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_dealer_contact(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'dealer_contact');

    SELECT (SELECT count(*) FROM stg_raw.newcars__dealers)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.dealers: pivot dphoneN / dphonerefN
    SELECT
        stg_control.fn_legacy_uuid('newcars.dealers:contact', r."dcode"::text || '|' || v.n) AS id,
        r."dcode"::text || '|' || v.n                                        AS legacy_id,
        'newcars.dealers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('newcars.dealers', r."dcode"::text)                                                   AS dealer_id,
        stg_control.fn_clean_phone_cr(v.phone)                     AS phone,
        stg_control.fn_clean_text(v.label)                         AS phone_label,
        v.n::smallint                                              AS sort_order,
        'newcars'::text AS _source_db, 'dealers'::text AS _source_table, r."dcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.newcars__dealers r
    CROSS JOIN LATERAL (VALUES
            (1, r."dphone1"::text, r."dphoneref1"::text),
            (2, r."dphone2"::text, r."dphoneref2"::text),
            (3, r."dphone3"::text, r."dphoneref3"::text),
            (4, r."dphone4"::text, r."dphoneref4"::text),
            (5, r."dphone5"::text, r."dphoneref5"::text),
            (6, r."dphone6"::text, r."dphoneref6"::text),
            (7, r."dphone7"::text, r."dphoneref7"::text),
            (8, r."dphone8"::text, r."dphoneref8"::text),
            (9, r."dphone9"::text, r."dphoneref9"::text),
            (10, r."dphone10"::text, r."dphoneref10"::text),
            (11, r."dphone11"::text, r."dphoneref11"::text),
            (12, r."dphone12"::text, r."dphoneref12"::text),
            (13, r."dphone13"::text, r."dphoneref13"::text),
            (14, r."dphone14"::text, r."dphoneref14"::text),
            (15, r."dphone15"::text, r."dphoneref15"::text),
            (16, r."dphone16"::text, r."dphoneref16"::text),
            (17, r."dphone17"::text, r."dphoneref17"::text),
            (18, r."dphone18"::text, r."dphoneref18"::text),
            (19, r."dphone19"::text, r."dphoneref19"::text),
            (20, r."dphone20"::text, r."dphoneref20"::text),
            (21, r."dphone21"::text, r."dphoneref21"::text),
            (22, r."dphone22"::text, r."dphoneref22"::text),
            (23, r."dphone23"::text, r."dphoneref23"::text),
            (24, r."dphone24"::text, r."dphoneref24"::text),
            (25, r."dphone25"::text, r."dphoneref25"::text)
         ) AS v(n, phone, label)
    WHERE nullif(trim(v.phone), '') IS NOT NULL
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.dealer_contact (id, legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, dealer_id, phone, phone_label, sort_order)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        dealer_id = EXCLUDED.dealer_id,
        phone = EXCLUDED.phone,
        phone_label = EXCLUDED.phone_label,
        sort_order = EXCLUDED.sort_order,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.dealer_contact._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.dealer_contact._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'dealer_contact', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_dealer_contact(bigint) IS 'stg_raw → stg_transform.dealer_contact (esqueleto v1 desde S2T)';
