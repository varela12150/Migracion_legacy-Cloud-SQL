-- ======================================================================
-- stg_transform.sp_transform_einvoice_document
-- stg_raw → stg_transform.einvoice_document  ·  Destino final: payments_db.einvoice_document
-- Lee: stg_raw.usedcars__tdtickets + stg_raw.usedcars__mttdtickets + stg_raw.usedcars__tdinvoices
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_einvoice_document(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_einvoice_document(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'einvoice_document');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__tdtickets)
        + (SELECT count(*) FROM stg_raw.usedcars__mttdtickets)
        + (SELECT count(*) FROM stg_raw.usedcars__tdinvoices)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.tdtickets
    SELECT
        stg_control.fn_legacy_uuid('usedcars.tdtickets', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.tdtickets'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'tdtickets'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__tdtickets r
    UNION ALL
    -- ---- usedcars.mttdtickets
    SELECT
        stg_control.fn_legacy_uuid('usedcars.mttdtickets', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.mttdtickets'                                                 AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'mttdtickets'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__mttdtickets r
    UNION ALL
    -- ---- usedcars.tdinvoices
    SELECT
        stg_control.fn_legacy_uuid('usedcars.tdinvoices', r."invoicenum"::text) AS id,
        r."invoicenum"::text                                                   AS legacy_id,
        'usedcars.tdinvoices'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."invoicenum"::text)                        AS document_number,
        r."tdclave"::text                                                      AS einvoice_key,
        'usedcars'::text AS _source_db, 'tdinvoices'::text AS _source_table, r."invoicenum"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__tdinvoices r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.einvoice_document (id, legacy_id, legacy_source, document_number, einvoice_key,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, document_number, einvoice_key,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, document_number, einvoice_key)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        document_number = EXCLUDED.document_number,
        einvoice_key = EXCLUDED.einvoice_key,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.einvoice_document._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.einvoice_document._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'einvoice_document', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_einvoice_document(bigint) IS 'stg_raw → stg_transform.einvoice_document (esqueleto v1 desde S2T)';
