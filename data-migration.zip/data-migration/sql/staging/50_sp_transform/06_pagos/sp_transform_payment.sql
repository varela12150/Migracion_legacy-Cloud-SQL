-- ======================================================================
-- stg_transform.sp_transform_payment
-- stg_raw → stg_transform.payment  ·  Destino final: payments_db.payment
-- Lee: stg_raw.usedcars__charges + stg_raw.accesorios__charges
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_payment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_payment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'payment');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__charges)
        + (SELECT count(*) FROM stg_raw.accesorios__charges)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.charges
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.charges', concat_ws('|', r."codigo", r."datein", r."tdinvoicenum")) AS id,
        concat_ws('|', r."codigo", r."datein", r."tdinvoicenum")               AS legacy_id,
        'usedcars.charges'                                                     AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_map_code('PAYMENT_SOURCE', 'usedcars', r."source"::text) AS channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS paid_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_map_code('PAYMENT_FEATURE', 'usedcars', r."feature"::text) AS service_code,
        stg_control.fn_clean_text(r."cname"::text)                             AS cardholder_name,
        stg_control.fn_map_code('CARD_BRAND', 'usedcars', r."ctype"::text)     AS card_brand,
        stg_control.fn_clean_text(r."clast4"::text)::char(4)                   AS card_last4,
        stg_control.fn_clean_text(r."approval"::text)                          AS authorization_code,
        to_jsonb(r."tdresponse")                                               AS gateway_response,  -- POR CONFIRMAR · TODO: evaluar jsonb vs archivo en S3
        stg_control.fn_clean_text(r."tdname"::text)                            AS invoice_name,
        stg_control.fn_clean_email(r."tdemail")                                AS invoice_email,
        stg_control.fn_map_code('ID_TYPE', 'usedcars', r."tdidtype"::text)     AS invoice_id_type,
        stg_control.fn_clean_text(r."tdidnum"::text)                           AS invoice_id_number,
        r."tdclave"::text                                                      AS einvoice_key,
        stg_control.fn_clean_text(r."tdmsg"::text)                             AS einvoice_message,
        stg_control.fn_map_code('EINVOICE_STATUS', 'usedcars', r."tdstatus"::text) AS einvoice_status,
        r."tdinvoicenum"::text                                                 AS invoice_number,
        to_jsonb(r."json")                                                     AS gateway_payload,  -- POR CONFIRMAR · TODO: evaluar jsonb vs archivo en S3
        'usedcars'::text AS _source_db, 'charges'::text AS _source_table, concat_ws('|', r."codigo", r."datein", r."tdinvoicenum") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__charges r
    UNION ALL
    -- ---- accesorios.charges  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('accesorios.charges', md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval"))) AS id,
        md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval")) AS legacy_id,
        'accesorios.charges'                                                   AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_map_code('PAYMENT_SOURCE', 'accesorios', r."source"::text) AS channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS paid_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_map_code('PAYMENT_FEATURE', 'accesorios', r."feature"::text) AS service_code,
        stg_control.fn_clean_text(r."cname"::text)                             AS cardholder_name,
        stg_control.fn_map_code('CARD_BRAND', 'accesorios', r."ctype"::text)   AS card_brand,
        stg_control.fn_clean_text(r."clast4"::text)::char(4)                   AS card_last4,
        stg_control.fn_clean_text(r."approval"::text)                          AS authorization_code,
        NULL::jsonb                                                            AS gateway_response,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_name,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_email,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_id_type,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_id_number,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_key,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_message,  -- no viene de accesorios.charges
        NULL::text                                                             AS einvoice_status,  -- no viene de accesorios.charges
        NULL::text                                                             AS invoice_number,  -- no viene de accesorios.charges
        NULL::jsonb                                                            AS gateway_payload,  -- no viene de accesorios.charges
        'accesorios'::text AS _source_db, 'charges'::text AS _source_table, md5(concat_ws('|', r."codigo", r."adname", r."source", r."datein", r."amount", r."feature", r."cname", r."ctype", r."clast4", r."ip", r."approval")) AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__charges r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.payment (id, legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, listing_title_snapshot, channel, paid_at, amount, service_code, cardholder_name, card_brand, card_last4, authorization_code, gateway_response, invoice_name, invoice_email, invoice_id_type, invoice_id_number, einvoice_key, einvoice_message, einvoice_status, invoice_number, gateway_payload)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        listing_title_snapshot = EXCLUDED.listing_title_snapshot,
        channel = EXCLUDED.channel,
        paid_at = EXCLUDED.paid_at,
        amount = EXCLUDED.amount,
        service_code = EXCLUDED.service_code,
        cardholder_name = EXCLUDED.cardholder_name,
        card_brand = EXCLUDED.card_brand,
        card_last4 = EXCLUDED.card_last4,
        authorization_code = EXCLUDED.authorization_code,
        gateway_response = EXCLUDED.gateway_response,
        invoice_name = EXCLUDED.invoice_name,
        invoice_email = EXCLUDED.invoice_email,
        invoice_id_type = EXCLUDED.invoice_id_type,
        invoice_id_number = EXCLUDED.invoice_id_number,
        einvoice_key = EXCLUDED.einvoice_key,
        einvoice_message = EXCLUDED.einvoice_message,
        einvoice_status = EXCLUDED.einvoice_status,
        invoice_number = EXCLUDED.invoice_number,
        gateway_payload = EXCLUDED.gateway_payload,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.payment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.payment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'payment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_payment(bigint) IS 'stg_raw → stg_transform.payment (esqueleto v1 desde S2T)';
