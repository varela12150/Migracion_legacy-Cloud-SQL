-- ======================================================================
-- stg_transform.sp_transform_payment_log
-- stg_raw → stg_transform.payment_log  ·  Destino final: payments_db.payment_log
-- Lee: stg_raw.usedcars__chargeslog
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_payment_log(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_payment_log(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'payment_log');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__chargeslog)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.chargeslog  (sin PK en origen: _source_pk = md5 de todas las columnas)
    -- No se migran: ip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.chargeslog', md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime"))) AS id,
        md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime")) AS legacy_id,
        'usedcars.chargeslog'                                                  AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS listing_id,
        stg_control.fn_clean_text(r."adname"::text)                            AS listing_title_snapshot,
        stg_control.fn_to_timestamptz(r."datein")                              AS attempted_at,
        r."amount"::numeric(12,2)                                              AS amount,
        stg_control.fn_clean_text(r."fullorder"::text)                         AS order_reference,
        stg_control.fn_clean_text(r."response"::text)                          AS gateway_response_code,
        stg_control.fn_clean_text(r."avsresponse"::text)                       AS avs_result,
        stg_control.fn_clean_text(r."cvvresponse"::text)                       AS cvv_result,
        stg_control.fn_clean_text(r."responsetime"::text)                      AS response_time,
        'usedcars'::text AS _source_db, 'chargeslog'::text AS _source_table, md5(concat_ws('|', r."codigo", r."adname", r."datein", r."amount", r."fullorder", r."ip", r."response", r."avsresponse", r."cvvresponse", r."responsetime")) AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__chargeslog r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.payment_log (id, legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, listing_title_snapshot, attempted_at, amount, order_reference, gateway_response_code, avs_result, cvv_result, response_time)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        listing_title_snapshot = EXCLUDED.listing_title_snapshot,
        attempted_at = EXCLUDED.attempted_at,
        amount = EXCLUDED.amount,
        order_reference = EXCLUDED.order_reference,
        gateway_response_code = EXCLUDED.gateway_response_code,
        avs_result = EXCLUDED.avs_result,
        cvv_result = EXCLUDED.cvv_result,
        response_time = EXCLUDED.response_time,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.payment_log._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.payment_log._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'payment_log', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_payment_log(bigint) IS 'stg_raw → stg_transform.payment_log (esqueleto v1 desde S2T)';
