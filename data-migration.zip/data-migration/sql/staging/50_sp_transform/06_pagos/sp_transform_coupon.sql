-- ======================================================================
-- stg_transform.sp_transform_coupon
-- stg_raw → stg_transform.coupon  ·  Destino final: payments_db.coupon
-- Lee: stg_raw.usedcars__coupons + stg_raw.accesorios__coupons
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_coupon(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_coupon(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'coupon');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__coupons)
        + (SELECT count(*) FROM stg_raw.accesorios__coupons)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.coupons
    SELECT
        stg_control.fn_legacy_uuid('usedcars.coupons', r."ccoupon"::text)      AS id,
        r."ccoupon"::text                                                      AS legacy_id,
        'usedcars.coupons'                                                     AS legacy_source,
        upper(stg_control.fn_clean_text(r."ccoupon"))                          AS code,
        stg_control.fn_to_date(r."cactivedate")                                AS valid_from,
        stg_control.fn_to_date(r."cexpdate")                                   AS valid_to,
        stg_control.fn_to_date(r."cdateused")                                  AS used_at,
        stg_control.fn_legacy_uuid('listing', r."cadcode"::text)               AS listing_id,
        stg_control.fn_map_code('COUPON_TYPE', 'usedcars', r."ctype"::text)    AS coupon_type,
        stg_control.fn_clean_text(r."creference"::text)                        AS reference,
        'usedcars'::text AS _source_db, 'coupons'::text AS _source_table, r."ccoupon"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__coupons r
    UNION ALL
    -- ---- accesorios.coupons
    SELECT
        stg_control.fn_legacy_uuid('accesorios.coupons', r."ccoupon"::text)    AS id,
        r."ccoupon"::text                                                      AS legacy_id,
        'accesorios.coupons'                                                   AS legacy_source,
        upper(stg_control.fn_clean_text(r."ccoupon"))                          AS code,
        stg_control.fn_to_date(r."cactivedate")                                AS valid_from,
        stg_control.fn_to_date(r."cexpdate")                                   AS valid_to,
        stg_control.fn_to_date(r."cdateused")                                  AS used_at,
        stg_control.fn_legacy_uuid('listing', r."cadcode"::text)               AS listing_id,
        stg_control.fn_map_code('COUPON_TYPE', 'accesorios', r."ctype"::text)  AS coupon_type,
        stg_control.fn_clean_text(r."creference"::text)                        AS reference,
        'accesorios'::text AS _source_db, 'coupons'::text AS _source_table, r."ccoupon"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.accesorios__coupons r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.coupon (id, legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, code, valid_from, valid_to, used_at, listing_id, coupon_type, reference)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        code = EXCLUDED.code,
        valid_from = EXCLUDED.valid_from,
        valid_to = EXCLUDED.valid_to,
        used_at = EXCLUDED.used_at,
        listing_id = EXCLUDED.listing_id,
        coupon_type = EXCLUDED.coupon_type,
        reference = EXCLUDED.reference,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.coupon._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.coupon._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'coupon', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_coupon(bigint) IS 'stg_raw → stg_transform.coupon (esqueleto v1 desde S2T)';
