-- ======================================================================
-- stg_transform.sp_transform_prepayment
-- stg_raw → stg_transform.prepayment  ·  Destino final: payments_db.prepayment
-- Lee: stg_raw.usedcars__prepay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_prepayment(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_prepayment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'prepayment');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__prepay)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.prepay
    -- No se migran: ppip
    SELECT
        stg_control.fn_legacy_uuid('usedcars.prepay', concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal")) AS id,
        concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal")                 AS legacy_id,
        'usedcars.prepay'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."ppuser"::text)                            AS performed_by,
        stg_control.fn_legacy_uuid('usedcars.sellers', r."ppseller"::text) /* TODO: confirmar que sellers.sellercode es la PK del padre */ AS seller_id,
        stg_control.fn_map_code('PREPAY_TYPE', 'usedcars', r."ppttype"::text)  AS movement_type,
        stg_control.fn_to_timestamptz(r."ppdate")                              AS movement_at,
        r."ppamount"::numeric(12,2)                                            AS amount,
        stg_control.fn_clean_text(r."ppdetail"::text)                          AS detail,
        stg_control.fn_clean_text(r."ppcomment"::text)                         AS comment,
        r."ppprevbal"::numeric(12,2)                                           AS previous_balance,
        r."ppnewbal"::numeric(12,2)                                            AS new_balance,
        'usedcars'::text AS _source_db, 'prepay'::text AS _source_table, concat_ws('|', r."ppseller", r."ppdate", r."ppnewbal") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__prepay r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.prepayment (id, legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, performed_by, seller_id, movement_type, movement_at, amount, detail, comment, previous_balance, new_balance)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        performed_by = EXCLUDED.performed_by,
        seller_id = EXCLUDED.seller_id,
        movement_type = EXCLUDED.movement_type,
        movement_at = EXCLUDED.movement_at,
        amount = EXCLUDED.amount,
        detail = EXCLUDED.detail,
        comment = EXCLUDED.comment,
        previous_balance = EXCLUDED.previous_balance,
        new_balance = EXCLUDED.new_balance,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.prepayment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.prepayment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'prepayment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_prepayment(bigint) IS 'stg_raw → stg_transform.prepayment (esqueleto v1 desde S2T)';
