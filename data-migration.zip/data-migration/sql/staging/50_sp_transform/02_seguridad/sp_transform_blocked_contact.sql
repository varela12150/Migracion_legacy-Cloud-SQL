-- ======================================================================
-- stg_transform.sp_transform_blocked_contact
-- stg_raw → stg_transform.blocked_contact  ·  Destino final: users_db.blocked_contact
-- Lee: stg_raw.usedcars__blocked + stg_raw.usedcars__blockedemails + stg_raw.usedcars__blockedips + stg_raw.usedcars__blockedphones + stg_raw.usedcars__correosfraude
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_blocked_contact(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

-- Código de error usado por sp_transform_blocked_contact (error_record.rule_code tiene FK a validation_rule)
INSERT INTO stg_control.validation_rule (rule_code, entity, description, severity, is_active)
VALUES ('VAL_PK_MISSING', NULL, 'Llave de origen vacía: la fila no se puede identificar y se excluye', 'ERROR', true)
ON CONFLICT (rule_code) DO NOTHING;

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_blocked_contact(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
    v_err    bigint := 0;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'blocked_contact');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__blocked)
        + (SELECT count(*) FROM stg_raw.usedcars__blockedemails)
        + (SELECT count(*) FROM stg_raw.usedcars__blockedips)
        + (SELECT count(*) FROM stg_raw.usedcars__blockedphones)
        + (SELECT count(*) FROM stg_raw.usedcars__correosfraude)
      INTO v_in;

    -- FIX 13/11/2026: filas con llave de origen vacía → fn_legacy_uuid devuelve NULL e id NULL
    -- hacía fallar la entidad completa (23502). Se excluyen y se registran como VAL_PK_MISSING.
    CREATE TEMP TABLE IF NOT EXISTS tmp_bc_pk_missing (tbl text, col text, payload jsonb) ON COMMIT DROP;
    TRUNCATE tmp_bc_pk_missing;
    INSERT INTO tmp_bc_pk_missing
        SELECT 'blocked', 'blockedid', to_jsonb(r) FROM stg_raw.usedcars__blocked r
         WHERE nullif(trim(r."blockedid"::text), '') IS NULL
        UNION ALL
        SELECT 'blockedemails', 'blockedemail', to_jsonb(r) FROM stg_raw.usedcars__blockedemails r
         WHERE nullif(trim(r."blockedemail"::text), '') IS NULL
        UNION ALL
        SELECT 'blockedips', 'ip', to_jsonb(r) FROM stg_raw.usedcars__blockedips r
         WHERE nullif(trim(r."ip"::text), '') IS NULL
        UNION ALL
        SELECT 'blockedphones', 'blockedphone', to_jsonb(r) FROM stg_raw.usedcars__blockedphones r
         WHERE nullif(trim(r."blockedphone"::text), '') IS NULL
        UNION ALL
        SELECT 'correosfraude', 'codigo', to_jsonb(r) FROM stg_raw.usedcars__correosfraude r
         WHERE nullif(trim(r."codigo"::text), '') IS NULL;
    GET DIAGNOSTICS v_err = ROW_COUNT;

    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'blocked_contact', 'usedcars', m.tbl, NULL,
                                     'VAL_PK_MISSING', 'ERROR',
                                     'Llave de origen vacía (' || m.col || '): fila excluida', m.payload)
      FROM tmp_bc_pk_missing m;


    WITH src AS (
    -- ---- usedcars.blocked
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blocked', r."blockedid"::text)    AS id,
        r."blockedid"::text                                                    AS legacy_id,
        'usedcars.blocked'                                                     AS legacy_source,
        stg_control.fn_clean_text(r."blockedid"::text)                         AS blockedid,
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blocked
        NULL::text                                                             AS ip,  -- no viene de usedcars.blocked
        NULL::text                                                             AS reason,  -- no viene de usedcars.blocked
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blocked
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blocked
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blocked
        'usedcars'::text AS _source_db, 'blocked'::text AS _source_table, r."blockedid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__blocked r
    WHERE nullif(trim(r."blockedid"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.blockedemails
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedemails', r."blockedemail"::text) AS id,
        r."blockedemail"::text                                                 AS legacy_id,
        'usedcars.blockedemails'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedemails
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        stg_control.fn_clean_email(r."blockedemail")                           AS blockedemail,
        NULL::text                                                             AS ip,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS reason,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedemails
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedemails
        'usedcars'::text AS _source_db, 'blockedemails'::text AS _source_table, r."blockedemail"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__blockedemails r
    WHERE nullif(trim(r."blockedemail"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.blockedips
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedips', r."ip"::text)        AS id,
        r."ip"::text                                                           AS legacy_id,
        'usedcars.blockedips'                                                  AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS blockedname,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blockedips
        stg_control.fn_clean_text(r."ip"::text)                                AS ip,
        stg_control.fn_clean_text(r."reason"::text)                            AS reason,
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedips
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedips
        'usedcars'::text AS _source_db, 'blockedips'::text AS _source_table, r."ip"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__blockedips r
    WHERE nullif(trim(r."ip"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.blockedphones
    SELECT
        stg_control.fn_legacy_uuid('usedcars.blockedphones', r."blockedphone"::text) AS id,
        r."blockedphone"::text                                                 AS legacy_id,
        'usedcars.blockedphones'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.blockedphones
        stg_control.fn_clean_text(r."blockedname"::text)                       AS blockedname,
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS ip,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS reason,  -- no viene de usedcars.blockedphones
        stg_control.fn_clean_text(r."blockedphone"::text)                      AS blockedphone,
        NULL::text                                                             AS codigo,  -- no viene de usedcars.blockedphones
        NULL::text                                                             AS emailaddr,  -- no viene de usedcars.blockedphones
        'usedcars'::text AS _source_db, 'blockedphones'::text AS _source_table, r."blockedphone"::text AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__blockedphones r
    WHERE nullif(trim(r."blockedphone"::text), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.correosfraude
    SELECT
        stg_control.fn_legacy_uuid('usedcars.correosfraude', r."codigo"::text) AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.correosfraude'                                               AS legacy_source,
        NULL::text                                                             AS blockedid,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedname,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedemail,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS ip,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS reason,  -- no viene de usedcars.correosfraude
        NULL::text                                                             AS blockedphone,  -- no viene de usedcars.correosfraude
        stg_control.fn_clean_text(r."codigo"::text)                            AS codigo,
        stg_control.fn_clean_email(r."emailaddr")                              AS emailaddr,
        'usedcars'::text AS _source_db, 'correosfraude'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__correosfraude r
    WHERE nullif(trim(r."codigo"::text), '') IS NOT NULL
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.blocked_contact (id, legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, blockedid, blockedname, blockedemail, ip, reason, blockedphone, codigo, emailaddr)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        blockedid = EXCLUDED.blockedid,
        blockedname = EXCLUDED.blockedname,
        blockedemail = EXCLUDED.blockedemail,
        ip = EXCLUDED.ip,
        reason = EXCLUDED.reason,
        blockedphone = EXCLUDED.blockedphone,
        codigo = EXCLUDED.codigo,
        emailaddr = EXCLUDED.emailaddr,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.blocked_contact._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.blocked_contact._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, v_err, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'blocked_contact', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_blocked_contact(bigint) IS 'stg_raw → stg_transform.blocked_contact (esqueleto v1 desde S2T)';
