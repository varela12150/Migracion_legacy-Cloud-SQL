-- ======================================================================
-- stg_transform.sp_transform_special_deal
-- stg_raw → stg_transform.special_deal  ·  Destino final: listings_db.special_deal
-- Lee: stg_raw.usedcars__specialdeals
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_special_deal(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_special_deal(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'special_deal');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__specialdeals)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.specialdeals
    SELECT
        stg_control.fn_legacy_uuid('usedcars.specialdeals', concat_ws('|', r."adcode", r."ddate")) AS id,
        concat_ws('|', r."adcode", r."ddate")                                  AS legacy_id,
        'usedcars.specialdeals'                                                AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."adcode"::text)                AS listing_id,
        stg_control.fn_to_date(r."ddate")                                      AS deal_date,
        r."dprice"::numeric(14,2)                                              AS deal_price,
        'usedcars'::text AS _source_db, 'specialdeals'::text AS _source_table, concat_ws('|', r."adcode", r."ddate") AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__specialdeals r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.special_deal (id, legacy_id, legacy_source, listing_id, deal_date, deal_price,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, deal_date, deal_price,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, deal_date, deal_price)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        deal_date = EXCLUDED.deal_date,
        deal_price = EXCLUDED.deal_price,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.special_deal._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.special_deal._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'special_deal', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_special_deal(bigint) IS 'stg_raw → stg_transform.special_deal (esqueleto v1 desde S2T)';
