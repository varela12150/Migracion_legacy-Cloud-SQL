-- ======================================================================
-- stg_transform.sp_transform_banner
-- stg_raw → stg_transform.banner  ·  Destino final: listings_db.banner
-- Lee: stg_raw.newcars__mainbanners
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_banner(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_banner(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'banner');

    SELECT (SELECT count(*) FROM stg_raw.newcars__mainbanners)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.mainbanners
    SELECT
        stg_control.fn_legacy_uuid('newcars.mainbanners', r."codigo"::text)    AS id,
        r."codigo"::text                                                       AS legacy_id,
        'newcars.mainbanners'                                                  AS legacy_source,
        stg_control.fn_clean_text(r."client"::text)                            AS client_name,
        r."filename"::text                                                     AS image_s3_key,
        stg_control.fn_clean_text(r."link"::text)                              AS link_url,
        stg_control.fn_clean_text(r."mobilelink"::text)                        AS mobile_link_url,
        stg_control.fn_clean_text(r."target"::text)                            AS link_target,
        stg_control.fn_to_date(r."startdate")                                  AS start_date,
        stg_control.fn_to_date(r."enddate")                                    AS end_date,
        'newcars'::text AS _source_db, 'mainbanners'::text AS _source_table, r."codigo"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.newcars__mainbanners r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.banner (id, legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, client_name, image_s3_key, link_url, mobile_link_url, link_target, start_date, end_date)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        client_name = EXCLUDED.client_name,
        image_s3_key = EXCLUDED.image_s3_key,
        link_url = EXCLUDED.link_url,
        mobile_link_url = EXCLUDED.mobile_link_url,
        link_target = EXCLUDED.link_target,
        start_date = EXCLUDED.start_date,
        end_date = EXCLUDED.end_date,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.banner._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.banner._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'banner', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_banner(bigint) IS 'stg_raw → stg_transform.banner (esqueleto v1 desde S2T)';
