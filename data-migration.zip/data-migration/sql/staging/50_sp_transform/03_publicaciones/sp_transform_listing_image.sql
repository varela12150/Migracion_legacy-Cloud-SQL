-- ======================================================================
-- stg_transform.sp_transform_listing_image
-- stg_raw → stg_transform.listing_image  ·  Destino final: listings_db.listing_image
-- Lee: stg_raw.usedcars__datafile + stg_raw.usedcars__archive + stg_raw.usedcars__expiredsellers + stg_raw.usedcars__pending + stg_raw.usedcars__pendingpay + stg_raw.usedcars__archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_image(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_image(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_image');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__datafile)
        + (SELECT count(*) FROM stg_raw.usedcars__archive)
        + (SELECT count(*) FROM stg_raw.usedcars__expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars__pending)
        + (SELECT count(*) FROM stg_raw.usedcars__pendingpay)
        + (SELECT count(*) FROM stg_raw.usedcars__archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.datafile'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__datafile r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.archive: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archive'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__archive r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.expiredsellers: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.expiredsellers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__expiredsellers r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.pending: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pending'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__pending r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.pendingpay: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pendingpay'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__pendingpay r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    UNION ALL
    -- ---- usedcars.archivetraspaso: una fila por foto no vacía (foto, foto2, foto3, foto4, foto5)
    SELECT
        stg_control.fn_legacy_uuid('listing_image', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archivetraspaso'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_image_s3_key(v.file)                        AS s3_key,   -- TODO: convención de rutas S3 (proceso de imágenes)
        v.n::smallint                                              AS sort_order,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 6 AS _prio
    FROM stg_raw.usedcars__archivetraspaso r
    CROSS JOIN LATERAL (VALUES (1, r."foto"::text), (2, r."foto2"::text), (3, r."foto3"::text), (4, r."foto4"::text), (5, r."foto5"::text)) AS v(n, file)
    WHERE nullif(trim(v.file), '') IS NOT NULL
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_image (id, legacy_id, legacy_source, listing_id, s3_key, sort_order,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, s3_key, sort_order,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, s3_key, sort_order)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        s3_key = EXCLUDED.s3_key,
        sort_order = EXCLUDED.sort_order,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_image._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_image._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_image', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_image(bigint) IS 'stg_raw → stg_transform.listing_image (esqueleto v1 desde S2T)';
