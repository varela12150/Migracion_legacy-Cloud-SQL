-- ======================================================================
-- stg_transform.sp_transform_listing
-- stg_raw → stg_transform.listing  ·  Destino final: listings_db.listing
-- Lee: stg_raw.usedcars__datafile + stg_raw.usedcars__archive + stg_raw.usedcars__expiredsellers + stg_raw.usedcars__pending + stg_raw.usedcars__pendingpay
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__datafile)
        + (SELECT count(*) FROM stg_raw.usedcars__archive)
        + (SELECT count(*) FROM stg_raw.usedcars__expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars__pending)
        + (SELECT count(*) FROM stg_raw.usedcars__pendingpay)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.datafile'                                                    AS legacy_source,
        'ACTIVE'                                                               AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__datafile r
    UNION ALL
    -- ---- usedcars.archive
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.archive'                                                     AS legacy_source,
        'ARCHIVED'                                                             AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__archive r
    UNION ALL
    -- ---- usedcars.expiredsellers
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.expiredsellers'                                              AS legacy_source,
        'EXPIRED'                                                              AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__expiredsellers r
    UNION ALL
    -- ---- usedcars.pending
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.pending'                                                     AS legacy_source,
        'PENDING_APPROVAL'                                                     AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__pending r
    UNION ALL
    -- ---- usedcars.pendingpay
    -- No se migran: pwd, compareactive, comparepending, comparehistory, favcount, cchash
    SELECT
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                AS id,
        r."codigo"::text                                                       AS legacy_id,
        'usedcars.pendingpay'                                                  AS legacy_source,
        'PENDING_PAYMENT'                                                      AS publication_lifecycle,
        r."refcode"::text                                                      AS reference_code,
        NULL::uuid                                                             AS dealer_id,  -- POR CONFIRMAR · TODO: Lookup a dealer
        stg_control.fn_map_id('BRAND', 'usedcars', r."marca"::text)            AS brand_id,
        stg_control.fn_clean_text(r."modelo"::text)                            AS model_name,
        stg_control.fn_clean_text(r."motor"::text)                             AS engine,
        stg_control.fn_to_int(r."ano"::text)::smallint                         AS year,
        stg_control.fn_legacy_uuid('usedcars.styles', r."estilo"::text)        AS body_style_id,
        r."numpas"::smallint                                                   AS passengers,
        r."precio"::numeric(14,2)                                              AS price,
        r."precio2"::numeric(14,2)                                             AS previous_price,  -- POR CONFIRMAR
        r."dexchrate"::numeric(10,2)                                           AS exchange_rate,
        r."traspaso"::numeric(14,2)                                            AS transfer_cost,  -- POR CONFIRMAR
        stg_control.fn_map_code('LISTING_ESTADO', 'usedcars', r."estado"::text) AS condition_code,
        stg_control.fn_clean_text(r."color"::text)                             AS exterior_color,
        stg_control.fn_clean_phone_cr(r."telefono")                            AS contact_phone,
        stg_control.fn_clean_phone_cr(r."whatsapp")                            AS contact_whatsapp,
        stg_control.fn_clean_email(r."email")                                  AS contact_email,
        stg_control.fn_clean_text(r."coment"::text)                            AS summary,
        stg_control.fn_clean_text(r."coment2"::text)                           AS description,
        stg_control.fn_clean_text(r."aiassist"::text)                          AS ai_description,
        stg_control.fn_clean_text(r."nombre"::text)                            AS contact_name,
        r."numpics"::smallint                                                  AS image_count,
        stg_control.fn_map_code('FUEL_TYPE', 'usedcars', r."combustibl"::text) AS fuel_type,
        r."erange"::numeric(8,1)                                               AS ev_range,
        stg_control.fn_map_code('RANGE_UNIT', 'usedcars', r."rangetype"::text) AS ev_range_unit,
        r."kwh"::numeric(6,1)                                                  AS battery_kwh,
        stg_control.fn_map_code('TRANSMISSION', 'usedcars', r."transmisio"::text) AS transmission,
        stg_control.fn_map_code('LISTING_STATUS', 'usedcars', r."status"::text) AS publication_status,
        r."mileage"::integer                                                   AS mileage,
        stg_control.fn_map_code('MILEAGE_UNIT', 'usedcars', r."mileagetype"::text) AS mileage_unit,
        stg_control.fn_map_code('LISTING_SOURCE', 'usedcars', r."source"::text) AS source_channel,
        stg_control.fn_to_timestamptz(r."datein")                              AS created_at,
        stg_control.fn_to_date(r."expdate")                                    AS expires_at,
        r."option1"::text                                                      AS option_1,  -- POR CONFIRMAR
        r."option2"::text                                                      AS option_2,  -- POR CONFIRMAR
        r."option3"::text                                                      AS option_3,  -- POR CONFIRMAR
        r."option4"::text                                                      AS option_4,  -- POR CONFIRMAR
        r."option5"::text                                                      AS option_5,  -- POR CONFIRMAR
        r."option6"::text                                                      AS option_6,  -- POR CONFIRMAR
        r."option7"::text                                                      AS option_7,  -- POR CONFIRMAR
        r."option8"::text                                                      AS option_8,  -- POR CONFIRMAR
        r."option9"::text                                                      AS option_9,  -- POR CONFIRMAR
        r."option10"::text                                                     AS option_10,  -- POR CONFIRMAR
        r."visits"::integer                                                    AS visit_count,
        stg_control.fn_to_bool(r."interior360"::text)                          AS has_interior_360,
        stg_control.fn_clean_text(r."videoname"::text)                         AS video_url,
        stg_control.fn_clean_text(r."color2"::text)                            AS interior_color,
        stg_control.fn_to_bool(r."negotiable"::text)                           AS is_negotiable,
        stg_control.fn_to_bool(r."registered"::text)                           AS is_registered,  -- POR CONFIRMAR
        stg_control.fn_clean_text(r."tag"::text)                               AS plate,
        stg_control.fn_to_int(r."numdoors"::text)::smallint                    AS doors,
        stg_control.fn_legacy_uuid('usedcars.provinces', r."province"::text)   AS province_id,
        stg_control.fn_to_bool(r."recibe"::text)                               AS accepts_trade_in,  -- POR CONFIRMAR
        upper(stg_control.fn_clean_text(r."vin"))                              AS vin,
        stg_control.fn_clean_text(r."appby"::text)                             AS approved_by,
        stg_control.fn_clean_text(r."delby"::text)                             AS deleted_by,
        stg_control.fn_to_timestamptz(r."deldate")                             AS deleted_at,
        stg_control.fn_to_bool(r."blocked"::text)                              AS is_blocked,
        stg_control.fn_clean_text(r."blockedreason"::text)                     AS blocked_reason,
        stg_control.fn_clean_text(r."blockedby"::text)                         AS blocked_by,
        stg_control.fn_map_code('CURRENCY', 'usedcars', r."currency"::text)    AS currency,
        stg_control.fn_to_bool(r."premium"::text)                              AS is_premium,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__pendingpay r
    ),
    dedup AS (
    -- Un mismo codigo puede existir en varias tablas del ciclo de vida: gana la de menor _prio
    -- (datafile > archive > expiredsellers > pending > pendingpay) y, dentro de la misma, el último cambio DMS.
    -- Los duplicados reales se reportan en sp_validate (regla VAL_LISTING_DUP_LIFECYCLE).
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing (id, legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, publication_lifecycle, reference_code, dealer_id, brand_id, model_name, engine, year, body_style_id, passengers, price, previous_price, exchange_rate, transfer_cost, condition_code, exterior_color, contact_phone, contact_whatsapp, contact_email, summary, description, ai_description, contact_name, image_count, fuel_type, ev_range, ev_range_unit, battery_kwh, transmission, publication_status, mileage, mileage_unit, source_channel, created_at, expires_at, option_1, option_2, option_3, option_4, option_5, option_6, option_7, option_8, option_9, option_10, visit_count, has_interior_360, video_url, interior_color, is_negotiable, is_registered, plate, doors, province_id, accepts_trade_in, vin, approved_by, deleted_by, deleted_at, is_blocked, blocked_reason, blocked_by, currency, is_premium)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        publication_lifecycle = EXCLUDED.publication_lifecycle,
        reference_code = EXCLUDED.reference_code,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        model_name = EXCLUDED.model_name,
        engine = EXCLUDED.engine,
        year = EXCLUDED.year,
        body_style_id = EXCLUDED.body_style_id,
        passengers = EXCLUDED.passengers,
        price = EXCLUDED.price,
        previous_price = EXCLUDED.previous_price,
        exchange_rate = EXCLUDED.exchange_rate,
        transfer_cost = EXCLUDED.transfer_cost,
        condition_code = EXCLUDED.condition_code,
        exterior_color = EXCLUDED.exterior_color,
        contact_phone = EXCLUDED.contact_phone,
        contact_whatsapp = EXCLUDED.contact_whatsapp,
        contact_email = EXCLUDED.contact_email,
        summary = EXCLUDED.summary,
        description = EXCLUDED.description,
        ai_description = EXCLUDED.ai_description,
        contact_name = EXCLUDED.contact_name,
        image_count = EXCLUDED.image_count,
        fuel_type = EXCLUDED.fuel_type,
        ev_range = EXCLUDED.ev_range,
        ev_range_unit = EXCLUDED.ev_range_unit,
        battery_kwh = EXCLUDED.battery_kwh,
        transmission = EXCLUDED.transmission,
        publication_status = EXCLUDED.publication_status,
        mileage = EXCLUDED.mileage,
        mileage_unit = EXCLUDED.mileage_unit,
        source_channel = EXCLUDED.source_channel,
        created_at = EXCLUDED.created_at,
        expires_at = EXCLUDED.expires_at,
        option_1 = EXCLUDED.option_1,
        option_2 = EXCLUDED.option_2,
        option_3 = EXCLUDED.option_3,
        option_4 = EXCLUDED.option_4,
        option_5 = EXCLUDED.option_5,
        option_6 = EXCLUDED.option_6,
        option_7 = EXCLUDED.option_7,
        option_8 = EXCLUDED.option_8,
        option_9 = EXCLUDED.option_9,
        option_10 = EXCLUDED.option_10,
        visit_count = EXCLUDED.visit_count,
        has_interior_360 = EXCLUDED.has_interior_360,
        video_url = EXCLUDED.video_url,
        interior_color = EXCLUDED.interior_color,
        is_negotiable = EXCLUDED.is_negotiable,
        is_registered = EXCLUDED.is_registered,
        plate = EXCLUDED.plate,
        doors = EXCLUDED.doors,
        province_id = EXCLUDED.province_id,
        accepts_trade_in = EXCLUDED.accepts_trade_in,
        vin = EXCLUDED.vin,
        approved_by = EXCLUDED.approved_by,
        deleted_by = EXCLUDED.deleted_by,
        deleted_at = EXCLUDED.deleted_at,
        is_blocked = EXCLUDED.is_blocked,
        blocked_reason = EXCLUDED.blocked_reason,
        blocked_by = EXCLUDED.blocked_by,
        currency = EXCLUDED.currency,
        is_premium = EXCLUDED.is_premium,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing(bigint) IS 'stg_raw → stg_transform.listing (esqueleto v1 desde S2T)';
