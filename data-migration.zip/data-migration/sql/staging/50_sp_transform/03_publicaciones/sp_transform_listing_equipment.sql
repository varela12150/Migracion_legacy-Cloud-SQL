-- ======================================================================
-- stg_transform.sp_transform_listing_equipment
-- stg_raw → stg_transform.listing_equipment  ·  Destino final: listings_db.listing_equipment
-- Lee: stg_raw.usedcars__datafile + stg_raw.usedcars__archive + stg_raw.usedcars__expiredsellers + stg_raw.usedcars__pending + stg_raw.usedcars__pendingpay + stg_raw.usedcars__archivetraspaso
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_listing_equipment(p_run_id);
-- Entidad PIVOT: una fila origen genera N filas destino (LATERAL VALUES).
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_listing_equipment(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'listing_equipment');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__datafile)
        + (SELECT count(*) FROM stg_raw.usedcars__archive)
        + (SELECT count(*) FROM stg_raw.usedcars__expiredsellers)
        + (SELECT count(*) FROM stg_raw.usedcars__pending)
        + (SELECT count(*) FROM stg_raw.usedcars__pendingpay)
        + (SELECT count(*) FROM stg_raw.usedcars__archivetraspaso)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.datafile: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.datafile'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'datafile'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__datafile r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.archive: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archive'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'archive'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.usedcars__archive r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.expiredsellers: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.expiredsellers'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'expiredsellers'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__expiredsellers r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.pending: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pending'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'pending'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 4 AS _prio
    FROM stg_raw.usedcars__pending r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.pendingpay: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.pendingpay'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'pendingpay'::text AS _source_table, r."refcode"::text || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 5 AS _prio
    FROM stg_raw.usedcars__pendingpay r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    UNION ALL
    -- ---- usedcars.archivetraspaso: unpivot f1..f40 (lógica de CheckEquipment pendiente de Q07)
    SELECT
        stg_control.fn_legacy_uuid('listing_equipment', r."codigo"::text || '|' || v.n) AS id,
        r."codigo"::text || '|' || v.n                             AS legacy_id,
        'usedcars.archivetraspaso'::text                                            AS legacy_source,
        stg_control.fn_legacy_uuid('listing', r."codigo"::text)                                                   AS listing_id,
        stg_control.fn_legacy_uuid('usedcars.carextras', v.n::text) AS equipment_id,  -- TODO Q07: confirmar f<N> ↔ carextras.idextra
        v.n::smallint                                              AS feature_slot,
        'usedcars'::text AS _source_db, 'archivetraspaso'::text AS _source_table, concat_ws('|', r."refcode", r."codigo") || '|' || v.n AS _source_pk,
        r._dms_op, r._dms_ts, 6 AS _prio
    FROM stg_raw.usedcars__archivetraspaso r
    CROSS JOIN LATERAL (VALUES (1, r."f1"::text), (2, r."f2"::text), (3, r."f3"::text), (4, r."f4"::text), (5, r."f5"::text), (6, r."f6"::text), (7, r."f7"::text), (8, r."f8"::text), (9, r."f9"::text), (10, r."f10"::text), (11, r."f11"::text), (12, r."f12"::text), (13, r."f13"::text), (14, r."f14"::text), (15, r."f15"::text), (16, r."f16"::text), (17, r."f17"::text), (18, r."f18"::text), (19, r."f19"::text), (20, r."f20"::text), (21, r."f21"::text), (22, r."f22"::text), (23, r."f23"::text), (24, r."f24"::text), (25, r."f25"::text), (26, r."f26"::text), (27, r."f27"::text), (28, r."f28"::text), (29, r."f29"::text), (30, r."f30"::text), (31, r."f31"::text), (32, r."f32"::text), (33, r."f33"::text), (34, r."f34"::text), (35, r."f35"::text), (36, r."f36"::text), (37, r."f37"::text), (38, r."f38"::text), (39, r."f39"::text), (40, r."f40"::text)) AS v(n, val)
    WHERE stg_control.fn_equipment_present(v.val)            -- TODO Q07: qué valor indica "tiene el equipamiento"
    ),
    dedup AS (
        SELECT DISTINCT ON (id) * FROM src ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.listing_equipment (id, legacy_id, legacy_source, listing_id, equipment_id, feature_slot,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, listing_id, equipment_id, feature_slot,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, listing_id, equipment_id, feature_slot)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        listing_id = EXCLUDED.listing_id,
        equipment_id = EXCLUDED.equipment_id,
        feature_slot = EXCLUDED.feature_slot,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.listing_equipment._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.listing_equipment._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'listing_equipment', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_listing_equipment(bigint) IS 'stg_raw → stg_transform.listing_equipment (esqueleto v1 desde S2T)';
