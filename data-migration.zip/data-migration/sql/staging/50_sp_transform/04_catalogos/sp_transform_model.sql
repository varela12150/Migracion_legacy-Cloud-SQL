-- ======================================================================
-- stg_transform.sp_transform_model
-- stg_raw → stg_transform.model  ·  Destino final: listings_db.model
-- Lee: stg_raw.newcars__models
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_model(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_model(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'model');

    SELECT (SELECT count(*) FROM stg_raw.newcars__models)
      INTO v_in;

    WITH src AS (
    -- ---- newcars.models
    SELECT
        stg_control.fn_legacy_uuid('newcars.models', r."mcode"::text)          AS id,
        r."mcode"::text                                                        AS legacy_id,
        'newcars.models'                                                       AS legacy_source,
        stg_control.fn_legacy_uuid('newcars.dealers', r."mdealer"::text)       AS dealer_id,
        stg_control.fn_legacy_uuid('newcars.brands', r."mbrand"::text)         AS brand_id,
        stg_control.fn_clean_text(r."mbasemodel"::text)                        AS base_model,
        stg_control.fn_legacy_uuid('newcars.styles', r."mstyle"::text)         AS body_style_id,
        r."mpicscode"::text                                                    AS image_prefix,
        stg_control.fn_to_int(r."myear"::text)::smallint                       AS year,
        r."mprice"::numeric(14,2)                                              AS price,
        stg_control.fn_clean_text(r."mdescrip"::text)                          AS mdescrip,
        stg_control.fn_clean_text(r."motherspecs"::text)                       AS motherspecs,
        stg_control.fn_clean_text(r."mmaintext"::text)                         AS mmaintext,
        r."mnumpics"::integer                                                  AS mnumpics,
        r."mnumvideos"::integer                                                AS mnumvideos,
        stg_control.fn_clean_text(r."mequipment"::text)                        AS mequipment,
        stg_control.fn_clean_text(r."mmotor"::text)                            AS mmotor,
        r."menginesize"::integer                                               AS menginesize,
        stg_control.fn_clean_text(r."mpower"::text)                            AS mpower,
        stg_control.fn_clean_text(r."mtorque"::text)                           AS mtorque,
        stg_control.fn_clean_text(r."msuspension"::text)                       AS msuspension,
        stg_control.fn_clean_text(r."msteering"::text)                         AS msteering,
        stg_control.fn_clean_text(r."mtransmission"::text)                     AS mtransmission,
        stg_control.fn_clean_text(r."mtransmission2"::text)                    AS mtransmission2,
        stg_control.fn_clean_text(r."mbrakes"::text)                           AS mbrakes,
        stg_control.fn_clean_text(r."mtires"::text)                            AS mtires,
        stg_control.fn_clean_text(r."mwarranty"::text)                         AS mwarranty,
        stg_control.fn_clean_text(r."mfuel"::text)                             AS mfuel,
        stg_control.fn_clean_text(r."mdrive"::text)                            AS mdrive,
        stg_control.fn_clean_text(r."mfueltank"::text)                         AS mfueltank,
        stg_control.fn_clean_text(r."mmaxspeed"::text)                         AS mmaxspeed,
        r."mvalves"::integer                                                   AS mvalves,
        r."mdoors"::integer                                                    AS mdoors,
        stg_control.fn_to_bool(r."mvisible"::text)                             AS is_visible,
        stg_control.fn_clean_text(r."mweight"::text)                           AS mweight,
        stg_control.fn_clean_text(r."mheight"::text)                           AS mheight,
        stg_control.fn_clean_text(r."mwidth"::text)                            AS mwidth,
        stg_control.fn_clean_text(r."mlength"::text)                           AS mlength,
        stg_control.fn_clean_text(r."mdiameter"::text)                         AS mdiameter,
        stg_control.fn_clean_text(r."mvideo1"::text)                           AS mvideo1,
        'newcars'::text AS _source_db, 'models'::text AS _source_table, r."mcode"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.newcars__models r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.model (id, legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, dealer_id, brand_id, base_model, body_style_id, image_prefix, year, price, mdescrip, motherspecs, mmaintext, mnumpics, mnumvideos, mequipment, mmotor, menginesize, mpower, mtorque, msuspension, msteering, mtransmission, mtransmission2, mbrakes, mtires, mwarranty, mfuel, mdrive, mfueltank, mmaxspeed, mvalves, mdoors, is_visible, mweight, mheight, mwidth, mlength, mdiameter, mvideo1)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        dealer_id = EXCLUDED.dealer_id,
        brand_id = EXCLUDED.brand_id,
        base_model = EXCLUDED.base_model,
        body_style_id = EXCLUDED.body_style_id,
        image_prefix = EXCLUDED.image_prefix,
        year = EXCLUDED.year,
        price = EXCLUDED.price,
        mdescrip = EXCLUDED.mdescrip,
        motherspecs = EXCLUDED.motherspecs,
        mmaintext = EXCLUDED.mmaintext,
        mnumpics = EXCLUDED.mnumpics,
        mnumvideos = EXCLUDED.mnumvideos,
        mequipment = EXCLUDED.mequipment,
        mmotor = EXCLUDED.mmotor,
        menginesize = EXCLUDED.menginesize,
        mpower = EXCLUDED.mpower,
        mtorque = EXCLUDED.mtorque,
        msuspension = EXCLUDED.msuspension,
        msteering = EXCLUDED.msteering,
        mtransmission = EXCLUDED.mtransmission,
        mtransmission2 = EXCLUDED.mtransmission2,
        mbrakes = EXCLUDED.mbrakes,
        mtires = EXCLUDED.mtires,
        mwarranty = EXCLUDED.mwarranty,
        mfuel = EXCLUDED.mfuel,
        mdrive = EXCLUDED.mdrive,
        mfueltank = EXCLUDED.mfueltank,
        mmaxspeed = EXCLUDED.mmaxspeed,
        mvalves = EXCLUDED.mvalves,
        mdoors = EXCLUDED.mdoors,
        is_visible = EXCLUDED.is_visible,
        mweight = EXCLUDED.mweight,
        mheight = EXCLUDED.mheight,
        mwidth = EXCLUDED.mwidth,
        mlength = EXCLUDED.mlength,
        mdiameter = EXCLUDED.mdiameter,
        mvideo1 = EXCLUDED.mvideo1,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.model._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.model._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'model', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_model(bigint) IS 'stg_raw → stg_transform.model (esqueleto v1 desde S2T)';
