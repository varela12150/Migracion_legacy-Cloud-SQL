-- ======================================================================
-- stg_transform.sp_transform_brand
-- stg_raw → stg_transform.brand  ·  Destino final: listings_db.brand
-- Lee: stg_raw.usedcars__brands + stg_raw.newcars__brands + stg_raw.usedcars__premiumbrands
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_brand(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_brand(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'brand');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__brands)
        + (SELECT count(*) FROM stg_raw.newcars__brands)
        + (SELECT count(*) FROM stg_raw.usedcars__premiumbrands)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.brands
    SELECT
        stg_control.fn_legacy_uuid('usedcars.brands', r."brandid"::text)       AS id,
        r."brandid"::text                                                      AS legacy_id,
        'usedcars.brands'                                                      AS legacy_source,
        stg_control.fn_clean_text(r."brandname"::text)                         AS name,
        NULL::text                                                             AS status,  -- no viene de usedcars.brands
        NULL::text                                                             AS video_url,  -- no viene de usedcars.brands
        NULL::text                                                             AS expo_status,  -- no viene de usedcars.brands
        NULL::uuid                                                             AS brand_id,  -- no viene de usedcars.brands
        NULL::smallint                                                         AS premium_min_year,  -- no viene de usedcars.brands
        NULL::numeric(14,2)                                                    AS premium_min_price,  -- no viene de usedcars.brands
        'usedcars'::text AS _source_db, 'brands'::text AS _source_table, r."brandid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__brands r
    UNION ALL
    -- ---- newcars.brands
    -- No se migran: branddir
    SELECT
        stg_control.fn_legacy_uuid('newcars.brands', r."brandid"::text)        AS id,
        r."brandid"::text                                                      AS legacy_id,
        'newcars.brands'                                                       AS legacy_source,
        stg_control.fn_clean_text(r."brandname"::text)                         AS name,
        stg_control.fn_map_code('BRAND_STATUS', 'newcars', r."status"::text)   AS status,
        stg_control.fn_clean_text(r."video1"::text)                            AS video_url,
        stg_control.fn_map_code('BRAND_STATUS', 'newcars', r."expostatus"::text) AS expo_status,
        NULL::uuid                                                             AS brand_id,  -- no viene de newcars.brands
        NULL::smallint                                                         AS premium_min_year,  -- no viene de newcars.brands
        NULL::numeric(14,2)                                                    AS premium_min_price,  -- no viene de newcars.brands
        'newcars'::text AS _source_db, 'brands'::text AS _source_table, r."brandid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 2 AS _prio
    FROM stg_raw.newcars__brands r
    UNION ALL
    -- ---- usedcars.premiumbrands
    SELECT
        stg_control.fn_legacy_uuid('usedcars.premiumbrands', r."premiumid"::text) AS id,
        r."premiumid"::text                                                    AS legacy_id,
        'usedcars.premiumbrands'                                               AS legacy_source,
        NULL::text                                                             AS name,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS status,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS video_url,  -- no viene de usedcars.premiumbrands
        NULL::text                                                             AS expo_status,  -- no viene de usedcars.premiumbrands
        NULL::uuid                                                             AS brand_id,  -- POR CONFIRMAR · TODO: Lookup brand por premiumid = usedcars.brands.brandid
        stg_control.fn_to_int(r."minyear"::text)::smallint                     AS premium_min_year,
        r."minprice"::numeric(14,2)                                            AS premium_min_price,
        'usedcars'::text AS _source_db, 'premiumbrands'::text AS _source_table, r."premiumid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 3 AS _prio
    FROM stg_raw.usedcars__premiumbrands r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.brand (id, legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name, status, video_url, expo_status, brand_id, premium_min_year, premium_min_price)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        status = EXCLUDED.status,
        video_url = EXCLUDED.video_url,
        expo_status = EXCLUDED.expo_status,
        brand_id = EXCLUDED.brand_id,
        premium_min_year = EXCLUDED.premium_min_year,
        premium_min_price = EXCLUDED.premium_min_price,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.brand._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.brand._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'brand', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_brand(bigint) IS 'stg_raw → stg_transform.brand (esqueleto v1 desde S2T)';
