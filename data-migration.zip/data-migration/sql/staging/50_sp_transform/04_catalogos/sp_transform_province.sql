-- ======================================================================
-- stg_transform.sp_transform_province
-- stg_raw → stg_transform.province  ·  Destino final: listings_db.province
-- Lee: stg_raw.usedcars__provinces
-- ESQUELETO v1: expresiones generadas desde la S2T. Revisar las marcadas TODO / POR CONFIRMAR.
-- Idempotente: UUID v5 determinístico + ON CONFLICT con _row_hash (re-ejecutar no duplica).
-- No valida: las reglas de calidad (formatos, FK, rangos) van en sp_validate.
-- Uso: CALL stg_transform.sp_transform_province(p_run_id);
-- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026 · Generado desde Avance_T15-T18_Diseno.xlsx (S2T v1)
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_province(p_run_id bigint)
LANGUAGE plpgsql
AS $$
DECLARE
    v_step   bigint;
    v_in     bigint;
    v_ok     bigint;
BEGIN
    v_step := stg_control.fn_step_start(p_run_id, 'sp_transform', 'province');

    SELECT (SELECT count(*) FROM stg_raw.usedcars__provinces)
      INTO v_in;

    WITH src AS (
    -- ---- usedcars.provinces
    SELECT
        stg_control.fn_legacy_uuid('usedcars.provinces', r."provinceid"::text) AS id,
        r."provinceid"::text                                                   AS legacy_id,
        'usedcars.provinces'                                                   AS legacy_source,
        stg_control.fn_clean_text(r."provincename"::text)                      AS name,
        'usedcars'::text AS _source_db, 'provinces'::text AS _source_table, r."provinceid"::text AS _source_pk,
        r._dms_op, r._dms_ts, 1 AS _prio
    FROM stg_raw.usedcars__provinces r
    ),
    dedup AS (
    SELECT DISTINCT ON (id) * FROM src
        ORDER BY id, _prio, _dms_ts DESC NULLS LAST
    )
    INSERT INTO stg_transform.province (id, legacy_id, legacy_source, name,
        _run_id, _source_db, _source_table, _source_pk, _row_hash, _is_deleted)
    SELECT id, legacy_id, legacy_source, name,
        p_run_id, _source_db, _source_table, _source_pk,
        md5(row(legacy_id, legacy_source, name)::text),
        coalesce(_dms_op = 'D', false)
    FROM dedup
    ON CONFLICT (id) DO UPDATE SET
        legacy_id = EXCLUDED.legacy_id,
        legacy_source = EXCLUDED.legacy_source,
        name = EXCLUDED.name,
        _run_id = EXCLUDED._run_id,
        _source_db = EXCLUDED._source_db,
        _source_table = EXCLUDED._source_table,
        _source_pk = EXCLUDED._source_pk,
        _row_hash = EXCLUDED._row_hash,
        _is_deleted = EXCLUDED._is_deleted,
        _transformed_at = now()
    WHERE stg_transform.province._row_hash IS DISTINCT FROM EXCLUDED._row_hash
       OR stg_transform.province._is_deleted <> EXCLUDED._is_deleted;

    GET DIAGNOSTICS v_ok = ROW_COUNT;
    PERFORM stg_control.fn_step_end(v_step, v_in, v_ok, 0, 0, 'SUCCESS', NULL);

EXCEPTION WHEN OTHERS THEN
    -- El orquestador hace COMMIT por entidad: el error queda registrado y se continúa con la siguiente.
    PERFORM stg_control.fn_step_end(v_step, v_in, 0, NULL, NULL, 'FAILED', SQLSTATE || ' ' || SQLERRM);
    PERFORM stg_control.fn_log_error(p_run_id, 'sp_transform', 'province', NULL, NULL, NULL, 'SP_FAILED', 'ERROR',
                                     SQLSTATE || ' ' || SQLERRM, NULL);
END;
$$;

COMMENT ON PROCEDURE stg_transform.sp_transform_province(bigint) IS 'stg_raw → stg_transform.province (esqueleto v1 desde S2T)';
