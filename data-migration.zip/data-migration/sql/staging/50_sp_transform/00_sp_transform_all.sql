-- ======================================================================
-- stg_transform.sp_transform_all · Orquestador stg_raw → stg_transform
-- Orden: catálogos → usuarios → publicaciones → relaciones de usuario → seguridad → pagos.
-- Como los UUID son determinísticos, el orden no es obligatorio para transformar;
-- sí lo es para sp_validate (FK contra la entidad padre ya transformada).
-- COMMIT por entidad: si una falla, queda FAILED en step_log y se sigue con la siguiente.
-- Uso (fuera de un bloque de transacción):  CALL stg_transform.sp_transform_all(NULL);
-- -- Proyecto: Migración de datos CRAutos · Historia DATA-02/DATA-03 · Modelo de staging v1
-- Autor: Andrés Varela (Ingeniería de Datos) · 23/10/2026
-- ======================================================================

CREATE OR REPLACE PROCEDURE stg_transform.sp_transform_all(p_run_id bigint DEFAULT NULL, p_run_type text DEFAULT 'FULL')
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_run_id IS NULL THEN
        INSERT INTO stg_control.migration_run (run_type, status, triggered_by)
        VALUES (p_run_type, 'RUNNING', current_user)
        RETURNING run_id INTO p_run_id;
        COMMIT;
    END IF;

    CALL stg_transform.sp_transform_brand(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_body_style(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_province(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_equipment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_accessory_section(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_model(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_app_user(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_seller(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_dealer(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_dealer_contact(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_admin_user(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_transfer(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_image(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_listing_equipment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_special_deal(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_banner(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_accessory_listing(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_favorite(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_friend(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_request(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_suggestion(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_user_report(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_blocked_contact(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_ip_allowlist(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_system_parameter(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_payment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_payment_log(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_prepayment(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_coupon(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_auto_renewal(p_run_id);  COMMIT;
    CALL stg_transform.sp_transform_einvoice_document(p_run_id);  COMMIT;

    UPDATE stg_control.migration_run
       SET status = CASE WHEN EXISTS (SELECT 1 FROM stg_control.step_log
                                       WHERE run_id = p_run_id AND step_name = 'sp_transform' AND status = 'FAILED')
                         THEN 'FAILED' ELSE 'SUCCESS' END,
           finished_at = now()
     WHERE run_id = p_run_id;
    COMMIT;
    RAISE NOTICE 'sp_transform_all terminado · run_id = %', p_run_id;
END;
$$;
