-- ======================================================================
-- Extensiones y esquemas de staging
-- Requiere permisos CREATE en crautos_db.
-- Proyecto: Migración de datos CRAutos · Historia DATA-02 · Modelo de staging v0
-- Autor: Andrés Varela (Ingeniería de Datos) · 15/10/2026
-- ======================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";  -- uuid_generate_v5 (UUID determinístico)
CREATE EXTENSION IF NOT EXISTS pgcrypto;     -- digest / gen_random_uuid

CREATE SCHEMA IF NOT EXISTS stg_raw;        -- espejo 1:1 del origen (lo llena AWS DMS)
CREATE SCHEMA IF NOT EXISTS stg_transform;  -- datos limpios, tipados y homologados
CREATE SCHEMA IF NOT EXISTS stg_validated;  -- solo filas que pasaron sp_validate
CREATE SCHEMA IF NOT EXISTS stg_control;    -- control operativo, errores y reconciliación

