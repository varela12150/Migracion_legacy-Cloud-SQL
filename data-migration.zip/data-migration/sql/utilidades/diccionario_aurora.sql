SET SESSION default_transaction_read_only = on;

WITH cols AS (
    SELECT n.nspname AS esquema, c.relname AS tabla, c.oid AS relid,
           a.attnum AS orden, a.attname AS columna, a.atttypid,
           format_type(a.atttypid, a.atttypmod) AS tipo_dato,
           CASE WHEN a.attnotnull THEN 'NO' ELSE 'SI' END AS acepta_nulos,
           pg_get_expr(d.adbin, d.adrelid) AS valor_default,
           CASE a.attidentity WHEN 'a' THEN 'ALWAYS' WHEN 'd' THEN 'BY DEFAULT' END AS identity,
           col_description(c.oid, a.attnum) AS descripcion_columna,
           obj_description(c.oid, 'pg_class') AS descripcion_tabla,
           CASE WHEN c.reltuples >= 0 THEN c.reltuples::bigint END AS filas_estimadas
    FROM pg_attribute a
    JOIN pg_class c      ON c.oid = a.attrelid
    JOIN pg_namespace n  ON n.oid = c.relnamespace
    LEFT JOIN pg_attrdef d ON d.adrelid = c.oid AND d.adnum = a.attnum
    WHERE c.relkind IN ('r','p')
      AND NOT c.relispartition
      AND a.attnum > 0 AND NOT a.attisdropped
      AND n.nspname NOT IN ('pg_catalog','information_schema')
      AND n.nspname NOT LIKE 'pg\_%'
),
llaves AS (
    SELECT con.conrelid AS relid, k.attnum,
           string_agg(DISTINCT CASE con.contype WHEN 'p' THEN 'PK' WHEN 'u' THEN 'UQ' WHEN 'f' THEN 'FK' END, ', ') AS llaves,
           string_agg(DISTINCT CASE WHEN con.contype = 'f'
                      THEN fn.nspname || '.' || fc.relname || '(' || fa.attname || ')' END, ', ') AS referencia_fk,
           string_agg(DISTINCT CASE WHEN con.contype = 'c' THEN pg_get_constraintdef(con.oid) END, ' ; ') AS reglas_check
    FROM pg_constraint con
    CROSS JOIN LATERAL unnest(con.conkey) WITH ORDINALITY AS k(attnum, pos)
    LEFT JOIN pg_class fc     ON fc.oid = con.confrelid
    LEFT JOIN pg_namespace fn ON fn.oid = fc.relnamespace
    LEFT JOIN pg_attribute fa ON fa.attrelid = con.confrelid AND fa.attnum = con.confkey[k.pos::int]
    WHERE con.contype IN ('p','u','f','c')
    GROUP BY con.conrelid, k.attnum
),
indices AS (
    SELECT i.indrelid AS relid, k.attnum, string_agg(DISTINCT ic.relname, ', ') AS indices
    FROM pg_index i
    JOIN pg_class ic ON ic.oid = i.indexrelid
    CROSS JOIN LATERAL unnest(i.indkey::int2[]) AS k(attnum)
    WHERE k.attnum > 0
    GROUP BY i.indrelid, k.attnum
)
SELECT c.esquema, c.tabla, c.orden, c.columna, c.tipo_dato,
       (SELECT string_agg(e.enumlabel, ' | ' ORDER BY e.enumsortorder)
          FROM pg_enum e WHERE e.enumtypid = c.atttypid) AS valores_permitidos,
       c.acepta_nulos, c.valor_default, c.identity,
       l.llaves, l.referencia_fk, l.reglas_check, ix.indices,
       c.descripcion_columna, c.descripcion_tabla, c.filas_estimadas
FROM cols c
LEFT JOIN llaves  l  ON l.relid  = c.relid AND l.attnum  = c.orden
LEFT JOIN indices ix ON ix.relid = c.relid AND ix.attnum = c.orden
ORDER BY c.esquema, c.tabla, c.orden;
