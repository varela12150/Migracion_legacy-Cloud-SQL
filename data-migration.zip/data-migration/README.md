# Migración de datos CRAutos

Migración de la base MySQL legada de CRAutos (`usedcars`, `newcars`, `micrautos`, `accesorios`) hacia **Aurora PostgreSQL** (`crautos_db`), usando AWS DMS para la carga y un staging de cuatro capas en PostgreSQL para transformar, validar y publicar los datos.

**Responsable:** Andrés Varela · Ingeniería de Datos · GFT Costa Rica

![Flujo de migración](docs/02_diseno/Diagrama_flujo_migracion_2026-11-06.png)

## Estado al 13/11/2026

| Fase | Estado |
| --- | --- |
| Descubrimiento | Terminada |
| Diseño | Terminada salvo T13 (modelo destino) y T14 (reglas de validación), en progreso |
| Construcción | En progreso: staging en UAT con datos reales, `sp_transform` y `sp_validate` ejecutados |

**Últimos hitos (UAT, datos reales cargados por AWS DMS):**

- **Carga DMS:** 102 tablas en `stg_raw`; las 47 en alcance cuadran con MySQL.
- **sp_transform:** 32/32 entidades con datos reales (≈9,9 M filas en `stg_transform`).
- **sp_validate:** 64 reglas aplicadas; 72,5 % de las filas aprobadas en `stg_validated`. Lo que no pasó se está revisando regla por regla.

Evidencia en [docs/03_construccion](docs/03_construccion/). Orden de despliegue en UAT en [sql/staging/90_UAT/LEEME.md](sql/staging/90_UAT/LEEME.md).

## Arquitectura del staging

```
MySQL legado ──DMS──▶ stg_raw ──sp_transform──▶ stg_transform ──sp_validate──▶ stg_validated ──sp_publish──▶ modelo destino
                        (47 tablas)               (32 entidades)                  (32 entidades, 64 reglas)
                                         stg_control: bitácora, errores, homologación, parámetros
```

| Esquema | Contenido |
| --- | --- |
| `stg_raw` | Espejo 1:1 del origen, sin restricciones. Lo llena AWS DMS (en UAT, con datos reales) |
| `stg_transform` | Datos limpios y tipados, con UUID determinístico. Lo llena `sp_transform_*` |
| `stg_validated` | Solo filas que pasan las reglas de `stg_control.validation_rule`. Lo llena `sp_validate` |
| `stg_control` | `migration_run`, `step_log`, `error_record`, `map_catalog`, `validation_rule` y funciones comunes `fn_*` |

## Estructura del repositorio

```
├── docs/
│   ├── 01_descubrimiento/   Inventario del MySQL de origen (Word y Excel)
│   ├── 02_diseno/           Clasificación v1 y matrices S2T (T15–T18), diagrama de flujo
│   ├── 03_construccion/     Evidencia de pruebas (dummy y UAT), reglas de validación, conciliación DMS
│   └── 04_seguimiento/      Tracker, rendición de cuentas y presentaciones de avance
└── sql/
    ├── staging/             DDL y procedimientos del staging v1 (ver sql/staging/LEEME_v1.md)
    │   ├── 00_ejecutar_todo.sql   Script maestro (psql)
    │   ├── 10_stg_control/        Tablas de control y funciones comunes
    │   ├── 20_stg_transform/      32 tablas de transformación
    │   ├── 30_stg_validated/      32 tablas validadas
    │   ├── 40_stg_raw/            Generador del DDL de stg_raw desde el MySQL
    │   ├── 50_sp_transform/       32 procedimientos por entidad + orquestador sp_transform_all
    │   ├── 60_datos_dummy/        Datos de prueba, verificación y versiones para DBeaver
    │   ├── 70_sp_validate/        stg_validated, validation_rule v2, 64 reglas, sp_validate_entity/_all
    │   ├── 80_reconciliacion/     Conteo MySQL vs stg_raw (carga DMS)
    │   ├── 90_UAT/                Despliegue en UAT: esquemas, sp_transform para tablas DMS, verificación
    │   └── historico/             DDL v0 (solo referencia)
    └── utilidades/          Consulta de diccionario de datos de Aurora
```

## Cómo ejecutar la prueba con datos dummy

Con **psql**, desde `sql/staging/`:

```bash
psql -d crautos_db -f 60_datos_dummy/00_crear_stg_raw_desde_Q01.sql   # 47 tablas stg_raw
psql -d crautos_db -f 00_ejecutar_todo.sql                            # staging + procedimientos
psql -d crautos_db -f 60_datos_dummy/01_insert_dummy_stg_raw.sql      # 2.650 filas de prueba
psql -d crautos_db -c "CALL stg_transform.sp_transform_all(NULL);"
psql -d crautos_db -f 60_datos_dummy/02_verificar_transform.sql
```

Con **DBeaver**, usa los scripts de `60_datos_dummy/dbeaver/` en este orden: `2b`, `2c`, `2d`, `2e`, `01_insert…`, `CALL`, `02_verificar…`. Antes, ten en cuenta:

- **Auto-Commit** debe estar activado.
- El **esquema activo** debe ser `public`.
- Ejecuta cada script completo con **Alt+X**.
- Las extensiones `uuid-ossp` y `pgcrypto` deben estar instaladas en `public`.

El detalle paso a paso, con las verificaciones y los resultados esperados, está en el documento de evidencia.

## Pendientes principales

- **Revisión de sp_validate regla por regla:** causas de las filas detenidas (enlaces entre tablas, anuncios de traspaso, duplicados del ciclo de vida). Detalle en la evidencia de UAT.
- **H-01:** teléfonos con dos números en un campo ("tel1 / tel2"). Decisión de negocio: tomar el primero o guardar un segundo teléfono.
- **map_catalog:** falta cargar la homologación (Q05/Q06). Mientras tanto los valores salen como `UNMAPPED:<valor>` y las 2 reglas de marca siguen inactivas.
- **Q07:** lógica de presencia de equipamiento (`fn_equipment_present`).
- **CDC:** confirmar que DMS aplica cambios nuevos y agregar la detección de borrados en UAT.
- **Siguientes procedimientos:** `sp_publish` y `sp_reconcile` (DATA-05).
- **Diseño:** cerrar T13 (modelo destino) y T14 (reglas de validación).

## Notas

- Este repositorio no contiene datos de clientes. Los datos de `60_datos_dummy` son ficticios; los resultados de UAT se versionan solo como totales.
- Los resultados crudos de las consultas de descubrimiento (Q01–Q10) no se versionan; se resumen en el inventario y en las matrices de diseño.
- La dirección del servidor de origen se omitió de los documentos a propósito.
